# MUnit automation — version 5.0.0

This revision implements endpoint-based HTTP generation and supersedes the version 4 instruction package. It is a set of agent instructions, not a guarantee of identical output from every model. No model is pinned; keep the existing chat Agent and Auto selections.

## Files and invocation

| File | Responsibility |
| --- | --- |
| [munit-generate.prompt.md](munit-generate.prompt.md) | Interactive source discovery and routing; asks for scope only when missing |
| [munit-http-listener.prompt.md](munit-http-listener.prompt.md) | RAML-first HTTP generation; one suite per routed method/path operation; all nested processing and error handlers |
| [munit-non-http-listener.prompt.md](munit-non-http-listener.prompt.md) | Every non-HTTP source, with DWL/producer-based inputs and complete nested processing |

```text
/munit-generate
/munit-generate all
/munit-generate orders.xml
/munit-generate orders.xml,customers.xml
/munit-generate errors
```

The no-argument command discovers sources and asks for all/files/errors. Supplying all already answers that question. Mixed applications plan both routes, HTTP first; missing RAML stops the entire selection before project writes.

## What changed

- `all` requires a frozen inventory of every APIKit-routed method/path operation, followed by one owning endpoint suite per inventory row. It does not mean one suite per source XML. Each endpoint suite contains its recursively planned scenarios. Media-type variants become scenarios within that endpoint suite.
- Every flow/sub-flow, when/otherwise, scatter-gather route, foreach, parallel-foreach, batch step/aggregator/on-complete, async scope, retry and handler body is traversed. Unresolved coverage is reported as incomplete, never silently excluded.
- APIKit handlers discovered through error-handler.xml or the actual referenced equivalent go into apikit-error-test-suite.xml; main handlers go into error-test-suite.xml. Each handler/type/condition/body branch is an obligation. Handler groups absent from source are reported, not invented.
- Every generated suite imports `<import file="test-config.xml" doc:name="Import"/>`. Shared client settings live in src/test/resources/test-config.xml, and are reused or derived from actual test/listener settings. The suite's own munit:config remains separate. Inline HTTP client configuration is removed from the suite template.
- Every mock then-return payload must call MunitTools::getResourceAsString with a literal out/*.json path. Typed results may wrap that call in read. Returning bare payload is banned in mocks; event-preserving operations omit the return-payload element.
- Both workers include executable native structural gates for the expected suite inventory, mandatory import, nonempty test suites and file-backed mock payloads. These checks do not prove semantic endpoint discovery or runtime correctness; the source ledger and actual runner remain necessary.
- Existing tests are compared and repaired narrowly. Combined legacy suites may be migrated by source-traced scenario ownership into endpoint suites, retaining useful content and unrelated tests. A genuinely unchanged rerun writes nothing.

## Native commands and installation

All extraction, validation and workflow commands are inside the worker Markdown. Complete one-time installers are enclosed below; no extra .ps1/.sh helper is required. Extract this package outside the Mule project and open a terminal in this directory before pasting the appropriate block.

Windows uses built-in PowerShell 5.1/.NET ZIP support. macOS uses its system Bash/unzip utilities; PowerShell is not assumed on macOS. Missing, corrupt, inaccessible or unsafe RAML archives stop with a clear message and no project output. No implementation can promise archive extraction never fails.

The installers add no extensions/dependencies and do not edit application folders. They assume an existing authorized VS Code chat setup. Actual test execution also requires the project's provisioned Java/Maven/Mule/MUnit 2.x environment.

Default installation format is Prompt, for the supported VS Code Local prompt session. Current VS Code documentation distinguishes Agent Host sessions, where prompt files are not loaded; use the provided Skill format option there. Prompt format uses the user prompt location; Skill format installs the same worker bodies as personal SKILL.md files with router links adjusted. Keep one active format per command and select a custom destination for a nondefault profile when required. [VS Code prompt files](https://code.visualstudio.com/docs/agent-customization/prompt-files)

The blocks already include `-Update` on Windows and `--update` on macOS to update an installed version of the same command names. Changed definitions are backed up; identical definitions are left untouched. Use the same installed format: change `-Format Prompt` to `-Format Skill`, or `--format prompt` to `--format skill`, when appropriate. The installer refuses conflicting formats in default locations. Do not invoke obsolete munit-scaffold commands from an older attachment; the commands in this package are the munit-generate/listener names shown above.

### Windows: paste into Windows PowerShell 5.1

This is a pasted command block; it does not need a persisted script or execution-policy change. Default Prompt destination is %APPDATA%\Code\User\prompts; Skill uses %USERPROFILE%\.copilot\skills. For a named/custom profile, append `-Destination 'ABSOLUTE_DIRECTORY'` after the closing script block arguments. Skill destination is the parent skills directory; Prompt destination is the prompt directory itself.

```powershell
& {
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [ValidateSet('Skill', 'Prompt')][string]$Format = 'Prompt',
    [string]$Destination,
    [switch]$Update
)
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false, $true)
$userRoot = [Environment]::GetFolderPath('UserProfile')
if (-not $userRoot) { throw 'Cannot resolve user profile.' }
$skillRoot = Join-Path $userRoot '.copilot/skills'
if ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) {
    $promptRoot = Join-Path ([Environment]::GetFolderPath('ApplicationData')) 'Code\User\prompts'
} else {
    $promptRoot = Join-Path $userRoot 'Library/Application Support/Code/User/prompts'
}
$useDefault = [string]::IsNullOrWhiteSpace($Destination)
if ($useDefault) {
    if ($Format -eq 'Skill') { $Destination = $skillRoot } else { $Destination = $promptRoot }
}
$Destination = [IO.Path]::GetFullPath($Destination)
# Preflight all three files before any destination write; publish router last.
$names = @('munit-http-listener', 'munit-non-http-listener', 'munit-generate')
$plan = @()
foreach ($name in $names) {
    $source = Join-Path (Get-Location).Path ($name + '.prompt.md')
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing bundled file: $source" }
    $text = [IO.File]::ReadAllText($source, $utf8).Replace("`r`n", "`n")
    $match = [regex]::Match($text, '\A---\n(?<header>.*?)\n---\n(?<body>[\s\S]*)\z', 'Singleline')
    if (-not $match.Success) { throw "Invalid frontmatter: $source" }
    $header = $match.Groups['header'].Value
    if ($header -notmatch ("(?m)^name: '" + [regex]::Escape($name) + "'$") -or
        $header -notmatch "(?m)^version: '5\.0\.0'$") { throw "Mismatched name/version: $source" }
    if ($Format -eq 'Skill') {
        $lines = @('---') + @($header -split "`n" | Where-Object { $_ -match '^(name|description):' })
        $lines += @('metadata:', "  version: '5.0.0'", '---')
        $body = [regex]::Replace($match.Groups['body'].Value, '\((munit-[a-z-]+)\.prompt\.md\)', '(../$1/SKILL.md)')
        $text = ($lines -join "`n") + "`n" + $body
        $target = Join-Path (Join-Path $Destination $name) 'SKILL.md'
        $other = Join-Path $promptRoot ($name + '.prompt.md')
    } else {
        $target = Join-Path $Destination ($name + '.prompt.md')
        $other = Join-Path (Join-Path $skillRoot $name) 'SKILL.md'
    }
    if ($useDefault -and (Test-Path -LiteralPath $other)) {
        throw "Other command format exists at $other. Keep one active format; relocate it before switching."
    }
    $changed = $true
    if (Test-Path -LiteralPath $target) {
        $item = Get-Item -LiteralPath $target
        if ($item.PSIsContainer -or (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
            throw "Destination is not a regular file: $target"
        }
        $changed = [IO.File]::ReadAllText($target, $utf8) -cne $text
        if ($changed -and -not $Update) { throw "Existing content differs: $target. Use -Update to preserve a backup and replace the installed skill." }
    }
    $plan += [pscustomobject]@{ Path = $target; Text = $text; Changed = $changed }
}
if (-not ($plan | Where-Object { $_.Changed })) {
    Write-Output 'All three commands are already installed; no changes.'
    return
}
if (-not $PSCmdlet.ShouldProcess($Destination, 'Install the three MUnit command files')) { return }
foreach ($entry in $plan) {
    if (-not $entry.Changed) { Write-Output "Unchanged: $($entry.Path)"; continue }
    $directory = [IO.Path]::GetDirectoryName($entry.Path)
    [IO.Directory]::CreateDirectory($directory) | Out-Null
    $stage = Join-Path $directory ('.munit-install-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [IO.File]::WriteAllText($stage, $entry.Text, $utf8)
        if ([IO.File]::ReadAllText($stage, $utf8) -cne $entry.Text) { throw 'Staged verification failed.' }
        if (Test-Path -LiteralPath $entry.Path) {
            $backup = $entry.Path + '.backup-' + [guid]::NewGuid().ToString('N')
            [IO.File]::Replace($stage, $entry.Path, $backup)
            Write-Output "Backup: $backup"
        } else { [IO.File]::Move($stage, $entry.Path) }
        if ([IO.File]::ReadAllText($entry.Path, $utf8) -cne $entry.Text) { throw 'Installed verification failed.' }
        Write-Output "Installed: $($entry.Path)"
    } finally {
        if (Test-Path -LiteralPath $stage -PathType Leaf) { [IO.File]::Delete($stage) }
    }
}
Write-Output 'Reload VS Code if needed. Select Agent and Auto; run /munit-generate all.'
Write-Output 'This installer updates skill definitions only. Selected application tests are synchronized using the worker prompts.'
} -Format Prompt -Update
```

### macOS: paste into Terminal

PowerShell is not built into macOS; this block uses its system Bash and native utilities. Default Prompt destination is ~/Library/Application Support/Code/User/prompts; Skill uses ~/.copilot/skills. Add `--destination 'ABSOLUTE_DIRECTORY'` to the first line for a different profile.

```bash
/bin/bash -s -- --format prompt --update <<'MUNIT_INSTALL'
set -euo pipefail
format=prompt
destination=''
update=false
while [ "$#" -gt 0 ]; do
    case "$1" in
        --format) [ "$#" -ge 2 ] || exit 2; format=$2; shift 2 ;;
        --destination) [ "$#" -ge 2 ] && [ -n "$2" ] || exit 2; destination=$2; shift 2 ;;
        --update) update=true; shift ;;
        --help) echo 'Usage: /bin/bash install-munit-command.sh [--format skill|prompt] [--destination DIRECTORY] [--update]'; exit 0 ;;
        *) echo "Unknown argument: $1" >&2; exit 2 ;;
    esac
done
case "$format" in skill|prompt) ;; *) echo 'Format must be skill or prompt' >&2; exit 2 ;; esac
bundle=$PWD
skill_root="$HOME/.copilot/skills"
prompt_root="$HOME/Library/Application Support/Code/User/prompts"
use_default=false
if [ -z "$destination" ]; then
    use_default=true
    if [ "$format" = skill ]; then destination=$skill_root; else destination=$prompt_root; fi
fi
stage_dir=$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/munit-install.XXXXXXXX")
target_stage=''
cleanup() {
    /bin/rm -f -- "$stage_dir/munit-http-listener" "$stage_dir/munit-non-http-listener" "$stage_dir/munit-generate"
    /bin/rmdir -- "$stage_dir"
    if [ -n "$target_stage" ]; then /bin/rm -f -- "$target_stage"; fi
}
trap cleanup EXIT
names=(munit-http-listener munit-non-http-listener munit-generate)
targets=()
changes=()
# Preflight all three destinations before publishing any file; router is last.
for name in "${names[@]}"; do
    source="$bundle/$name.prompt.md"
    [ -f "$source" ] || { echo "Missing bundled file: $source" >&2; exit 1; }
    /usr/bin/awk -v expected="$name" '
      NR == 1 {if ($0 != "---") bad=1; next}
      !closed && $0 == "---" {closed=1; next}
      !closed && $0 == "name: '\''" expected "'\''" {name_ok=1}
      !closed && $0 == "version: '\''5.0.0'\''" {version_ok=1}
      END {if (bad || !closed || !name_ok || !version_ok) exit 1}
    ' "$source" || { echo "Invalid bundled name/version: $source" >&2; exit 1; }
    if [ "$format" = skill ]; then
        target="$destination/$name/SKILL.md"
        other="$prompt_root/$name.prompt.md"
        /usr/bin/awk '
          NR == 1 {print; next}
          !closed && $0 == "---" {print "metadata:"; print "  " version; print "---"; closed=1; next}
          !closed {if ($0 ~ /^(name|description):/) print; if ($0 ~ /^version:/) version=$0; next}
          {print}
        ' "$source" | /usr/bin/sed -E 's@\((munit-[a-z-]+)\.prompt\.md\)@(../\1/SKILL.md)@g' > "$stage_dir/$name"
    else
        target="$destination/$name.prompt.md"
        other="$skill_root/$name/SKILL.md"
        /bin/cp -- "$source" "$stage_dir/$name"
    fi
    if [ "$use_default" = true ] && [ -e "$other" ]; then
        echo "Other command format exists at $other. Keep one active format; relocate it before switching." >&2; exit 1
    fi
    if [ -L "$target" ] || { [ -e "$target" ] && [ ! -f "$target" ]; }; then
        echo "Destination is not a regular file: $target" >&2; exit 1
    fi
    changed=true
    if [ -f "$target" ]; then
        if /usr/bin/cmp -s "$target" "$stage_dir/$name"; then changed=false
        elif [ "$update" = false ]; then
            echo "Existing content differs: $target. Use --update to preserve a backup and replace the installed skill." >&2; exit 1
        fi
    fi
    targets+=("$target")
    changes+=("$changed")
done
for ((i=0; i<${#names[@]}; i++)); do
    target=${targets[$i]}
    if [ "${changes[$i]}" = false ]; then echo "Unchanged: $target"; continue; fi
    directory=$(dirname -- "$target")
    /bin/mkdir -p -- "$directory"
    target_stage=$(/usr/bin/mktemp "$directory/.munit-install.XXXXXXXX")
    /bin/cp -- "$stage_dir/${names[$i]}" "$target_stage"
    /usr/bin/cmp -s "$target_stage" "$stage_dir/${names[$i]}"
    if [ -f "$target" ]; then
        backup="$target.backup-$(/usr/bin/uuidgen)"
        /bin/cp -p -- "$target" "$backup"
        echo "Backup: $backup"
    fi
    /bin/mv -f -- "$target_stage" "$target"
    target_stage=''
    /usr/bin/cmp -s "$target" "$stage_dir/${names[$i]}"
    echo "Installed: $target"
done
echo 'Reload VS Code if needed. Select Agent and Auto; run /munit-generate all.'
echo 'This installer updates skill definitions only. Selected application tests are synchronized using the worker prompts.'
MUNIT_INSTALL
```

Reload VS Code if the slash commands are not listed; inspect Chat: Open Customizations. In remote sessions install on the host where the agent reads its prompts/skills. Normal editor tool approvals remain in effect.

## Validation and honest limits

The regression cases and results for this revision are in [VALIDATION.md](VALIDATION.md). Generated template parsing and native script checks are not an actual Mule application execution. No application or remote system from your reported failure was inspected.

The mandatory non-null assertion remains your convention. It does not verify business output or expected HTTP status. A 200..599 validator admits error responses; it does not establish correct error handling. Valid null results or unreachable predicates are reported as policy/coverage blockers, not hidden by invented data.

MUnit mocks are established after application initialization, so connector/global configuration can still be required. Injected errors must be valid for the installed modules. [MUnit 2.3 mock processor](https://docs.mulesoft.com/munit/2.3/mock-event-processor)

APIKit explicit mappings can specify resource, action and content type; discovery must reconcile mappings and contract operations. [APIKit module reference](https://docs.mulesoft.com/apikit/latest/apikit-4-xml-reference)

Batch processing requires record-policy and completion analysis; one HTTP response does not establish every record completed. [Mule batch phases](https://docs.mulesoft.com/mule-runtime/4.6/batch-phases)
