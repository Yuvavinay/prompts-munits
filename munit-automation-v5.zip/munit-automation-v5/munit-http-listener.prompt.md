---
mode: 'agent'
agent: 'agent'
name: 'munit-http-listener'
version: '5.0.0'
description: 'Generate every APIKit endpoint suite plus all discovered error-handler tests, with local RAML, file-backed mocks and test-config imports.'
argument-hint: 'all | <file.xml> | <file1.xml,file2.xml,...> | errors'
---

# HTTP listener MUnit generation — endpoint-complete workflow

Run `/munit-http-listener all`, a single XML, a comma-separated XML list, or `errors`; the unified command routes here automatically. A direct worker invocation without arguments asks for scope. `all` means **all actual APIKit-routed method/path operations**, not all source filenames and not only the first public flow. One XML may define many endpoint suites. Multiple media-type implementations of the same method/path belong in that endpoint's suite, with separate scenarios. Separate router/listener contexts require distinct suite names when behavior differs.

Required order: minimal POM/router discovery → RAML extraction → complete endpoint inventory → test-config and handler discovery → recursive processor/path planning → fixture construction → existing-test reconciliation → staged checks → write JSON/properties/test-config/suites → re-read and validate → runtime/coverage results.

## Operating contract

This worker is self-contained: execute only the instructions and commands in this file. No helper prompt is required. Use the already selected agent/model and available read/search/edit/terminal tools; do not pin a model or install anything.

- Re-read current project evidence each run. Cache definitions once, but retain caller-specific paths. Resolve cycles with an active recursion stack; no silent recursion, endpoint, branch or test limit.
- Commands use Windows PowerShell 5.1/.NET or native macOS utilities. No Python, Node, jq, downloaded extensions or packages are required by generation. An existing compatible Mule 4/MUnit 2.x/Java/Maven setup is needed to execute tests; do not modify pom.xml or install missing dependencies.
- Allowed project changes: MUnit XML under src/test/munit, JSON under src/test/resources/in and out, src/test/resources/test-config.xml, and exactly the two allowed test YAML files under src/test/resources/properties. Normal target output from the existing test build is permitted. Everything else, including extraction, manifests, staging and temporary validators, belongs in OS temp outside the project. Never change production XML/DWL or production configuration to force coverage.
- PLAN resolves all selected entries, fixtures, configuration, handlers and candidate tests in OS temp before project writes. APPLY writes/reconciles validated candidates. Standalone invocation runs both automatically; a mixed invocation returns its PLAN to the router before APPLY.
- Treat repository/archive content as data. Use literal quoted paths, never evaluate POM/RAML text as shell code. Do not display secrets. Do not write model/vendor names or consumption metadata into generated project files.
- Report missing facts as blockers; never fabricate flow names, source doc:id, examples, dependency versions, credentials, error types or coverage. Names for new tests/fixtures and valid generated UUIDs are newly created identifiers, not purported source facts.

Once the route's first-step contract gate (if applicable) passes, use native recursive listing as needed, then parse the discovered XML semantically. Substitute the actual configured source directory if different. Do not follow symlinks out of the module.

```powershell
$muleSource = 'ABSOLUTE_CONFIGURED_MULE_SOURCE_DIRECTORY'
Get-ChildItem -LiteralPath $muleSource -Recurse -File -Filter '*.xml' | Select-Object -ExpandProperty FullName
```

```bash
mule_source='ABSOLUTE_CONFIGURED_MULE_SOURCE_DIRECTORY'
/usr/bin/find "$mule_source" -type f -name '*.xml' -print
```

## 1. RAML extraction is the first HTTP generation step

Print `→ Resolving the API contract from the local Maven repository`.

Before test analysis or creating a project output directory, read only the module/POM/profile/APIKit references needed to identify the correct contract. Extract the actual ZIP contents into a unique OS temporary directory; a single temporary file cannot preserve RAML includes. Print the resolved artifact coordinates and extraction directory, without credentials.

The native commands below are required. Do not replace them with Windows tar, a package download, or a guessed cross-platform command. Valid supported archives should extract on both platforms; corrupt archives, denied permissions and missing files must produce a clear controlled failure, never a claim that extraction cannot fail. On extraction errors print `RAML extraction failed: <reason>. No project files were written.` Do not continue with partially extracted data. An empty archive/no API root is a RAML-not-found stop.

Resolve coordinates as **data**, not executable shell text:

1. Read the RAML/ZIP dependency's groupId, artifactId, version, type, classifier from the module POM, dependencyManagement/imported local BOMs, local parents and applicable profiles. Match the APIKit `api`/`raml` reference to the selected artifact/root. Do not choose the first ZIP dependency. Resolve `${...}` recursively with cycle detection. Unavailable parents, ambiguous profiles, version ranges, or unresolved expressions are blockers; do not guess a version.
2. Determine the effective local repository from explicit `-Dmaven.repo.local`, configured Maven arguments/settings, user `~/.m2/settings.xml`, global settings where applicable, then default `~/.m2/repository`. Resolve precedence; do not scan unrelated repositories for the newest version. On Windows use the actual user profile path, not a literal tilde. Do not display credentials from settings.
3. Construct `<repository>/<groupId with dots replaced by separators>/<artifactId>/<version>/<artifactId>-<version>[-<classifier>].<extension>`. For a dependency explicitly declared as ZIP/RAML, honor the actual classifier; do not substitute a fragment for the root API. If classifier is absent and source conventions leave it uncertain, inspect only the matching version directory and prove the chosen archive/root from APIKit and archive metadata. For SNAPSHOTs resolve the matching extension/classifier through local `maven-metadata*.xml`; do not sort files by date and assume the latest is correct.
4. Check all selected archive paths exist before creating project output directories. If absent, print exactly `RAML not found. Please add the RAML artifact declared by pom.xml to the local Maven repository, then rerun /munit-generate. No project files were written.` Include the unresolved coordinates and checked paths separately. HALT THE ENTIRE RUN. Do not fetch an online or source-tree substitute.
5. Extract to a fresh temporary directory per artifact. Never extract into the project or `.m2`, reuse a stale extraction, or flatten directories. The following blocks use native tools and accept a **resolved absolute archive path**; replace the placeholder using literal shell quoting. Reject malformed, encrypted, unsafe, or corrupt archives; do not continue after a nonzero exit.

### Windows native extraction (PowerShell 5.1)

Use Windows PowerShell, not a shell whose `tar` implementation cannot read ZIPs. Single quotes in a literal path must be doubled. This block validates paths before extraction; it needs no downloaded module.

```powershell
$ErrorActionPreference = 'Stop'
$ramlArchive = 'RESOLVED_ABSOLUTE_ARCHIVE_PATH'
if (-not (Test-Path -LiteralPath $ramlArchive -PathType Leaf)) {
    throw 'RAML not found. No project files were written.'
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$ramlTemp = Join-Path ([IO.Path]::GetTempPath()) ('munit-raml-' + [guid]::NewGuid().ToString('D'))
$ramlZip = [IO.Compression.ZipFile]::OpenRead($ramlArchive)
try {
    $seen = @{}
    foreach ($entry in $ramlZip.Entries) {
        $n = $entry.FullName.Replace('\', '/')
        if ($n -match '(^/|^[A-Za-z]:|(^|/)\.\.(/|$)|[\x00-\x1f])') { throw 'Unsafe archive path' }
        $dest = [IO.Path]::GetFullPath((Join-Path $ramlTemp $n))
        $prefix = [IO.Path]::GetFullPath($ramlTemp) + [IO.Path]::DirectorySeparatorChar
        if (-not $dest.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Archive path escapes temp' }
        if ($seen.ContainsKey($dest)) { throw 'Duplicate archive destination' }
        $seen[$dest] = $true
        if (($entry.ExternalAttributes -band 0xF0000000L) -eq 0xA0000000L) { throw 'Archive symlink is not allowed' }
    }
} finally { $ramlZip.Dispose() }
[IO.Compression.ZipFile]::ExtractToDirectory($ramlArchive, $ramlTemp)
Get-ChildItem -LiteralPath $ramlTemp -Recurse -File -Filter '*.raml' | Select-Object -ExpandProperty FullName
Write-Output ('RAML_TEMP=' + $ramlTemp)
```

### macOS native extraction (system Bash)

Use `/bin/bash`. Quote a literal single quote as `'\''`; never interpolate POM text as shell code. These utilities are part of macOS; no PowerShell, Python, Node, Java, or Homebrew is required for extraction.

```bash
set -euo pipefail
raml_archive='RESOLVED_ABSOLUTE_ARCHIVE_PATH'
test -f "$raml_archive" || { echo 'RAML not found. No project files were written.' >&2; exit 1; }
unset UNZIP UNZIPOPT ZIPINFO ZIPINFOOPT
raml_names=$(/usr/bin/unzip -Z1 "$raml_archive")
raml_details=$(/usr/bin/zipinfo -l "$raml_archive")
printf '%s\n' "$raml_names" | /usr/bin/awk '
  /^\// || /^[A-Za-z]:/ || /\\/ || /(^|\/)\.\.(\/|$)/ || /[[:cntrl:]]/ {bad=1}
  {key=tolower($0); if (seen[key]++) bad=1}
  END {exit bad ? 1 : 0}' || { echo 'Unsafe or duplicate archive path' >&2; exit 1; }
printf '%s\n' "$raml_details" | /usr/bin/awk '
  /^l/ {bad=1} END {exit bad ? 1 : 0}' || { echo 'Archive symlink is not allowed' >&2; exit 1; }
/usr/bin/unzip -tq "$raml_archive" </dev/null
raml_temp=$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/munit-raml.XXXXXXXX")
/usr/bin/unzip -q "$raml_archive" -d "$raml_temp" </dev/null
/usr/bin/find "$raml_temp" -type f -name '*.raml' -print
printf 'RAML_TEMP=%s\n' "$raml_temp"
```

6. Find the API root with `#%RAML 1.0` or the project's supported RAML version; a Library, Trait, DataType, or NamedExample fragment is not an API root. Multiple roots require APIKit mapping evidence. No valid root is the same whole-run halt as a missing artifact.
7. Resolve `!include`, `uses`, traits, resourceTypes, type inheritance, named examples, schemas, and nested resources relative to each referring file. Prefer bundled `exchange_modules`; use local fragment artifacts only when their coordinates are evidenced in the contract/POM/metadata. Preserve relative references across extraction directories. Missing referenced fragments or remote-only references stop generation; do not download them. Detect reference cycles and traverse each dependency once.
8. Build a per-operation contract: method, full resource path, media types, required headers/query/URI parameters, effective request type constraints, request example, and responses. RAML keys are `example`/`examples`; “requestExample” below means the selected request body's example value, not a guessed RAML keyword. Resolve inherited traits and distinguish example wrappers (`value`, `strict`) from the actual body.

For plain HTTP flows, replace references to APIKit mapping in the resolution procedure with the evidenced listener method/path/dispatch mapping. The same local-artifact and missing-contract halt rules apply.

## 2. Enumerate every routed endpoint before planning the first suite

Print `→ Enumerating every APIKit-routed endpoint`.
Recursively read all production XML in the module's configured source roots. Parse namespaces. Build a definition index of all flows/sub-flows, listener sources, APIKit routers/configs and explicit flow-mappings, plus direct and dynamic flow-ref edges. Do not infer an endpoint count from filenames or the first search result.

For `errors`, still discover operations to select real HTTP anchors and valid request fixtures, but mark them ANCHOR_ONLY: no endpoint suite is required or changed in this mode. The expected suite inventory contains only the discovered error groups. For named endpoint selections, include their reachable handlers; for `all`/`errors`, inventory all handlers in the selected HTTP application scope, including unreferenced declarations as unresolved obligations.

1. For each reachable APIKit router, resolve its config and the extracted RAML root. Traverse nested RAML resources and inherited methods. Apply explicit APIKit resource/action/content-type flow mappings first; otherwise resolve the runtime's generated operation-flow convention against actual named flow definitions. Include media-type variants; do not invent flows from a name-splitting heuristic.
2. Cross-check in both directions: every implemented router route maps to a contract operation, and every relevant contract operation maps to its actual operation flow(s). Missing or conflicting mappings are blockers, never reasons to reduce the expected endpoint count. Console flows and shared sub-flows are not extra endpoints. Contract-only operations without implementation remain explicit missing-implementation obligations.
3. Define ENDPOINT_KEY = module + listener/router-config context + HTTP method + normalized full resource path. Preserve URI parameters; do not confuse GET /orders with POST /orders or /orders/{id}. A media-type variant is a child scenario of that key. If multiple listeners merely expose the same graph, record transport variants explicitly and choose grouping from observed behavior, not accidental filename collisions.
4. Freeze an endpoint inventory in OS temp with columns: key, method, path, media types, main listener flow, public operation flow(s), source files, RAML location, suite filename, planned tests, state/blocker. Derive new lower-kebab-case filenames such as get-orders-test-suite.xml and post-orders-test-suite.xml. These are illustrative names, never values to copy into an unrelated project. Add a context suffix only to avoid a proven collision.
5. For `all`, keep every endpoint row in scope. A named file/list selects every endpoint implemented in those files or reached through reverse callers of a selected shared flow; include all dependencies regardless of file location. Validate every requested filename; ambiguous basenames need a full path. Never expand a named selection into unrelated operations.
6. Show **the complete method/path → suite table and its count before writing**: `→ Found <E> APIKit endpoints; expecting <E> endpoint suites plus the applicable APIKit/main error suites`. An example with GET /orders, POST /orders and GET /orders/{id} requires three endpoint suites, not one orders.xml suite. No dummy placeholder suite counts as ready.

For a plain HTTP listener without APIKit, use its evidenced method/path dispatch as the endpoint inventory, retain the RAML gate, and do not invent APIKit operations or APIKit errors. If dynamic dispatch cannot be resolved, report that blocker.

**Completion gate:** each selected endpoint key maps to exactly one owning nonempty endpoint suite and every planned scenario to an actual test in that suite. Distinct endpoint keys cannot share one suite merely because they share a file. Handler suites do not count toward E. Extra existing unrelated suites do not satisfy a missing endpoint. Compare endpoint keys and actual execution routes, not just counts. If two missing endpoints are replaced by two duplicates, validation must fail.

Use a work queue containing every frozen endpoint row followed by the required handler-suite rows. Plan all rows first. During APPLY, advance one row only after its complete suite passes file checks, then process the next row automatically. A per-suite Done message does not return from the invocation. The queue is finished only when every required row is ready, or the run explicitly reports the remaining blocked/pending rows. Never replace the full queue with the currently open editor file.

## 3. Shared configuration and error-handler inventory

Every generated endpoint, APIKit error, and main error suite MUST contain exactly one top-level core import:

```xml
<import file="test-config.xml" doc:name="Import"/>
```

Use `src/test/resources/test-config.xml` as the shared classpath resource. Retain one unique `<munit:config name="SUITE_BASE.xml"/>` per suite: munit:config identifies the suite and does not replace the import. Put HTTP client configuration in test-config.xml, **never inline in an endpoint/error suite**. Do not import production api.xml or error-handler.xml a second time when the application already loads them.

Read an existing test-config.xml and all its consumers first. Reuse its real HTTP request config name, local host, port, TLS, base path, and existing property mechanism. Preserve unrelated configuration. If absent, create it as a test artifact only after deriving its settings from the actual listener and the two existing test YAML files. Use loopback for the test client, honor HTTPS/TLS, and resolve the listener port/test environment; never guess a port, key or config-ref. If a value is not derivable, request it before APPLY. Do not make an empty config merely to satisfy the import.

Keep exactly one discoverable test-config.xml on the test classpath and unique global config names. If it already lives in another loaded test location, prove import resolution and reuse it or plan a narrowly scoped relocation that preserves all references; never create a competing resource. Parse its imports recursively for cycles and duplicate globals. Verify a suite run alone and the combined run both resolve the imported config.

Before fixtures, require both test YAML source files, their actual configuration/secure-properties activation and keys, and the existing compatible MUnit 2.x runner/tools/plugin/assert-expression support. Reject extra pre-existing files in the restricted test-properties folder without deleting them. Constants/error mapping resources may be read on the normal main classpath but are never copied into test resources. Missing build/configuration facts block APPLY.

Locate `error-handler.xml` recursively and read it fully. Also find alternate actual files such as error-handlers.xml through referenced global handlers; never stop because the plural spelling differs. Trace flow-level/try-level handler refs, handler inheritance and defaultErrorHandler-ref. Names alone do not determine handler ownership.

- APIKit handler group → `apikit-error-test-suite.xml`.
- Main/business handler group → `error-test-suite.xml`.
- Inline try handlers and endpoint connector/error branches also remain endpoint-suite obligations.

Inventory every on-error-continue/on-error-propagate, every explicit type in comma-separated lists, an omitted type/ANY catch-all, each when condition, and every processor in each handler body. Preserve order/first-match semantics. Include handlers without a known caller as explicit unreachable blockers rather than silently omitting them. Map every handler/type/condition/body-branch obligation to a planned test. The two error files may contain many tests per handler; their count is not simply the count of handler names. For `all`, both named suites are required when their respective groups exist. If a group is absent, report it as absent and do not invent an empty error suite.

## Drill through every flow, scope and handler

Print `→ Tracing every endpoint/entry through all nested processing`.
For EACH call edge: SEARCH definition → READ complete body → LIST all processors → RECORD backend identifiers and target semantics → RECURSE. Apply this inside choice when/otherwise, scatter-gather routes, foreach, parallel-foreach, batch steps/aggregators/on-complete, async, try, until-successful, error handlers and their own sub-flow calls. Resolve custom DWL imports and inline set-payload/set-variable/set-attributes mappings as well as resource files.

Cache a read definition once but traverse its path context for each caller. Do not mark a sub-flow globally covered after the first endpoint. Detect recursive cycles, then plan a finite reachable execution; unresolved dynamic targets remain blockers. A mock of a resolved flow-ref, whole choice, transform, iterator, scatter-gather, batch job, or error handler is prohibited: it would conceal the processing this build must cover.

Record each processor's source file/location, namespace/operation, containing entry/path, verbatim doc:id/doc:name, config-ref, target/targetValue, predicates, error mappings, payload/attributes/vars producers and downstream consumers. Source identifiers are read this run, not generated. If a source processor lacks doc:id, use a proven unique source doc:name plus discriminators and report that fallback. Do not change production IDs.

Mock outbound operations including http:request, db:*, salesforce:*, wsc:consume, sftp:*, ftp:*, file:*, os:store/retrieve/contains/remove, anypoint-mq:*, jms:*, vm:* and other evidenced external operations. Wildcards denote executable outbound operations, not globals or sources. Never mock loggers, json-logger:logger or transformations. Narrow selectors must not intercept the suite's own HTTP request.

An unavailable sub-flow may have a source-matched flow-ref mock ONLY if its contract is evidenced, with `<!-- NOTE: unresolved flow-ref; body unavailable -->`. That does not satisfy full coverage and prevents a complete result. A nonexistent referenced flow can still prevent application startup.

### Depth-first coverage obligations

Before ANY project write, enumerate this table recursively for every endpoint/entry and handler body. Maintain a source-derived obligation ledger with key, entry/handler, construct, branch/processor, ordered call path, predicates, producing fixture, test name, suite, and blocker. One test can satisfy several obligations only when the traced execution actually reaches all of them.

| Construct | Mandatory scenarios and evidence |
| --- | --- |
| Sequential processing | Every reachable processor before, inside and after nested scopes appears in a test path |
| choice | Every when, respecting preceding false conditions; otherwise with every when false; implicit fall-through if no otherwise element; repeat recursively for nested choices |
| scatter-gather | All routes succeed; every non-trivial alternative in every route, with the other routes still executing; nested alternatives and actual composite-error handling |
| foreach | At least one actual iteration, every internal branch and downstream processing; empty/multiple collections where they change behavior |
| parallel-foreach | Actual nonempty iteration with all internal paths; evidence for aggregation, route-specific errors and downstream handling; no shared mutable mock counter for nondeterministic order |
| batch | Each step with records meeting its acceptPolicy/acceptExpression, successful and failed-record paths, aggregator behavior and on-complete processing; maxFailedRecords considered; every nested call/branch traversed |
| try | Success plus every on-error handler/type/when alternative that can match; execute handler processors and continue/propagate behavior |
| until-successful | Success plus repeated real inner failure leading to MULE:RETRY_EXHAUSTED; do not mock the scope itself |
| cache/object store | Both hit and miss, with source-supported default/missing-key behavior and contains Boolean fixtures |
| async | Every internal path and nested handler remains in scope; observable bounded completion is required |
| global/main/APIKit handler | Every type/when alternative and every branch of each body, with a proven trigger and first-match routing |

Evaluate the full predicate with its ancestor conditions and actual producers. AND true needs all conjuncts true; OR false needs all disjuncts false. A backend-controlled branch needs a changed out/ fixture, not an arbitrary in/ field. Never preseed flow-derived vars to bypass their producers. Do not mutate forbidden configuration to force an otherwise-unreachable branch.

Batch and async return before some work completes. Read the existing application's synchronization/test facilities and use a version-compatible bounded completion mechanism. A successful HTTP response or fixed sleep alone is not proof all records or async routes finished. A failure inside a batch record does not automatically become the enclosing HTTP/main-handler error. Trace actual error propagation. If completion cannot be observed without disallowed production edits or missing tools, identify the exact obligation as blocked; do not omit the scope or claim its coverage.

All feasible obligations are required, irrespective of size. Infinite loop/path combinations are represented by finite behavior-relevant executions, not a promise of infinite enumeration. The prior minimum coverage percentage is not permission to skip branches. Track planned processor/path coverage separately from actual MUnit measured coverage. Document source/global declarations and unreachable code separately; doc:id counts are not automatically runtime processor counts. Never claim 100% without the actual report and its exclusions.

## APIKit and main error tests: cover handlers as real processing

Print `→ Planning all APIKit and main error-handler scenarios`.

**Mode B — apikit-error-test-suite.xml:** use a valid contract request, enable only the main listener, and mock the exact router to raise the registered type needed by the target APIKit handler. Match source doc:id/doc:name and config-ref where available. Execute the actual handler body and recursively mock only its external connectors. Exercise each type, when alternative, and nested body branch from the frozen handler ledger. ANY is a matcher, never an injectable error type; choose an evidenced registered type which bypasses earlier handlers. Router error injection verifies handling, not the router's real invalid-request detection. Where required, add real invalid-request scenarios separately and explicitly identify their intentional contract violations.

**Mode C — error-test-suite.xml:** for each main-handler obligation, search ALL callers and their full graphs for an actual trigger: raise-error, connector error/error-mapping, or an inner try/retry propagation. Choose a reachable HTTP anchor separately for each case. Enable that listener/public operation pair. Execute the real APIKit router and business chain. Mock upstream backends to succeed and the actual failing backend to induce the error; a status-gated raise-error needs the status/body that actually enters its branch. Never mock apikit:router as a shortcut to the main handler. APIKIT:* is not a substitute for a business error; if the main handler explicitly handles an APIKIT type, prove its real production route instead of pretending it is an APP error.

On-error-continue and on-error-propagate both need tests. Respect handler order, conditions, mappings and outer handling. Several types on one handler need their matching obligations; different body branches may require multiple tests per type. Do not mark an unreachable handler covered by adding an arbitrary mock. A blocked obligation keeps the full run incomplete; no skip-and-call-done allowance.

For both HTTP error modes add the canonical 200..599 response validator as the last request child. No expectedErrorType for errors delivered as HTTP responses. Keep four loggers and the one required assertion. Missing/null HTTP payloads that conflict with that assertion are blockers, not permission to insert a fake non-null result. Error fixtures are raw connector outputs; the application produces its own formatted error response.

## Construct and validate HTTP fixtures, then stage the two properties

Print `→ Validating and writing request and backend fixtures`.

Before ANY project WRITE, establish a valid candidate for every required fixture and its provenance:

- `in/<suite-base>-request.json`: copy the selected RAML JSON request example byte-for-byte, including its whitespace, when the source is a JSON file/literal. Validate first; never repair the base example silently. For a RAML YAML object example, JSON serialization preserves value/types but cannot be verbatim bytes: report this conflict and request a JSON example before writing under this strict contract. Missing/invalid body examples block that operation. For a contract with **no request body**, use `null` as a test-event seed and omit `<http:body>`; do not send an invented `{}` request body.
- Branch `in/` copies change only the declared fields referenced by the relevant predicates, preserving all other values and types. Diff against the base; validate effective RAML required fields, enums, types, nested items, nullability, lengths/ranges/patterns, and additionalProperties. Evaluate all predicates with the planned fixtures. No required-field deletion or invalid enum to force a business branch. Invalid request bodies are not needed for router-mock Mode B tests.
- `out/<suite-base>-<connector-slug>-<scenario>.json`: raw backend output consumed by DWL, never the final DWL result or a RAML response example. Use an evidenced backend sample/schema, or explicit constraints derived from source with a recorded derivation. The narrow exception is a response mapping whose body is exactly `payload` and whose source path proves pass-through; its RAML response example can be the backend fixture. An intermediate pass-through followed by another transform does not qualify.
- Put backend attributes fixtures in `out/` as separate `*-attributes.json` when needed; preserve scalar/array/object types. Identical proven fixtures can be reused. Do not dump credentials or model/provider metadata into any generated artifact.
- Native JSON syntax validation is mandatory, but it does not prove RAML validity. Check effective RAML semantics from the resolved contract, or use an already available local validator. If a constraint cannot be checked reliably, mark it unresolved and stop before write; do not invent a regex RAML parser.

For existing fixture files, apply the synchronization/consumer-ownership procedure; rewrite stale selected-scenario data only when all consumers remain correct. Write only candidates that pass the above gates. Re-read and JSON-parse immediately, then compare with the approved candidate and provenance. No comments, trailing commas, or unexpanded template markers in JSON.

## Copy or synchronize exactly two property files

Print `→ Comparing test property files`.

The only allowed destination files are src/test/resources/properties/app-properties-test.yaml and app-secrets-test.yaml. Resolve the unique corresponding files under src/main/resources from actual configuration references. Both must already exist. If an allowed destination is absent, copy its source bytes unchanged; if identical, skip the copy. If stale, synchronize it byte-for-byte to its proven source **only after** identifying affected test consumers and verifying this is the application's intended test configuration. A property change requires validating every affected suite; otherwise report its impact rather than silently disrupting unrelated tests. Preserve encrypted bytes and never display credentials. No dev/qa/prod variants, app-constants.yaml, app-errors.yaml or apikit-errors.yaml may be copied or created. Other pre-existing destination files are a preflight conflict; never delete them to force compliance. Compare hashes after each actual copy. On a no-op, copy nothing.


## Reconcile existing suites without losing tests

Print `→ Comparing the complete plan with existing tests`.
Snapshot existing suites/config/resources and hashes in OS temp. Match scenarios using entry method/path or direct flow, branch context, backend outcomes and handler—not doc:id alone, filename alone, or approximate mock-sequence overlap. Read current fixtures and expected behavior. A source-format-only change is not a semantic difference.

- UNCHANGED: the test still exercises the required current behavior and all required structure/configuration is already valid. Preserve bytes, identifiers, order and modification times; do not recopy properties, regenerate metadata or run a write-producing Maven command on a true no-op.
- UPDATE: repair stale source selectors, mocks, fixture references/values, configuration imports and execution details only where needed. Replace a resolved flow-ref mock with its backend mocks. Add newly required scenarios to their owning suite.
- REWRITE: replace only a selected test body whose implementation/path genuinely changed. Preserve its identity and meaningful existing assertions where compatible. Do not discard useful business assertions to satisfy the restrictive canonical format; report the conflict and request the necessary policy decision.
- MIGRATE: if selected endpoint scenarios are mixed in an old file, move those matched test elements into their owning endpoint suites, preserving their semantic coverage and custom content. Adjust only destination suite-name prefixes/necessary config references. Validate destination first, then remove just the migrated originals; do not leave duplicates. Stage the migration as a single reviewed change plan, preserve unrelated tests, and never delete the old suite file. Ambiguous ownership blocks migration.
- UNRESOLVED/OBSOLETE: preserve unmatched existing tests until ownership/intent is known. Do not delete, disable or weaken tests to obtain green results. A scenario with no current successor is reported for separate cleanup.

Trace all fixture consumers, including DWL resource readers. Update a shared fixture only when every consumer remains correct; otherwise create a stable scenario-specific copy and change only affected references. An existing all-endpoints suite does not satisfy endpoint-specific ownership without reconciliation. Older APIKit/main error suite names can be migrated using the same ownership rule to the requested apikit-error-test-suite.xml and error-test-suite.xml.

Freeze a complete change plan before APPLY. Re-read source/destination hashes before committing to avoid overwriting concurrent edits. Stage the projected full files in temp, validate them, then apply narrow changes; after every actual WRITE re-read/parse and compare to the staged candidate. Validate source-traced edits, unchanged-test preservation and all shared consumers. Do not claim no-op if a missing import, payload placeholder, endpoint suite or branch requires repair.

## XML identifiers and names

Each suite filename ends in -test-suite.xml. SUITE_BASE is its filename without .xml; every owned test name starts SUITE_BASE-. Names describe the actual branch/outcome and never contain happy-path, error-path or default-choice. Endpoint keys, not source filenames, determine HTTP ownership. Test names and global names must be unique across the selected module.

Exactly one XML declaration and one Mule root; first bytes must be <?xml with no BOM/leading whitespace. Optional generated doc:id attributes may be omitted. If present, generate lowercase valid UUIDs using `[guid]::NewGuid().ToString('D')` on Windows or `/usr/bin/uuidgen | tr '[:upper:]' '[:lower:]'` on macOS. Every generated doc:id in a file is unique and matches `^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$`. Never regenerate a source whereValue identifier to make it look like a UUID.

Use only namespaces/schema pairs needed by actual XML elements or attributes. A mock selector string such as processor="db:select" does not itself require xmlns:db. Keep actual prefixes compatible with the project's runner. XML-escape source attribute values and correctly escape DW literals. All uppercase template tokens below are placeholders to replace with verified values before WRITE.

## Canonical suite root — the import is mandatory

Use this root for a new suite; reconcile existing suites in place without adding a second declaration/root.

```xml
<?xml version="1.0" encoding="UTF-8"?>
<mule xmlns="http://www.mulesoft.org/schema/mule/core"
      xmlns:munit="http://www.mulesoft.org/schema/mule/munit"
      xmlns:munit-tools="http://www.mulesoft.org/schema/mule/munit-tools"
      xmlns:http="http://www.mulesoft.org/schema/mule/http"
      xmlns:doc="http://www.mulesoft.org/schema/mule/documentation"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
      http://www.mulesoft.org/schema/mule/munit http://www.mulesoft.org/schema/mule/munit/current/mule-munit.xsd
      http://www.mulesoft.org/schema/mule/munit-tools http://www.mulesoft.org/schema/mule/munit-tools/current/mule-munit-tools.xsd
      http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd">
    <!-- munit-generate: endpoint/handler suite v5 -->
    <munit:config name="SUITE_BASE.xml"/>
    <import file="test-config.xml" doc:name="Import"/>
    <!-- Insert fully instantiated tests here. -->
</mule>
```

Use the actual protocol/TLS requirements; the HTTP example is not a license to downgrade HTTPS. Make base-path placement explicit: either client basePath or request path, never both. Add `xmlns:doc` only if a generated element has doc:* attributes. Include connector namespace declarations/schema pairs only when actual suite elements/attributes use that namespace. A plain string such as `processor="db:select"` is a mock selector, not an XML QName requiring `xmlns:db`. Use the source prefix spelling understood by the runner; verify alternate source prefixes rather than assuming `http`.

The HTTP request config belongs in src/test/resources/test-config.xml, not the suite. A minimal NEW shared file has this shape only when its connection settings are proven. Substitute its real name/port/protocol, reuse existing properties/TLS, and do not introduce guessed defaults:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<mule xmlns="http://www.mulesoft.org/schema/mule/core"
      xmlns:http="http://www.mulesoft.org/schema/mule/http"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
      http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd">
    <http:request-config name="ACTUAL_TEST_HTTP_CONFIG">
        <http:request-connection host="127.0.0.1" port="ACTUAL_TEST_PORT" protocol="ACTUAL_PROTOCOL"/>
    </http:request-config>
</mule>
```

This file contains shared globals, not munit:test or a second suite-level munit:config. Do not duplicate production configuration-properties loaders or globals. Test property selection must be proven active, not assumed from copying YAML.

## HTTP test structures

| Mode | First-child enable-flow-sources contents | Execution/mocking |
| --- | --- | --- |
| A: operation | MAIN_LISTENER_FLOW and PUBLIC_FLOW, deduplicated if the same flow | Local HTTP request; backend connectors mocked |
| B: APIKit errors | MAIN_LISTENER_FLOW only | Local HTTP request; narrowly identified APIKit router mocked to registered error |
| C: business handler | MAIN_LISTENER_FLOW and PUBLIC_FLOW of this handler's actual entry, deduplicated | Local HTTP request; real trigger/connector error reaches business handler; never mock APIKit router |

Instantiate the block below for all three modes. Apply the table to its source list and mocks; do not generate three duplicate templates. Set-event contains only payload and is the first child of execution. Exactly four **test-owned** core INFO loggers have `message="#[payload]"`; application loggers invoked through production code do not count. Categories are literal generated names, not an assumed `${log.category.base}` property.

```xml
<munit:test name="SUITE_BASE-SCENARIO" description="EVIDENCED_SCENARIO">
    <munit:enable-flow-sources>
        <munit:enable-flow-source value="MAIN_LISTENER_FLOW"/>
        <munit:enable-flow-source value="PUBLIC_FLOW"/>
    </munit:enable-flow-sources>
    <munit:behavior>
        <!-- Insert the exact connector mocks for the complete path. -->
    </munit:behavior>
    <munit:execution>
        <munit:set-event>
            <munit:payload value="#[read(MunitTools::getResourceAsString('in/INPUT.json'), 'application/json')]" mediaType="application/json"/>
        </munit:set-event>
        <logger level="INFO" message="#[payload]" category="SUITE_BASE.execution-start"/>
        <http:request config-ref="TEST_HTTP_CONFIG" method="METHOD" path="RESOLVED_RESOURCE_PATH">
            <http:body><![CDATA[#[payload]]]></http:body>
            <!-- Add evidenced headers, uri-params, query-params in schema order. -->
        </http:request>
        <logger level="INFO" message="#[payload]" category="SUITE_BASE.execution-end"/>
    </munit:execution>
    <munit:validation>
        <logger level="INFO" message="#[payload]" category="SUITE_BASE.validation-start"/>
        <munit-tools:assert>
            <munit-tools:that><![CDATA[#[import * from dw::test::Asserts
---
payload must notBeNull()]]]></munit-tools:that>
        </munit-tools:assert>
        <logger level="INFO" message="#[payload]" category="SUITE_BASE.validation-end"/>
    </munit:validation>
</munit:test>
```

Remove `http:body` for bodyless contracts. Supply request headers/URI/query values from the contract and traced test configuration; sending HTTP creates real listener attributes. Preserve required types through the HTTP serialization boundary. Never use a flow-ref to simulate REST transport, except a raise-error scenario explicitly testing the sub-flow directly. For that exception retain the applicable REST source list, seed payload only, and classify it as a direct test with no transport coverage.

Exactly one `munit-tools:assert` with the above expression is mandatory. Do not replace it with assert-that, verify-call, or MunitTools::equalTo. This is a **non-null check**, not a response-schema/status/business-correctness assertion. Do not claim otherwise. If a valid scenario necessarily returns null, report the incompatibility instead of adding set-payload just to make this check pass.

## APIKit router error mocks

```xml
<munit-tools:mock-when processor="apikit:router">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="doc:id" whereValue="SOURCE_ROUTER_DOC_ID"/>
        <munit-tools:with-attribute attributeName="config-ref" whereValue="SOURCE_APIKIT_CONFIG"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:error typeId="REGISTERED_APIKIT_ERROR"/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

Add the actual source doc:name when present. This router wrapper belongs only in Mode B. Mode C uses a connector wrapper and its real production trigger.

### Error request addition

Every HTTP error test adds this as the LAST child of http:request:

```xml
<http:response-validator>
    <http:success-status-code-validator values="200..599"/>
</http:response-validator>
```

The validator admits error responses for validation; it does not assert the expected HTTP status. Modes B/C do not use expectedErrorType for HTTP-delivered errors.

## Canonical mocks — every returned payload comes from out/

Every `munit-tools:payload` under `munit-tools:then-return` MUST contain a literal call to `MunitTools::getResourceAsString('out/<actual-file>.json')`. The referenced file must exist and parse before the suite is committed. Use straight ASCII quotes. Never write value="payload", value="#[payload]", an inline JSON value, a dynamic path, or a placeholder instead of this call. This restriction is specific to mocked returns; execution loggers and an HTTP body may correctly use payload.

For a connector returning JSON content, instantiate:

```xml
<munit-tools:mock-when processor="SOURCE_PREFIX:OPERATION">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="doc:id" whereValue="SOURCE_DOC_ID"/>
        <munit-tools:with-attribute attributeName="doc:name" whereValue="SOURCE_DOC_NAME"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value="#[MunitTools::getResourceAsString('out/ACTUAL_BACKEND_FILE.json')]" mediaType="application/json" encoding="UTF-8"/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

If downstream code requires an already parsed Java object/array/Boolean, retain the same file call inside read; do not return a String just to match the shorter template:

```xml
<munit-tools:payload value="#[read(MunitTools::getResourceAsString('out/ACTUAL_BACKEND_FILE.json'), 'application/json')]" mediaType="application/java"/>
```

Record the observed output type and use the appropriate media type. For typed XML/binary/Java values, use evidenced decoding of a JSON-stored raw value; if it cannot be represented faithfully within the allowed fixture policy, report the blocker instead of returning an unrelated JSON object.

Then-return child order is variables → payload → attributes → error, omitting unused children according to the installed schema. Load backend attributes from a separate out/*-attributes.json when needed, using getResourceAsString plus read and the actual required attribute type. An error-only mock has only `<munit-tools:error typeId="REGISTERED_ERROR_TYPE"/>`, with no artificial success payload.

For target/targetValue connectors, read the runtime/version's actual mocking semantics and existing working tests. If the mock must populate the target variable explicitly, derive its value from the out/ fixture and evaluated targetValue in then-return variables; OMIT the payload element to preserve the original event. Do not insert `#[payload]` to preserve it. If that runtime applies target assignment itself, return the raw connector result instead. Do not apply both strategies blindly. Variables supplied by mocks must come from real target/output semantics, not shortcuts around production set-variable processors.

### Object-store cases

- retrieve hit: return the actual stored value from out/<cache-hit>.json, typed for its consumer.
- retrieve miss: return the evidenced defaultValue fixture, or the connector's registered missing-key error when no default applies.
- contains: out/<contains>.json contains Boolean true or false; use the parsed Java-value form.
- store/remove with proven event-preserving semantics: use an empty then-return; no payload element is needed. Do not invent a result or a live store operation.

Mock every external operation on the COMPLETE test path, not just inside its final branch. Only a whole-path search proving zero mockable backends permits behavior containing exactly `<!-- B16-exception: provably empty branch -->`. Never add a meaningless mock to meet a count.

## Required checks before WRITE, after each WRITE, and before completion

Print `→ Checking every expected suite, mock fixture, import and coverage obligation`.
The full endpoint/entry and handler inventory must be frozen from source BEFORE constructing tests. Do not regenerate the expected inventory from the files you happened to write. Stage a projected final tree in OS temp, including existing unchanged selected suites/resources, and apply these gates there before copying changes into the application. Re-run against actual destinations after each write/complete batch.

| Reject | Auto-fix or required resolution |
| --- | --- |
| Missing endpoint/entry suite, duplicate ownership, zero-test placeholder, absent planned scenario | Finish its source-traced tests; E endpoint rows must match E owning suites, excluding handlers; never reduce E to the produced count |
| Missing handler/type/when/body branch or skipped unresolved call | Complete its trigger and nested processing or report incomplete; no silent skip allowance |
| Absent/duplicate test-config import or inline HTTP client config in a suite | Add exactly one core import file="test-config.xml"; reconcile shared config and every config-ref; retain the separate suite munit:config |
| Any then-return payload lacking MunitTools::getResourceAsString('out/<literal>.json'), including value="payload" or value="#[payload]" | Create/reuse the proper raw backend fixture and use the canonical call, optionally decoded by read; event-preserving operations omit payload instead |
| Missing/malformed/wrong-case fixture or wrong JSON root type | Reconstruct from source contract/DWL/backend constraints, parse and verify all consumers; no generic fake {} replacement |
| Mock selector not verbatim on the same current source processor or matching multiple calls | Read the actual element and narrow doc:id/doc:name/config selectors; do not mock the test HTTP client |
| A resolved flow-ref, scope, handler, transform or logger mocked | Replace with real recursive execution plus backend mocks |
| mock-when outside behavior; then-return children out of order | Move to behavior; enforce variables, payload, attributes, error for present children |
| Empty behavior without proof | Search the entire path; add real mocks, or the B16-exception comment only for a provably connector-free path |
| Invalid XML/BOM/multiple roots/duplicate or invalid generated IDs/unused namespaces | Repair serialization/IDs/declarations; source matching values remain unchanged |
| Wrong test prefix, forbidden test names, duplicate test/config identities | Use the actual owning suite prefix and unique scenario identity |
| Wrong HTTP source list or enable-flow-sources not first | Instantiate A/B/C mode with current source flow names and correct first-child ordering |
| set-event not first execution child; REST attributes/variables seeded there | Restore first-child set-event with payload only; let real HTTP/production code produce attributes/vars |
| Not four test-owned INFO payload loggers or not exactly the canonical one assert | Restore the generated template; preserve useful existing checks or report the policy conflict, never silently weaken them |
| assert-that, verify-call, MunitTools::equalTo | Prohibited in generated tests; use the canonical assertion, not a renamed equivalent |
| Error HTTP request without final 200..599 validator | Add it last; no expectedErrorType for HTTP-delivered errors |
| Invalid RAML base example/branch constraints or wrong DWL data origin | Correct from evidence before write; non-HTTP inputs require their producer analysis |
| More/different test property filenames or altered copied content | Copy only the two source test YAMLs byte-for-byte; unrelated pre-existing files are a conflict, never silently deleted |
| Unproven async/batch completion or coverage based only on planned mocks | Obtain a supported completion signal and actual report, otherwise report the unresolved obligation |
| Unexpanded templates, invented source values or generation metadata | Substitute verified values and remove labels not part of the actual application |

### Native file-validation commands

Use namespace-aware XML parsing; no dependency installation. PowerShell writes XML with `[IO.File]::WriteAllText(path, text, (New-Object Text.UTF8Encoding($false)))`, never its BOM-producing default UTF8 writer. Check every generated doc:id with the UUID regex and uniqueness set. Parse JSON using `ConvertFrom-Json -ErrorAction Stop`; compare YAML bytes/hashes with Get-FileHash. macOS uses xmllint --nonet after rejecting DOCTYPE, od for initial bytes, cmp for exact copies, and the system JSON parser below. XML parsing is not MUnit XSD validation or runtime execution.

The embedded regression gate below specifically catches the reported missing-suite/import/mock-payload defects. It complements, not replaces, the semantic gates above. Its manifest `expected-suites.txt` is a UTF-8, one-relative-suite-path-per-line inventory created from the frozen endpoint/entry/handler table, not from existing filenames. Paths are module-relative under src/test/munit, use forward slashes, and are unique. Run with CHECK_ROOT pointing first to the staged projected module and then the actual module. Put the manifest and any temporary script only in OS temp. Run all suites in the manifest; do not sample one.

#### Windows inventory/import/mock gate

Run this literal block after substituting the two resolved absolute paths. It reads only; nonzero/throw means fix the candidate and run again.

```powershell
$ErrorActionPreference = 'Stop'
$checkRoot = 'ABSOLUTE_PROJECTED_OR_REAL_MODULE'
$manifestPath = 'ABSOLUTE_TEMP_EXPECTED_SUITES_TXT'
$utf8Strict = New-Object Text.UTF8Encoding($false, $true)
$coreUri = 'http://www.mulesoft.org/schema/mule/core'
$testUri = 'http://www.mulesoft.org/schema/mule/munit'
$toolsUri = 'http://www.mulesoft.org/schema/mule/munit-tools'
$httpUri = 'http://www.mulesoft.org/schema/mule/http'
$rows = @([IO.File]::ReadAllLines($manifestPath, $utf8Strict))
if ($rows.Count -eq 0) { throw 'Expected suite inventory is empty' }
$seenSuites = @{}
$settings = New-Object Xml.XmlReaderSettings
$settings.DtdProcessing = [Xml.DtdProcessing]::Prohibit
$settings.XmlResolver = $null
foreach ($rel in $rows) {
    if ($rel -notmatch '^src/test/munit/[a-z0-9][a-z0-9/-]*-test-suite\.xml$' -or
        $rel.Contains('..') -or $seenSuites.ContainsKey($rel)) { throw "Invalid/duplicate inventory row: $rel" }
    $seenSuites[$rel] = $true
    $suitePath = Join-Path $checkRoot $rel
    if (-not (Test-Path -LiteralPath $suitePath -PathType Leaf)) { throw "Missing expected suite: $rel" }
    $raw = [IO.File]::ReadAllText($suitePath, $utf8Strict)
    $bytes = [IO.File]::ReadAllBytes($suitePath)
    if ($bytes.Length -lt 5 -or [Text.Encoding]::ASCII.GetString($bytes, 0, 5) -cne '<?xml' -or
        [regex]::Matches($raw, '<\?xml\s').Count -ne 1) { throw "Invalid XML start/declaration: $rel" }
    $reader = [Xml.XmlReader]::Create($suitePath, $settings)
    $xml = New-Object Xml.XmlDocument
    $xml.XmlResolver = $null
    try { $xml.Load($reader) } finally { $reader.Dispose() }
    $ns = New-Object Xml.XmlNamespaceManager($xml.NameTable)
    $ns.AddNamespace('c', $coreUri); $ns.AddNamespace('m', $testUri)
    $ns.AddNamespace('t', $toolsUri); $ns.AddNamespace('h', $httpUri)
    if ($xml.SelectNodes('/c:mule', $ns).Count -ne 1 -or
        $xml.SelectNodes('/c:mule/c:import[@file="test-config.xml"]', $ns).Count -ne 1 -or
        $xml.SelectNodes('/c:mule/m:config', $ns).Count -ne 1 -or
        $xml.SelectNodes('/c:mule/m:test', $ns).Count -eq 0) { throw "Missing root/import/config/tests: $rel" }
    if ($xml.SelectNodes('//h:request-config', $ns).Count -ne 0) { throw "HTTP client config must be in test-config.xml: $rel" }
    $base = [IO.Path]::GetFileNameWithoutExtension($suitePath)
    $names = @{}
    foreach ($test in $xml.SelectNodes('/c:mule/m:test', $ns)) {
        $name = $test.GetAttribute('name')
        if (-not $name.StartsWith($base + '-', [StringComparison]::Ordinal) -or
            $name -match 'happy-path|error-path|default-choice' -or $names.ContainsKey($name)) { throw "Invalid test name: $name" }
        $names[$name] = $true
    }
    foreach ($payloadNode in $xml.SelectNodes('//t:then-return/t:payload', $ns)) {
        $value = $payloadNode.GetAttribute('value')
        $matches = [regex]::Matches($value, "MunitTools::getResourceAsString\('(?<resource>out/[^'`"<>\r\n]+\.json)'\)")
        if ($matches.Count -ne 1 -or -not $value.StartsWith('#[') -or -not $value.EndsWith(']')) { throw "Mock payload must load exactly one literal out JSON resource: $rel" }
        $resource = $matches[0].Groups['resource'].Value
        if ($resource.Contains('\') -or $resource -match '(^|/)\.\.(/|$)|//' ) { throw 'Invalid mock resource path' }
        $jsonPath = Join-Path (Join-Path $checkRoot 'src/test/resources') $resource
        if (-not (Test-Path -LiteralPath $jsonPath -PathType Leaf)) { throw "Missing mock resource: $resource" }
        $jsonText = [IO.File]::ReadAllText($jsonPath, $utf8Strict)
        if ([string]::IsNullOrWhiteSpace($jsonText)) { throw "Empty JSON resource: $resource" }
        $null = ConvertFrom-Json -InputObject $jsonText -ErrorAction Stop
    }
    Write-Output ('Structural gate passed: ' + $rel)
}
```

#### macOS inventory/import/mock gate

Use /bin/bash. This block uses the system XML parser and archive-independent file commands only. The separate JSON check below must also run on each fixture; shell/XML inspection does not validate JSON semantics.

```bash
set -euo pipefail
check_root='ABSOLUTE_PROJECTED_OR_REAL_MODULE'
manifest_path='ABSOLUTE_TEMP_EXPECTED_SUITES_TXT'
core_uri='http://www.mulesoft.org/schema/mule/core'
test_uri='http://www.mulesoft.org/schema/mule/munit'
tools_uri='http://www.mulesoft.org/schema/mule/munit-tools'
http_uri='http://www.mulesoft.org/schema/mule/http'
test -s "$manifest_path" || { echo 'Expected suite inventory is empty' >&2; exit 1; }
/usr/bin/awk '
  !/^src\/test\/munit\/[a-z0-9][a-z0-9\/-]*-test-suite\.xml$/ || /\.\./ {bad=1}
  {if (seen[$0]++) bad=1} END {exit bad ? 1 : 0}' "$manifest_path" || { echo 'Invalid/duplicate inventory row' >&2; exit 1; }
while IFS= read -r rel || test -n "$rel"; do
  suite_path="$check_root/$rel"
  test -f "$suite_path" || { echo "Missing expected suite: $rel" >&2; exit 1; }
  start=$(/usr/bin/od -An -tx1 -N5 "$suite_path" | /usr/bin/tr -d ' \n')
  test "$start" = '3c3f786d6c' || { echo "Invalid XML start: $rel" >&2; exit 1; }
  if /usr/bin/grep -qi '<!DOCTYPE' "$suite_path"; then echo 'DOCTYPE is forbidden' >&2; exit 1; fi
  /usr/bin/xmllint --nonet --noout "$suite_path"
  root="/*[local-name()='mule' and namespace-uri()='$core_uri']"
  imports="$root/*[local-name()='import' and namespace-uri()='$core_uri' and @file='test-config.xml']"
  configs="$root/*[local-name()='config' and namespace-uri()='$test_uri']"
  tests="$root/*[local-name()='test' and namespace-uri()='$test_uri']"
  clients="//*[local-name()='request-config' and namespace-uri()='$http_uri']"
  ok=$(/usr/bin/xmllint --nonet --xpath "count($root)=1 and count($imports)=1 and count($configs)=1 and count($tests)>0 and count($clients)=0" "$suite_path")
  test "$ok" = 'true' || { echo "Missing root/import/config/tests or inline HTTP config: $rel" >&2; exit 1; }
  base=${rel##*/}; base=${base%.xml}
  names_ok=$(/usr/bin/xmllint --nonet --xpath "count($tests[not(starts-with(@name,'$base-')) or contains(@name,'happy-path') or contains(@name,'error-path') or contains(@name,'default-choice') or @name=preceding-sibling::*[local-name()='test' and namespace-uri()='$test_uri']/@name])=0" "$suite_path")
  test "$names_ok" = 'true' || { echo "Invalid/duplicate test name: $rel" >&2; exit 1; }
  payloads="//*[local-name()='then-return' and namespace-uri()='$tools_uri']/*[local-name()='payload' and namespace-uri()='$tools_uri']"
  count=$(/usr/bin/xmllint --nonet --xpath "count($payloads)" "$suite_path")
  i=1
  while test "$i" -le "$count"; do
    value=$(/usr/bin/xmllint --nonet --xpath "string(($payloads)[$i]/@value)" "$suite_path")
    case "$value" in '#['*']') ;; *) echo "Invalid mock payload expression: $rel" >&2; exit 1 ;; esac
    resource=$(printf '%s\n' "$value" | /usr/bin/sed -nE "s/.*MunitTools::getResourceAsString\('(out\/[^'\"<>]+\.json)'\).*/\1/p")
    call_count=$(printf '%s\n' "$value" | /usr/bin/awk '{n+=gsub(/MunitTools::getResourceAsString\(/,"&")} END{print n+0}')
    test "$call_count" = 1 && test -n "$resource" || { echo "Mock payload must load one literal out JSON resource: $rel" >&2; exit 1; }
    case "$resource" in *\\*|*'/../'*|*'//'*|*$'\n'*|*$'\r'*) echo 'Invalid mock resource path' >&2; exit 1 ;; esac
    test -f "$check_root/src/test/resources/$resource" || { echo "Missing mock resource: $resource" >&2; exit 1; }
    i=$((i + 1))
  done
  printf 'Structural gate passed: %s\n' "$rel"
done < "$manifest_path"
```

The manifest gate intentionally does not count unrelated old suites. Independently prove each required endpoint key owns the corresponding tests and that all required handler/processor obligations are represented. Check literal fixture filename casing on both platforms even when the filesystem permits case-insensitive lookup.

Use this native macOS JSON check for each candidate and written fixture; supply its actual path as the argument. A successful parse validates syntax only, so the RAML and provenance gates still apply.

```bash
/usr/bin/osascript -l JavaScript - 'ABSOLUTE_JSON_PATH' <<'JXA'
ObjC.import('Foundation');
function run(argv) {
    var text = $.NSString.stringWithContentsOfFileEncodingError(argv[0], $.NSUTF8StringEncoding, null);
    if (!text) throw new Error('Unable to read UTF-8 JSON');
    JSON.parse(ObjC.unwrap(text));
    return 'JSON syntax passed';
}
JXA
```

### Final semantic and execution gate

Compare the source-derived ledger to actual test names, route method/path/public flows, predicates, mock outcomes and handler triggers. Presence of a suite or a file-backed mock alone is insufficient. Verify all JSON syntax and contract/DWL constraints, every source selector, UUID uniqueness, exactly the two YAMLs and import/config resolution. Preserve unrelated hashes and unchanged selected tests.

Run the existing project's offline MUnit test command/profiles when available and changes required a write; inspect the command first so no deploy/live backend activity is triggered. Use an already provisioned Maven executable, no clean, automatic wrapper bootstrap, downloads or POM edits. Run each new/config-changed suite alone and the combined selected suites to catch import/global collisions. Read actual failures, skips and coverage exclusions. Fix defects in generated/updated tests and rerun affected tests. A true no-op performs no project-write-producing test command and says runtime not run.

Native/static checks cannot prove runtime validity. If no runtime/schema check can execute, state `generated; runtime not run; coverage unmeasured`, not `all tests passed`. If any required endpoint/processor/branch/handler remains blocked, the final state is incomplete, even if other suites were written successfully. Never label a valid archive extraction, non-null assertion or XML parse as proof of full application coverage.

## Progress and final output

Before each step print `→ <plain action line>`. After each complete generated/reconciled suite print `✅ Done: <filename> (<N> tests; <A> added, <U> updated, <M> migrated)`. On a true no-op print `✅ Unchanged: <filename> (<N> tests; 0 changes)`. Done means the file passed generation checks; always report runtime separately.

Finally print the COMPLETE endpoint/entry → suite → test-count → generation/runtime status table, plus each handler suite's required/completed obligation counts. Reconcile planned keys, not only numbers. List remaining blockers with source location and missing evidence. Preserve the temporary ledger across interruption, recheck source changes on resumption, and continue through every remaining endpoint; never return after one suite simply because it was the first discovered.

`Summary: <generated | unchanged | incomplete>; endpoints/entries <ready>/<required>; handler obligations <ready>/<required>; suites <ready>/<required>; tests <total>; runtime <passed | failed | not run>; coverage <actual result | unmeasured>; blockers <list or none>.`
