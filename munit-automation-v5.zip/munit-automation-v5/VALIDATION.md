# Version 5 validation record

Validated locally on macOS on 13 September 2026. The synthetic files used here test the package and structural gates; they are not a generated suite for your application. The other system where you reported failures was not accessed.

## Passed

- Metadata, model-unpinned headers, independent worker files and balanced fences
- Native macOS Prompt/Skill installation, no-op, backup, missing-source and symlink checks
- All embedded Bash blocks pass syntax checks
- Six-suite manifest accepted: three endpoints, two error suites, one non-HTTP entry
- HTTP A/B/C and non-HTTP assembled templates parse and meet checked structure
- Shared test-config template parses and suite roots contain imports, no inline clients
- Rejects bare mock payload
- Rejects event-payload mock
- Rejects inline mock object
- Rejects wrong in/ mock resource
- Rejects missing mock JSON
- Rejects missing import
- Rejects duplicate import
- Rejects inline HTTP configuration
- Rejects empty endpoint suite
- Rejects wrong test-name prefix
- Rejects BOM
- Rejects one missing endpoint while all other suites exist
- Rejects duplicate expected-suite inventory rows
- Native RAML extraction accepts nested valid archive and rejects missing, corrupt, traversal and case-colliding archives
- Native macOS JSON parser accepts object/null and rejects malformed JSON

## Not verified

- Windows PowerShell execution (installer, extraction, gate)
- Actual VS Code slash-command discovery and agent adherence
- APIKit endpoint discovery and synchronization on a real Mule application
- MUnit XSD/runtime, DataWeave evaluation, batch/async completion and measured coverage

## How to interpret these results

The missing-endpoint regression uses a frozen six-suite manifest: three endpoint suites, two handler suites and one non-HTTP entry suite. Removing one endpoint file causes the embedded macOS gate to fail even though every other file exists. This proves the gate detects a missing file relative to its inventory; it does not prove an agent will correctly discover every real APIKit mapping. The independent source-derived endpoint and path ledgers remain mandatory.

The mock regressions distinguish forbidden mock-return payload expressions from legitimate execution payload loggers and HTTP bodies. Both direct getResourceAsString calls and the typed read wrapper are specified in the prompt. The native gate is a structural check, not DataWeave execution or proof of backend type fidelity.

The import regressions check that every suite contains exactly one test-config.xml import and no inline HTTP client config. Import resolution and duplicate-global behavior still require the actual Mule runtime, including isolated-suite and combined-suite execution.

XML templates were assembled from the delivered Markdown with synthetic names and parsed. Checks covered one assertion, four loggers, execution set-event ordering, HTTP source enable ordering, error response validators and non-HTTP direct invocation. No MUnit XSD or Mule test runner was executed.

The commands use native platform facilities, but no extraction command can guarantee success for missing, corrupt, unsafe or inaccessible input. Tested failures stopped rather than producing application output. PowerShell blocks require Windows validation before a cross-platform runtime-success claim.
