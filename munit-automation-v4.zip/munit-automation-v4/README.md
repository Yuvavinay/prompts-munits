# MUnit prompt files — version 4

This version implements your revised architecture. The router **only classifies and dispatches**. Each worker is self-contained and includes its own native commands, input rules, mocks, test templates, existing-test synchronization and validation. The workers do not load the router or any shared helper. Common correctness rules are repeated inside the two workers so either can run independently; only the selected worker is loaded during a single-source invocation.

| Prompt file | Responsibility |
| --- | --- |
| [munit-generate.prompt.md](munit-generate.prompt.md) | Detect HTTP/non-HTTP entry sources and dispatch |
| [munit-http-listener.prompt.md](munit-http-listener.prompt.md) | Recursive XML selection, local RAML, HTTP tests and existing-test synchronization |
| [munit-non-http-listener.prompt.md](munit-non-http-listener.prompt.md) | Recursive XML/DWL analysis, DWL-derived entry inputs, external mocks and existing-test synchronization |

## Usage

```text
/munit-generate all
/munit-generate orders.xml
/munit-generate orders.xml,customers.xml
/munit-http-listener src/main/mule/operations/orders.xml,src/main/mule/operations/customers.xml
/munit-non-http-listener scheduler.xml,mq-subscriber.xml
```

`errors` is also supported. Use quoted paths when a filename includes spaces or commas. Basenames must resolve uniquely anywhere under the module's source tree. A missing/ambiguous list member stops writes; the agent never quietly processes only part of the requested list. Dependencies and reverse callers are resolved recursively even when their files were not explicitly listed. A mixed-source selection is dispatched to both workers with planning before writes.

## Existing tests

This version supersedes version 3's additive-only restriction. If the implementation and MUnit tests are in sync, the run makes no project writes. If not, it updates stale mock selectors, fixture contents/references, connector outcomes and execution details, or rewrites only the affected test body. Missing scenarios get new tests. Names and valid test IDs are preserved when possible; unrelated and unchanged tests stay untouched. Shared fixtures use consumer-aware updates or a new scenario copy. The agent does not rebuild a whole suite to repair one test, disable failing tests, or delete unrelated tests. A removed scenario with no valid successor is reported for a separate cleanup decision.

Example: orders.xml has a new backend call and its existing mock doc:id changed. The existing order test is updated with the current selector and backend mock; it is not left blocked by the previous additive-only policy. Rerun the command with the same source and it should report Unchanged.

## Non-HTTP input source

DWL plus its producing flow is the input authority. The worker follows inline/resource mappings, custom modules, variables and backend targets to distinguish entry data from connector results. The source message goes to in/; raw backend results consumed by a later transform go to out/. A scheduler that starts with a database query usually has a null entry seed; the query response belongs in out/, even if a subsequent DWL reads it as payload.

Selectors, typed inputs, predicates, defaults and coercions provide constraints, but arbitrary DWL is not always a complete source-message schema. The prompt records what is inferred and requests missing essential evidence instead of inventing business fields. [DataWeave selectors](https://docs.mulesoft.com/dataweave/2.4/dataweave-selectors), [DataWeave precedence and coercion operators](https://docs.mulesoft.com/dataweave/2.3/dataweave-flow-control-precedence)

## One-time installation — commands enclosed below

Extract this package outside your Mule project. Open a terminal **in this extracted directory**, where all three .prompt.md files are present. The blocks below contain the complete installers; there is no .ps1/.sh helper to download or run. They validate all three files first, back up changed installed definitions, skip identical definitions and write no application files. No administrator rights, new extension or dependency is required by these installers.

Default mode below is **Prompt**, using the VS Code Local agent's user-profile prompt directory. Select Agent and Auto in the sidebar after installation; no model is pinned in the files. Current VS Code documentation says Agent Host sessions do not load prompt files: for that session type, change the final PowerShell `-Format Prompt` to `-Format Skill`, or the first Bash `--format prompt` to `--format skill`. The same Markdown bodies are installed as personal SKILL.md files, with router links adjusted. [VS Code prompt-file documentation](https://code.visualstudio.com/docs/agent-customization/prompt-files)

Keep one active format per command. If version 3 is already installed in Skill format, use Skill here to update it in place, or relocate the old installed definitions before switching formats. Updates affect prompt definitions; synchronization of application tests occurs only when the command is invoked in the application workspace.

### Windows: paste into Windows PowerShell 5.1

This is a pasted command block; it does not need a persisted script or execution-policy change. Default Prompt destination is %APPDATA%\Code\User\prompts; Skill uses %USERPROFILE%\.copilot\skills. For a named/custom profile, append `-Destination 'ABSOLUTE_DIRECTORY'` after the closing script block arguments. Skill destination is the parent skills directory; Prompt destination is the prompt directory itself.

```powershell
& {
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [ValidateSet('Skill', 'Prompt')][string]$Format = 'Prompt',
    [string]$Destination,
    [switch]$Update
)
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false, $true)
$userRoot = [Environment]::GetFolderPath('UserProfile')
if (-not $userRoot) { throw 'Cannot resolve user profile.' }
$skillRoot = Join-Path $userRoot '.copilot/skills'
if ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) {
    $promptRoot = Join-Path ([Environment]::GetFolderPath('ApplicationData')) 'Code\User\prompts'
} else {
    $promptRoot = Join-Path $userRoot 'Library/Application Support/Code/User/prompts'
}
$useDefault = [string]::IsNullOrWhiteSpace($Destination)
if ($useDefault) {
    if ($Format -eq 'Skill') { $Destination = $skillRoot } else { $Destination = $promptRoot }
}
$Destination = [IO.Path]::GetFullPath($Destination)
# Preflight all three files before any destination write; publish router last.
$names = @('munit-http-listener', 'munit-non-http-listener', 'munit-generate')
$plan = @()
foreach ($name in $names) {
    $source = Join-Path (Get-Location).Path ($name + '.prompt.md')
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing bundled file: $source" }
    $text = [IO.File]::ReadAllText($source, $utf8).Replace("`r`n", "`n")
    $match = [regex]::Match($text, '\A---\n(?<header>.*?)\n---\n(?<body>[\s\S]*)\z', 'Singleline')
    if (-not $match.Success) { throw "Invalid frontmatter: $source" }
    $header = $match.Groups['header'].Value
    if ($header -notmatch ("(?m)^name: '" + [regex]::Escape($name) + "'$") -or
        $header -notmatch "(?m)^version: '4\.0\.0'$") { throw "Mismatched name/version: $source" }
    if ($Format -eq 'Skill') {
        $lines = @('---') + @($header -split "`n" | Where-Object { $_ -match '^(name|description):' })
        $lines += @('metadata:', "  version: '4.0.0'", '---')
        $body = [regex]::Replace($match.Groups['body'].Value, '\((munit-[a-z-]+)\.prompt\.md\)', '(../$1/SKILL.md)')
        $text = ($lines -join "`n") + "`n" + $body
        $target = Join-Path (Join-Path $Destination $name) 'SKILL.md'
        $other = Join-Path $promptRoot ($name + '.prompt.md')
    } else {
        $target = Join-Path $Destination ($name + '.prompt.md')
        $other = Join-Path (Join-Path $skillRoot $name) 'SKILL.md'
    }
    if ($useDefault -and (Test-Path -LiteralPath $other)) {
        throw "Other command format exists at $other. Keep one active format; relocate it before switching."
    }
    $changed = $true
    if (Test-Path -LiteralPath $target) {
        $item = Get-Item -LiteralPath $target
        if ($item.PSIsContainer -or (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
            throw "Destination is not a regular file: $target"
        }
        $changed = [IO.File]::ReadAllText($target, $utf8) -cne $text
        if ($changed -and -not $Update) { throw "Existing content differs: $target. Use -Update to preserve a backup and replace the installed skill." }
    }
    $plan += [pscustomobject]@{ Path = $target; Text = $text; Changed = $changed }
}
if (-not ($plan | Where-Object { $_.Changed })) {
    Write-Output 'All three commands are already installed; no changes.'
    return
}
if (-not $PSCmdlet.ShouldProcess($Destination, 'Install the three MUnit command files')) { return }
foreach ($entry in $plan) {
    if (-not $entry.Changed) { Write-Output "Unchanged: $($entry.Path)"; continue }
    $directory = [IO.Path]::GetDirectoryName($entry.Path)
    [IO.Directory]::CreateDirectory($directory) | Out-Null
    $stage = Join-Path $directory ('.munit-install-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [IO.File]::WriteAllText($stage, $entry.Text, $utf8)
        if ([IO.File]::ReadAllText($stage, $utf8) -cne $entry.Text) { throw 'Staged verification failed.' }
        if (Test-Path -LiteralPath $entry.Path) {
            $backup = $entry.Path + '.backup-' + [guid]::NewGuid().ToString('N')
            [IO.File]::Replace($stage, $entry.Path, $backup)
            Write-Output "Backup: $backup"
        } else { [IO.File]::Move($stage, $entry.Path) }
        if ([IO.File]::ReadAllText($entry.Path, $utf8) -cne $entry.Text) { throw 'Installed verification failed.' }
        Write-Output "Installed: $($entry.Path)"
    } finally {
        if (Test-Path -LiteralPath $stage -PathType Leaf) { [IO.File]::Delete($stage) }
    }
}
Write-Output 'Reload VS Code if needed. Select Agent and Auto; run /munit-generate all.'
Write-Output 'This installer updates skill definitions only. Selected application tests are synchronized using the worker prompts.'
} -Format Prompt -Update
```

### macOS: paste into Terminal

PowerShell is not built into macOS; this block uses its system Bash and native utilities. Default Prompt destination is ~/Library/Application Support/Code/User/prompts; Skill uses ~/.copilot/skills. Add `--destination 'ABSOLUTE_DIRECTORY'` to the first line for a different profile.

```bash
/bin/bash -s -- --format prompt --update <<'MUNIT_INSTALL'
set -euo pipefail
format=prompt
destination=''
update=false
while [ "$#" -gt 0 ]; do
    case "$1" in
        --format) [ "$#" -ge 2 ] || exit 2; format=$2; shift 2 ;;
        --destination) [ "$#" -ge 2 ] && [ -n "$2" ] || exit 2; destination=$2; shift 2 ;;
        --update) update=true; shift ;;
        --help) echo 'Usage: /bin/bash install-munit-command.sh [--format skill|prompt] [--destination DIRECTORY] [--update]'; exit 0 ;;
        *) echo "Unknown argument: $1" >&2; exit 2 ;;
    esac
done
case "$format" in skill|prompt) ;; *) echo 'Format must be skill or prompt' >&2; exit 2 ;; esac
bundle=$PWD
skill_root="$HOME/.copilot/skills"
prompt_root="$HOME/Library/Application Support/Code/User/prompts"
use_default=false
if [ -z "$destination" ]; then
    use_default=true
    if [ "$format" = skill ]; then destination=$skill_root; else destination=$prompt_root; fi
fi
stage_dir=$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/munit-install.XXXXXXXX")
target_stage=''
cleanup() {
    /bin/rm -f -- "$stage_dir/munit-http-listener" "$stage_dir/munit-non-http-listener" "$stage_dir/munit-generate"
    /bin/rmdir -- "$stage_dir"
    if [ -n "$target_stage" ]; then /bin/rm -f -- "$target_stage"; fi
}
trap cleanup EXIT
names=(munit-http-listener munit-non-http-listener munit-generate)
targets=()
changes=()
# Preflight all three destinations before publishing any file; router is last.
for name in "${names[@]}"; do
    source="$bundle/$name.prompt.md"
    [ -f "$source" ] || { echo "Missing bundled file: $source" >&2; exit 1; }
    /usr/bin/awk -v expected="$name" '
      NR == 1 {if ($0 != "---") bad=1; next}
      !closed && $0 == "---" {closed=1; next}
      !closed && $0 == "name: '\''" expected "'\''" {name_ok=1}
      !closed && $0 == "version: '\''4.0.0'\''" {version_ok=1}
      END {if (bad || !closed || !name_ok || !version_ok) exit 1}
    ' "$source" || { echo "Invalid bundled name/version: $source" >&2; exit 1; }
    if [ "$format" = skill ]; then
        target="$destination/$name/SKILL.md"
        other="$prompt_root/$name.prompt.md"
        /usr/bin/awk '
          NR == 1 {print; next}
          !closed && $0 == "---" {print "metadata:"; print "  " version; print "---"; closed=1; next}
          !closed {if ($0 ~ /^(name|description):/) print; if ($0 ~ /^version:/) version=$0; next}
          {print}
        ' "$source" | /usr/bin/sed -E 's@\((munit-[a-z-]+)\.prompt\.md\)@(../\1/SKILL.md)@g' > "$stage_dir/$name"
    else
        target="$destination/$name.prompt.md"
        other="$skill_root/$name/SKILL.md"
        /bin/cp -- "$source" "$stage_dir/$name"
    fi
    if [ "$use_default" = true ] && [ -e "$other" ]; then
        echo "Other command format exists at $other. Keep one active format; relocate it before switching." >&2; exit 1
    fi
    if [ -L "$target" ] || { [ -e "$target" ] && [ ! -f "$target" ]; }; then
        echo "Destination is not a regular file: $target" >&2; exit 1
    fi
    changed=true
    if [ -f "$target" ]; then
        if /usr/bin/cmp -s "$target" "$stage_dir/$name"; then changed=false
        elif [ "$update" = false ]; then
            echo "Existing content differs: $target. Use --update to preserve a backup and replace the installed skill." >&2; exit 1
        fi
    fi
    targets+=("$target")
    changes+=("$changed")
done
for ((i=0; i<${#names[@]}; i++)); do
    target=${targets[$i]}
    if [ "${changes[$i]}" = false ]; then echo "Unchanged: $target"; continue; fi
    directory=$(dirname -- "$target")
    /bin/mkdir -p -- "$directory"
    target_stage=$(/usr/bin/mktemp "$directory/.munit-install.XXXXXXXX")
    /bin/cp -- "$stage_dir/${names[$i]}" "$target_stage"
    /usr/bin/cmp -s "$target_stage" "$stage_dir/${names[$i]}"
    if [ -f "$target" ]; then
        backup="$target.backup-$(/usr/bin/uuidgen)"
        /bin/cp -p -- "$target" "$backup"
        echo "Backup: $backup"
    fi
    /bin/mv -f -- "$target_stage" "$target"
    target_stage=''
    /usr/bin/cmp -s "$target" "$stage_dir/${names[$i]}"
    echo "Installed: $target"
done
echo 'Reload VS Code if needed. Select Agent and Auto; run /munit-generate all.'
echo 'This installer updates skill definitions only. Selected application tests are synchronized using the worker prompts.'
MUNIT_INSTALL
```

Reload VS Code if the slash commands are not listed; inspect Chat: Open Customizations. In remote sessions install on the host where the agent reads its prompts/skills. Normal editor tool approvals remain in effect.

## Preconditions and validation limits

HTTP extraction needs the POM-declared RAML and its fragments already in the effective local Maven repository. It uses native Windows/macOS archive commands and never downloads a substitute. Missing HTTP RAML stops the entire selected run before project writes. Pure non-HTTP runs skip RAML and derive fixtures from DWL/flow evidence.

Both routes retain the existing compatible Mule 4/MUnit 2.x/Java/Maven prerequisite, exact two test-property files, source-traced mocks and requested XML conventions. Test execution uses only an already provisioned offline toolchain; no POM/dependency changes are made. The specified non-null assertion checks payload presence only, not response correctness. Source flow names tracing to api.xml remains the requested HTTP project-specific gate; other layouts are reported rather than silently renamed.

Package validation checks native macOS installation, link/metadata conversion, no-op/update behavior, recursive-discovery examples and assembled XML structures. Windows execution, actual VS Code sidebar discovery, agent-generated reconciliation against a real Mule application, DataWeave evaluation and measured MUnit coverage remain unverified here. The prompts must report runtime not run / coverage unmeasured when those checks are unavailable. No failure-free guarantee is made for unknown applications.
