# MUnit automation — portable context

Current release: **12.0.0**. Target: existing VS Code chat with GitHub Copilot, Agent selected and Auto or the user's current model. No model/provider is pinned. This package creates reusable prompt instructions for Mule 4/MUnit 2.x; no target Mule application was supplied, accessed or run here.

## Authoritative files

Use only the three current definitions in munit-automation-v12/: munit-generate.prompt.md, munit-http-listener.prompt.md, munit-non-http-listener.prompt.md. README.md contains installation/update commands; VALIDATION.md states what was checked. The final ZIP contains these five files and this context. All execution commands are embedded in the worker Markdown. There is no external helper dependency or separate refresh prompt.

The latest user explicitly requested shorter, polished files and prohibited macOS-specific checks on this system. This revision used **52 Python-standard-library authoring/synthetic checks only**, with no native/macOS/PowerShell/installer/VS Code/Mule execution. Earlier version counts must not be presented as this release's runtime validation.

## Correct architecture and main RAML selection

1. Generic router does only read-only production source detection and immediately loads the HTTP worker when an actual inbound HTTP listener exists; otherwise non-HTTP. Source QName matters, not filenames, outbound requests or source-less helpers. It creates no files/indexes, and does no RAML/DWL/test work. Omitted argument means all; otherwise preserve the supplied all/file/list/errors scope. Application modules are separate.
2. HTTP begins with pom.xml/local metadata and the APIKit reference to identify the MAIN API artifact: groupId, artifactId/name, version, type, classifier, effective local repository and exact local metadata. Locate the matching artifact in .m2/repository or its evidenced override, then extract it to external temp. Do not choose the common library, first ZIP, newest version or similarly named artifact as the main API. A missing main API stops project writes with a clear message.
3. csp-dhisp-common-api-library.raml is only a locally cached trait dependency when the extracted API applies it. Resolve actual method is entries through uses aliases, parameterized/nested trait definitions and exact versioned library paths/archives. Merge applicable resource/resourceType/security/method declarations; do not copy all library headers. Method is: [] does not cancel resource traits. Required values and enum/type constraints come from actual contracts/test properties, never invented credentials.
4. Only after extraction/dependency/header prerequisites, recursively analyse every selected APIKit operation and its XML/DWL graph, build all scenarios/fixtures, then write every owning suite plus source-required APIKit/main error suites. Non-HTTP skips RAML and derives in/ from first-entry XML/DWL consumers, not transformed output or later backend shapes.

## Preserved output contract

- All APIKit method/path owners receive endpoint-specific -test-suite.xml files with tests for all required feasible paths. File lists resolve reverse callers/cross-file dependencies. Required handlers own apikit-error-test-suite.xml or error-test-suite.xml; local try handlers stay with their entry. Non-HTTP does not inherit REST/APIKit execution rules.
- Recursively drill every flow-ref, scope, handler ref/default, DWL resource/import/function and relevant data reference. Cache reads by current content but retain each call context, prefix/suffix and branch vector. Use active-cycle detection and source-proven finite behavior; no arbitrary depth/test cap or false complete claim.
- Choice includes when/otherwise and nested/sequential combinations; scatter-gather mocks all concurrent routes; loops, batch, retry, cache and async require their specified representative/error/termination/completion scenarios. All executable processor occurrences are accounted for. Planned coverage is not measured coverage.
- Mock only actual external operations using current verbatim source selectors; never mock resolved flow-ref, DWL, handlers/scopes or json loggers. Full path mock sets include prefix, sub-flows, concurrent branches, real handler body and suffix. Returned payloads are literal out/ getResourceAsString calls with typed parsing when needed. No bare mock payload, inline JSON, verify-call or hidden processing.
- Collect all selected base request examples recursively, preserving valid JSON bytes or faithfully serializing YAML examples. Add only condition-driven variants satisfying full predicates plus effective required/type/enum constraints. Raw backend results belong in out/; RAML response examples only with proved HTTP pass-through. Non-HTTP entry/attribute/flow-derived/backend origins stay separate.
- Stage all JSON before suite XML. Fixture manifest version 2 and executable required/type/enum checks remain; deliberately invalid APIKit inputs have a distinct role/exact expected failure. Broader RAML/DWL semantics still need source analysis. No schema/parser dependency is installed.
- Every suite imports test-config.xml and has unique munit:config. Exactly two source byte-copies go to properties: app-properties-test.yaml and app-secrets-test.yaml. No dev/qa/prod/constants/error YAML copies or deletion of unrelated files to satisfy the allowlist.
- XML starts with one declaration and root, without BOM. Generated IDs are optional, otherwise unique lowercase hex UUIDs. Test names begin SUITE_BASE-; banned generic names remain prohibited. Exactly four INFO payload loggers and one prescribed non-null assertion. This assertion alone does not prove business correctness, and legitimate null/custom-assertion conflicts must not be hidden.
- REST source-enablement and first payload-only set-event follow Modes A/B/C. Execute named Request to <actual path> HTTP requests with explicit effective header maps. Error response validators are last and accept 200..599. Main error coverage must not use the router-mock shortcut. Non-HTTP invokes actual flow processing with sources disabled.

## Boundaries, refresh and continuation

Only the specified suite XML, in/out JSON, shared test-config and two test YAMLs may change in the project. Production/POM/.m2/settings/command definitions/helper folders/target remain unchanged. All extraction, plans, scripts, staging and optional isolated runtime output remain in verified physical OS temp outside the application. Installation uses user-level locations outside Maven applications; replace all three definitions together and start a fresh chat.

Preserve valid unchanged tests/fixtures byte-for-byte with unchanged timestamps. Add missing cases and narrowly patch stale selected implementation; retain unrelated tests and check all shared-fixture consumers. Do not delete/disable failures or fabricate values. Before/after source/path/hash and acceptance checks remain mandatory.

Proceed automatically without what-next/continue menus. Optional enabled subagents only analyse bounded scopes/review staged output, returning compact source-backed findings; the parent alone writes, verifies/merges results and finishes failed work locally. Serial fallback is complete. No extra agents/extensions/settings or model overrides, and no guaranteed token reduction.

If the main API is present but a referenced fragment remains unavailable after exact local search, retained source-backed generation may use actual implementation/current-test evidence and explicit pending-contract markers. Unknown constraints/headers remain unverified. The known common library must be searched locally, not mistaken for the root or declared absent merely because it was not bundled. Real missing essential facts are precise gaps, never fabricated readiness.

## What changed from v11 and what is not proved

The large duplicated native discovery, version-3 plan gate and path-guard frameworks were removed from prompts. Their required outcomes remain an agent acceptance checklist and one source-derived ledger; do not claim equivalent deterministic enforcement or reuse old plan schema/scripts. Fixture validation, extraction/probes and small XML parsing blocks remain embedded. Workers are self-contained, so common output rules necessarily occur in both files, but only once within each worker.

Current sizes: router 1,187 bytes; HTTP 58,886; non-HTTP 42,380. Size reduction is not a measured token/cost/quality result.

This is a reviewed release candidate. Actual production readiness, supported-platform native execution, VS Code/model adherence, complete semantic discovery, real Mule/MUnit runtime and measured coverage remain unverified. Do not inspect the user's excluded other system or claim its tests were repaired. For a future session, read these exact files before editing; this context alone does not authorize installation or application changes.
