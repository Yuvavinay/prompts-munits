#!/bin/bash
# Native macOS installer. No downloads or project/settings changes.
set -euo pipefail

format=skill
destination=''
update=false
while [ "$#" -gt 0 ]; do
    case "$1" in
        --format)
            [ "$#" -ge 2 ] || { echo '--format requires skill or prompt' >&2; exit 2; }
            format=$2; shift 2 ;;
        --destination)
            [ "$#" -ge 2 ] && [ -n "$2" ] || { echo '--destination requires a path' >&2; exit 2; }
            destination=$2; shift 2 ;;
        --update) update=true; shift ;;
        --help)
            echo 'Usage: /bin/bash install-munit-command.sh [--format skill|prompt] [--destination PARENT_DIRECTORY] [--update]'
            exit 0 ;;
        *) echo "Unknown argument: $1" >&2; exit 2 ;;
    esac
done
case "$format" in skill|prompt) ;; *) echo 'Format must be skill or prompt' >&2; exit 2 ;; esac

bundle_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
source_file="$bundle_dir/munit-generate.prompt.md"
[ -f "$source_file" ] || { echo 'Keep this installer beside munit-generate.prompt.md.' >&2; exit 1; }
# Validate the narrow bundled format without a YAML dependency.
/usr/bin/awk '
  NR == 1 {if ($0 != "---") exit 1; next}
  !closed && $0 == "---" {closed=1; next}
  !closed && $0 == "name: '\''munit-generate'\''" {name_ok=1}
  !closed && /^version: '\''[0-9]+\.[0-9]+\.[0-9]+'\''$/ {version_ok=1}
  END {if (!closed || !name_ok || !version_ok) exit 1}
' "$source_file" || { echo 'Invalid command frontmatter' >&2; exit 1; }

default_skills="$HOME/.copilot/skills"
default_prompts="$HOME/Library/Application Support/Code/User/prompts"
if [ -z "$destination" ]; then
    if [ "$format" = skill ]; then
        destination=$default_skills
        other_command="$default_prompts/munit-generate.prompt.md"
    else
        destination=$default_prompts
        other_command="$default_skills/munit-generate/SKILL.md"
    fi
    [ ! -e "$other_command" ] || {
        echo "The other format is already installed at $other_command. Keep only one active /munit-generate format; relocate it before switching." >&2
        exit 1
    }
fi
if [ "$format" = skill ]; then
    target_dir="$destination/munit-generate"
    target_file="$target_dir/SKILL.md"
else
    target_dir=$destination
    target_file="$target_dir/munit-generate.prompt.md"
fi
[ ! -L "$target_file" ] || { echo "Refusing to replace a symbolic link: $target_file" >&2; exit 1; }
if [ -e "$target_file" ] && [ ! -f "$target_file" ]; then
    echo "Not a regular file: $target_file" >&2; exit 1
fi

# Use system temp for conversion; the installed command remains one file.
stage_file=$(/usr/bin/mktemp "${TMPDIR:-/tmp}/munit-install.XXXXXXXX")
target_stage=''
cleanup() {
    /bin/rm -f -- "$stage_file"
    if [ -n "$target_stage" ]; then /bin/rm -f -- "$target_stage"; fi
}
trap cleanup EXIT
if [ "$format" = skill ]; then
    /usr/bin/awk '
      NR == 1 {print; next}
      !closed && $0 == "---" {print "metadata:"; print "  " version; print "---"; closed=1; next}
      !closed {if ($0 ~ /^(name|description):/) print; if ($0 ~ /^version:/) version=$0; next}
      {print}
    ' "$source_file" > "$stage_file"
else
    /bin/cp -- "$source_file" "$stage_file"
fi
if [ -f "$target_file" ]; then
    if /usr/bin/cmp -s "$stage_file" "$target_file"; then
        echo "Already installed: $target_file"
        exit 0
    fi
    if [ "$update" = false ]; then
        echo "Different content exists at $target_file. Use --update to replace it with a backup." >&2
        exit 1
    fi
fi
/bin/mkdir -p -- "$target_dir"
target_stage=$(/usr/bin/mktemp "$target_dir/.munit-install.XXXXXXXX")
/bin/cp -- "$stage_file" "$target_stage"
/usr/bin/cmp -s "$stage_file" "$target_stage" || { echo 'Staged file verification failed' >&2; exit 1; }
if [ -f "$target_file" ]; then
    backup_file="$target_file.backup-$(/usr/bin/uuidgen)"
    /bin/cp -p -- "$target_file" "$backup_file"
    echo "Backup: $backup_file"
fi
/bin/mv -f -- "$target_stage" "$target_file"
target_stage=''
/usr/bin/cmp -s "$stage_file" "$target_file" || { echo 'Installed file verification failed' >&2; exit 1; }
echo "Installed: $target_file"
echo 'Open the Mule application in VS Code chat, select Agent and Auto, and run /munit-generate all.'
echo 'If the command is not listed, reload the window and inspect Chat: Open Customizations.'
