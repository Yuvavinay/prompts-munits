#requires -Version 5.1
<#
Install the bundled command in the current user's existing editor environment.
No network, elevation, project writes, or settings changes are performed.
Destination is the parent skill directory, or the prompt directory for Format Prompt.
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [ValidateSet('Skill', 'Prompt')]
    [string]$Format = 'Skill',
    [string]$Destination,
    [switch]$Update
)

$ErrorActionPreference = 'Stop'
$sourceFile = Join-Path $PSScriptRoot 'munit-generate.prompt.md'
if (-not (Test-Path -LiteralPath $sourceFile -PathType Leaf)) {
    throw 'Keep this installer beside munit-generate.prompt.md.'
}
$utf8 = New-Object System.Text.UTF8Encoding($false, $true)
$sourceText = [IO.File]::ReadAllText($sourceFile, $utf8).Replace("`r`n", "`n")
$headerMatch = [regex]::Match($sourceText, '\A---\n(?<header>.*?)\n---\n(?<body>[\s\S]*)\z', 'Singleline')
if (-not $headerMatch.Success) { throw 'Invalid command frontmatter.' }
$header = $headerMatch.Groups['header'].Value
if ($header -notmatch "(?m)^name: 'munit-generate'$" -or
    $header -notmatch "(?m)^version: '[0-9]+\.[0-9]+\.[0-9]+'$") {
    throw 'Unexpected command name or version.'
}
$userRoot = [Environment]::GetFolderPath('UserProfile')
if ([string]::IsNullOrWhiteSpace($userRoot)) { throw 'Cannot resolve user profile.' }
$onWindows = [Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT
if ($onWindows) {
    $appDataRoot = [Environment]::GetFolderPath('ApplicationData')
    $defaultPrompts = Join-Path $appDataRoot 'Code\User\prompts'
} else {
    $defaultPrompts = Join-Path $userRoot 'Library/Application Support/Code/User/prompts'
}
$defaultSkills = Join-Path $userRoot '.copilot/skills'
$defaultDestination = [string]::IsNullOrWhiteSpace($Destination)
if ($defaultDestination) {
    if ($Format -eq 'Skill') {
        $Destination = $defaultSkills
        $otherCommand = Join-Path $defaultPrompts 'munit-generate.prompt.md'
    } else {
        $Destination = $defaultPrompts
        $otherCommand = Join-Path $defaultSkills 'munit-generate/SKILL.md'
    }
    if (Test-Path -LiteralPath $otherCommand) {
        throw "The other command format is already installed at $otherCommand. Keep only one active /munit-generate format; relocate the previous file before switching."
    }
}
$Destination = [IO.Path]::GetFullPath($Destination)
if ($Format -eq 'Skill') {
    # One source body, converted to portable skill frontmatter at install time.
    $skillLines = @('---')
    $skillLines += @($header -split "`n" | Where-Object { $_ -match '^(name|description):' })
    $versionLine = @($header -split "`n" | Where-Object { $_ -match '^version:' })[0]
    $skillLines += 'metadata:'
    $skillLines += ('  ' + $versionLine)
    $skillLines += '---'
    $installText = ($skillLines -join "`n") + "`n" + $headerMatch.Groups['body'].Value
    $targetDir = Join-Path $Destination 'munit-generate'
    $targetFile = Join-Path $targetDir 'SKILL.md'
} else {
    $installText = $sourceText
    $targetDir = $Destination
    $targetFile = Join-Path $targetDir 'munit-generate.prompt.md'
}
if (Test-Path -LiteralPath $targetFile) {
    if (-not (Test-Path -LiteralPath $targetFile -PathType Leaf)) { throw "Not a regular file: $targetFile" }
    if (((Get-Item -LiteralPath $targetFile).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "Refusing to replace a symbolic link: $targetFile"
    }
    $currentText = [IO.File]::ReadAllText($targetFile, $utf8)
    if ($currentText -ceq $installText) {
        Write-Output "Already installed: $targetFile"
        return
    }
    if (-not $Update) { throw "Different content exists at $targetFile. Use -Update to replace it with a backup." }
}
if (-not $PSCmdlet.ShouldProcess($targetFile, 'Install MUnit command')) { return }
[IO.Directory]::CreateDirectory($targetDir) | Out-Null
$stageFile = Join-Path $targetDir ('.munit-install-' + [guid]::NewGuid().ToString('N') + '.tmp')
try {
    [IO.File]::WriteAllText($stageFile, $installText, $utf8)
    if ([IO.File]::ReadAllText($stageFile, $utf8) -cne $installText) { throw 'Staged file verification failed.' }
    if (Test-Path -LiteralPath $targetFile -PathType Leaf) {
        $backupFile = $targetFile + '.backup-' + [guid]::NewGuid().ToString('N')
        [IO.File]::Replace($stageFile, $targetFile, $backupFile)
        Write-Output "Backup: $backupFile"
    } else {
        [IO.File]::Move($stageFile, $targetFile)
    }
    if ([IO.File]::ReadAllText($targetFile, $utf8) -cne $installText) { throw 'Installed file verification failed.' }
    Write-Output "Installed: $targetFile"
    Write-Output 'Open the Mule application in VS Code chat, select Agent and Auto, and run /munit-generate all.'
    Write-Output 'If the command is not listed, reload the window and inspect Chat: Open Customizations.'
} finally {
    if (Test-Path -LiteralPath $stageFile -PathType Leaf) { [IO.File]::Delete($stageFile) }
}
