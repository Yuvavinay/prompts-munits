# MUnit automation command

One maintained instruction file powers `/munit-generate all`, `/munit-generate <file.xml>`, and `/munit-generate errors`. It includes an internal router for APIKit REST and non-HTTP flows, native local-RAML extraction, recursive flow analysis, fixture gates, XML templates, and validation rules. It replaces the four overlapping scaffold/refresh prompts; repeat invocations reconcile the same generated scenarios.

## Install once

Extract the distribution ZIP into a directory outside your Mule project. Keep the three supplied command/installer files together. Run the following from that directory.

**Windows — built-in Windows PowerShell 5.1:**

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\Install-MUnitCommand.ps1"
```

The execution-policy option applies to that process only. The installer makes no persistent policy/settings changes, downloads nothing, and needs no administrator privileges. Existing organization policy still applies.

**macOS — built-in shell:**

```bash
/bin/bash ./install-munit-command.sh
```

PowerShell is not built into macOS, so the native shell installer meets the no-extra-dependency requirement. Users who already have PowerShell can use the `.ps1` installer there, but it is not required.

Both default to installing exactly one self-contained file:

```text
~/.copilot/skills/munit-generate/SKILL.md
```

The installers derive that file from `munit-generate.prompt.md`, preserving the complete instruction body and converting only its frontmatter. No companion scripts or shared prompts are needed at invocation time. Edit the source `.prompt.md` when maintaining this bundle; do not maintain a second copy of the instructions.

VS Code supports personal skills in this directory and exposes skills as slash commands. [VS Code skills documentation](https://code.visualstudio.com/docs/agent-customization/agent-skills)

## Run from the sidebar

1. Open the Mule application folder in your existing VS Code setup with GitHub Copilot available.
2. Open Chat, select **Agent**, and select **Auto** in the model picker where available.
3. Run one of:

```text
/munit-generate all
/munit-generate src/main/mule/operations/create-order.xml
/munit-generate errors
```

If the command is absent, reload the window and inspect **Chat: Open Customizations** or `/skills`. Ensure the active agent host can see the installed personal skill. For Remote/WSL/container sessions, install on the host where the agent reads its files; a local desktop install is not automatically a remote install. The installer does not change your agent/model choice or remove normal editor tool approvals.

## Requested prompt-file format

The source contains the requested `mode`, `name`, `version`, `description`, and `argument-hint` fields, plus the currently documented `agent: 'agent'`. There is no model override. `mode` and `version` are retained metadata; `agent` controls execution in the prompt-file format.

For a VS Code **Local agent** environment that uses prompt files, install that format instead:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\Install-MUnitCommand.ps1" -Format Prompt
```

```bash
/bin/bash ./install-munit-command.sh --format prompt
```

Default destinations:

| Format | Windows | macOS |
| --- | --- | --- |
| Skill | `%USERPROFILE%\.copilot\skills\munit-generate\SKILL.md` | `~/.copilot/skills/munit-generate/SKILL.md` |
| Prompt | `%APPDATA%\Code\User\prompts\munit-generate.prompt.md` | `~/Library/Application Support/Code/User/prompts/munit-generate.prompt.md` |

Current VS Code documentation says prompt files continue to work with the Local agent but are not loaded by Agent Host sessions; skills are the default here for that reason. Prompt files without a `model` field use the selected model. [VS Code prompt-file documentation](https://code.visualstudio.com/docs/agent-customization/prompt-files)

For a named profile, Insiders, portable installation, or custom data directory, supply the actual destination with PowerShell `-Destination 'ABSOLUTE_DIRECTORY'` or Bash `--destination 'ABSOLUTE_DIRECTORY'`. Skill destinations are **parent skill directories**; prompt destinations are **the prompt directory itself**. Do not install both formats as `/munit-generate` in the same environment. The installers detect the other format at the default paths; custom locations must be checked by the user.

## Updating

An identical reinstall changes nothing. Different existing content is protected by default. To update, add `-Update` on PowerShell or `--update` on Bash. The previous file receives a unique `.backup-*` name before replacement. No unrelated prompts are changed or deleted.

## Application prerequisites and behavior

The installer itself needs only native OS tools. Executing MUnit still requires the application's existing compatible Mule 4 / MUnit 2.x / Java / Maven setup and locally cached dependencies. This command does not add dependencies or change `pom.xml`. File checks remain possible when runtime execution is unavailable, and the summary must say **runtime not run; coverage unmeasured**.

For selected REST flows, the declared API artifact and all needed contract fragments must already be in the effective local Maven repository. Resolution uses the POM's actual type/classifier/version, local parents/profiles, repository settings, and snapshot metadata. It never downloads a substitute. [Maven artifact layout](https://maven.apache.org/repository/layout.html), [Maven settings](https://maven.apache.org/settings.html)

The two existing source files `app-properties-test.yaml` and `app-secrets-test.yaml` are copied byte-for-byte. The application must already support selecting them and provisioning any secure-property key. Outbound mocks do not eliminate application startup configuration requirements. [MUnit mock processor documentation](https://docs.mulesoft.com/munit/2.3/mock-event-processor)

Only MUnit XML, `in/` JSON, `out/` JSON, and those two property files are written into the project. Temporary extraction/planning stays in OS temp. An existing test run may create its normal Maven `target/` reports. A missing REST RAML artifact stops the entire selected run before any project write, including in mixed REST/non-HTTP applications.

## Explicit resolutions of conflicting requirements

The instruction file preserves the requested strict rules and exposes cases that cannot satisfy them honestly:

| Requirement combination | Implemented treatment |
| --- | --- |
| Separate routing files, but latest request requires one self-contained file with no shared imports | One file with internal REST and any-source routes; no duplicated rule sets |
| Two REST source roles, but one real listener flow | Enable the real flow once when source proves both roles are the same; never invent an extra listener |
| Source names must come from `api.xml` | Enforced as a project-specific gate; a different source layout is reported, not renamed or guessed |
| Verbatim request example, but the RAML example is a YAML object or absent | Request a valid JSON example; no silent serialization or invented request fields; bodyless operations use a null event seed without a request body |
| Exactly two property files, but destination already contains other files | Stop before writing; do not delete existing user files |
| All execution paths, including loops and asynchronous work | Enumerate finite branch obligations depth-first, preserve all unresolved paths, and require evidenced completion for async/batch work; do not claim fixed sleeps prove completion |
| Every doc:id executed, including configuration declarations or unreachable code | Separate executable processor coverage from source traceability; list non-executable/unreachable elements explicitly |
| Four loggers and an assertion must run in direct propagated-error tests | Catch the expected error in a test-local scope and guard against its absence; unexpected errors still fail |
| Valid scenario returns null, but the only allowed assertion is non-null | Report the contradiction; do not alter application output to pass |
| No guessed values, but mock fixture values must be created | Permit explicitly derived values from source predicates/types; missing backend shape/contract blocks affected tests |
| No vendor text in generated artifacts, but namespaces/source values contain it | Prohibit generation metadata; preserve required Mule schema URIs and exact source/property values |

Mocked target variables receive their calculated values while preserving the incoming event; `os:contains` returns a Boolean. [MUnit target-variable testing](https://docs.mulesoft.com/munit/latest/test-processor-that-uses-target-variable)

The mandatory assertion is exactly `payload must notBeNull()` inside `munit-tools:assert`. It checks non-nullness only. Combined with a `200..599` HTTP validator, it does **not** prove the expected status or response body. APIKit router mocks test handler dispatch, not actual request validation. Stronger business assertions would require relaxing the specified assertion rule. [MUnit assert-expression documentation](https://docs.mulesoft.com/munit/2.3/assertion-expression-processor)

No instruction file can guarantee failure-free generation for every application or identical results across models. This package uses shared rules, compact per-run inventories, staged validation, and explicit blockers to reduce errors without hiding incomplete work.

## Validation of this distribution

Executed on macOS:

- Native installer: skill/prompt output, unchanged instruction body, repeated installation, conflict protection, explicit update with backup, paths containing spaces/quotes, and invalid arguments.
- Native extraction: nested RAML/examples/fragments, unique temporary directories, and rejection of missing, corrupt, traversal, absolute-path, symlink, and case-collision archives.
- Instantiated REST A/B/C and any-source templates: XML parsing, source-list ordering, payload-only event setup, four loggers, one required assertion, and final HTTP error validators.
- Native JXA JSON parsing; prompt and installed-skill YAML parsing with system Ruby; skill name, description, metadata and unchanged-body checks.

Not executed: Windows PowerShell code, actual editor sidebar discovery, Mule/MUnit schema/runtime validation, or measured application coverage. PowerShell is unavailable in the authoring environment, and no target Mule application was supplied. The bundled skill-creator validator could not start because its PyYAML dependency is absent; native YAML parsing and equivalent metadata checks were used instead. These runtime/editor checks remain acceptance checks on your Windows setup and a representative Mule application.
