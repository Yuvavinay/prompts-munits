#requires -Version 5.1
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [ValidateSet('Skill', 'Prompt')][string]$Format = 'Skill',
    [string]$Destination,
    [switch]$Update
)
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false, $true)
$userRoot = [Environment]::GetFolderPath('UserProfile')
if (-not $userRoot) { throw 'Cannot resolve user profile.' }
$skillRoot = Join-Path $userRoot '.copilot/skills'
if ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) {
    $promptRoot = Join-Path ([Environment]::GetFolderPath('ApplicationData')) 'Code\User\prompts'
} else {
    $promptRoot = Join-Path $userRoot 'Library/Application Support/Code/User/prompts'
}
$useDefault = [string]::IsNullOrWhiteSpace($Destination)
if ($useDefault) {
    if ($Format -eq 'Skill') { $Destination = $skillRoot } else { $Destination = $promptRoot }
}
$Destination = [IO.Path]::GetFullPath($Destination)
# Preflight all three files before any destination write; publish router last.
$names = @('munit-http-listener', 'munit-non-http-listener', 'munit-generate')
$plan = @()
foreach ($name in $names) {
    $source = Join-Path $PSScriptRoot ($name + '.prompt.md')
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing bundled file: $source" }
    $text = [IO.File]::ReadAllText($source, $utf8).Replace("`r`n", "`n")
    $match = [regex]::Match($text, '\A---\n(?<header>.*?)\n---\n(?<body>[\s\S]*)\z', 'Singleline')
    if (-not $match.Success) { throw "Invalid frontmatter: $source" }
    $header = $match.Groups['header'].Value
    if ($header -notmatch ("(?m)^name: '" + [regex]::Escape($name) + "'$") -or
        $header -notmatch "(?m)^version: '3\.0\.0'$") { throw "Mismatched name/version: $source" }
    if ($Format -eq 'Skill') {
        $lines = @('---') + @($header -split "`n" | Where-Object { $_ -match '^(name|description):' })
        $lines += @('metadata:', "  version: '3.0.0'", '---')
        $body = [regex]::Replace($match.Groups['body'].Value, '\((munit-[a-z-]+)\.prompt\.md\)', '(../$1/SKILL.md)')
        $text = ($lines -join "`n") + "`n" + $body
        $target = Join-Path (Join-Path $Destination $name) 'SKILL.md'
        $other = Join-Path $promptRoot ($name + '.prompt.md')
    } else {
        $target = Join-Path $Destination ($name + '.prompt.md')
        $other = Join-Path (Join-Path $skillRoot $name) 'SKILL.md'
    }
    if ($useDefault -and (Test-Path -LiteralPath $other)) {
        throw "Other command format exists at $other. Keep one active format; relocate it before switching."
    }
    $changed = $true
    if (Test-Path -LiteralPath $target) {
        $item = Get-Item -LiteralPath $target
        if ($item.PSIsContainer -or (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
            throw "Destination is not a regular file: $target"
        }
        $changed = [IO.File]::ReadAllText($target, $utf8) -cne $text
        if ($changed -and -not $Update) { throw "Existing content differs: $target. Use -Update to preserve a backup and replace the installed skill." }
    }
    $plan += [pscustomobject]@{ Path = $target; Text = $text; Changed = $changed }
}
if (-not ($plan | Where-Object { $_.Changed })) {
    Write-Output 'All three commands are already installed; no changes.'
    return
}
if (-not $PSCmdlet.ShouldProcess($Destination, 'Install the three MUnit command files')) { return }
foreach ($entry in $plan) {
    if (-not $entry.Changed) { Write-Output "Unchanged: $($entry.Path)"; continue }
    $directory = [IO.Path]::GetDirectoryName($entry.Path)
    [IO.Directory]::CreateDirectory($directory) | Out-Null
    $stage = Join-Path $directory ('.munit-install-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [IO.File]::WriteAllText($stage, $entry.Text, $utf8)
        if ([IO.File]::ReadAllText($stage, $utf8) -cne $entry.Text) { throw 'Staged verification failed.' }
        if (Test-Path -LiteralPath $entry.Path) {
            $backup = $entry.Path + '.backup-' + [guid]::NewGuid().ToString('N')
            [IO.File]::Replace($stage, $entry.Path, $backup)
            Write-Output "Backup: $backup"
        } else { [IO.File]::Move($stage, $entry.Path) }
        if ([IO.File]::ReadAllText($entry.Path, $utf8) -cne $entry.Text) { throw 'Installed verification failed.' }
        Write-Output "Installed: $($entry.Path)"
    } finally {
        if (Test-Path -LiteralPath $stage -PathType Leaf) { [IO.File]::Delete($stage) }
    }
}
Write-Output 'Reload VS Code if needed. Select Agent and Auto; run /munit-generate all.'
Write-Output 'This installer updates skill definitions only. Generated application tests follow the additive-only policy.'
