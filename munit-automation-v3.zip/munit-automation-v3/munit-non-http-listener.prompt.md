---
mode: 'agent'
agent: 'agent'
name: 'munit-non-http-listener'
version: '3.0.0'
description: 'Generate additive scheduler, messaging and other non-HTTP MUnit suites without deleting existing tests.'
argument-hint: '<file.xml> | all | errors'
---

# Non-HTTP listener MUnit route

Run `/munit-non-http-listener <file.xml> | all | errors`, or let `/munit-generate` route here. Read the **Shared sections only** in [the router](munit-generate.prompt.md), once per invocation. Follow its additive/no-op policy and validation gates. Do not execute its dispatch section when loading it directly. This file contains only non-HTTP-specific instructions.

## Scope and sequence

1. Read current source, pom.xml, test configuration and existing MUnit suites. Identify scheduler, anypoint-mq subscriber, JMS/VM listener, file/SFTP source or any other real non-HTTP source by namespace and source role. An outbound HTTP request inside a scheduler does not make the entry an HTTP-listener flow. Trace source-less sub-flows back to callers; never select them by filename alone.
2. No RAML extraction is required for a purely non-HTTP selection. On a mixed router invocation wait for the global HTTP RAML gate before any project write. Do not invoke the HTTP worker simply because a backend uses HTTP.
3. Apply shared preflight/snapshot, recursive flow/sub-flow/DWL analysis, depth-first branch coverage and comparison against existing tests. Find existing suites by their actual execution flow-ref even when the suite/source filename changed.
4. Derive incoming payload/attributes from source contracts, existing valid test data and the code that consumes them. For a scheduler without an incoming payload, use null; do not invent a request contract. A non-null final assertion still requires the actual flow result to be non-null. Broker-only typed attributes/acknowledgement/transaction state must not be approximated by a guessed object.
5. Use the common backend mocks and out/ fixture rules. Mock outbound database, HTTP, file, object-store, MQ/JMS/VM and other external operations on each path. Run resolved sub-flows for real; do not mock the inbound source or enable the scheduler/subscriber. Read connector target/targetValue and preserve event semantics.
6. Compare the complete scenario set to existing tests. Empty delta is a true no-op. Otherwise add only missing tests, proven safe mock insertions, new fixtures and missing allowed test property files. Preserve all existing tests, assertions and fixture bytes. Stale tests needing replacement are explicit conflicts.
7. Use the shared root, naming, mock and validation blocks with the non-HTTP structure below. Run file/preservation checks, then established offline tests only if changes were made. Report timing/broker-delivery coverage separately from direct flow-processing coverage.

## Non-HTTP test structure

Use the same naming, mock, JSON, properties, traversal and validation rules. Omit enable-flow-sources so schedulers and subscribers never activate; replace the REST HTTP request with `<flow-ref name="ACTUAL_ENTRY_FLOW"/>`. No test HTTP config is needed unless the suite actually uses one. These test flow processing, not scheduler timing, broker delivery, transactions, or acknowledgement lifecycle.

Seed payload from an evidenced source message/example (or null for a source with no payload). REST's payload-only set-event rule stays unchanged for REST. Any-source tests may add source-required attributes/variables using the installed set-event schema only when evidenced from the source boundary; label that seed in the plan. Never fabricate connector-only Java attributes as arbitrary maps. An unavailable source contract blocks the dependent scenario.

```xml
<munit:test name="SUITE_BASE-SCENARIO" description="EVIDENCED_SCENARIO">
    <munit:behavior>
        <!-- Insert source-traced connector mocks; use the shared empty-path exception only when proved. -->
    </munit:behavior>
    <munit:execution>
        <munit:set-event>
            <munit:payload value="#[read(MunitTools::getResourceAsString('in/INPUT.json'), 'application/json')]" mediaType="application/json"/>
        </munit:set-event>
        <logger level="INFO" message="#[payload]" category="SUITE_BASE.execution-start"/>
        <flow-ref name="ACTUAL_ENTRY_FLOW"/>
        <logger level="INFO" message="#[payload]" category="SUITE_BASE.execution-end"/>
    </munit:execution>
    <!-- Insert the exact Shared: canonical validation block from the router. -->
</munit:test>
```

Use the shared direct-call error procedure for propagated errors. on-error-continue paths must traverse the actual handler and retain their real output. Iterate actual representative collections/records for foreach/batch, honor acceptPolicy, and prove bounded async/batch completion with the available source/test mechanism. Do not claim a fixed sleep proves completion or skip internal branch planning.

`errors` selects reachable non-HTTP business handlers and traced triggers only. Never add APIKit router mocks or APIKIT error injections for this route. Catch-all ANY is not a throwable type; use a registered error proven to reach the handler. An unavailable trigger stays an explicit coverage obligation.

## Finish

Use the shared progress and final summary. Preserve existing test order/names/IDs and hashes of all pre-existing fixtures/properties. A second identical invocation must change no project bytes. Do not delete/disable an old failing test to make the added tests appear successful.
