# MUnit skills — additive edition, version 3

All generation instructions and native command examples are inside these three Markdown files. The router stores common rules once, and loads only the relevant listener route. Install all three together.

| Markdown file | Slash command | Purpose |
| --- | --- | --- |
| [munit-generate.prompt.md](munit-generate.prompt.md) | `/munit-generate all` | Detect the source, compare existing tests, and route to the relevant instructions |
| [munit-http-listener.prompt.md](munit-http-listener.prompt.md) | `/munit-http-listener all` | HTTP listener tests, including APIKit operations and handlers, with mandatory local RAML |
| [munit-non-http-listener.prompt.md](munit-non-http-listener.prompt.md) | `/munit-non-http-listener all` | Scheduler, MQ/JMS/VM, file and other non-HTTP flow tests |

Every command also accepts `<file.xml>` or `errors`. For example:

```text
/munit-generate src/main/mule/orders.xml
/munit-http-listener src/main/mule/api.xml
/munit-non-http-listener src/main/mule/order-scheduler.xml
```

## Existing files and tests

When a suite filename already exists, the agent reads its tests and compares their implementation with the current source, reachable sub-flows, mocks, fixtures and contract. It also finds matching tests in differently named suites so a source rename does not create duplicate tests.

| Finding | Action |
| --- | --- |
| Existing tests already cover the implementation | No writes, no formatting, no property recopy, no build execution; report Unchanged |
| New uncovered operation/branch/error case | Append only the missing test and required new fixtures |
| Existing test needs a newly added backend mock | Insert the missing mock only if old nodes, values, selectors and assertions remain unchanged and correct |
| Matching input/output fixture exists | Reuse it without rewriting |
| New scenario needs different fixture data | Create a distinct deterministic fixture; preserve the old fixture |
| Old test is stale, obsolete or requires replacement | Preserve it, report the specific conflict and required repair; do not delete/disable it |

The agent must compare before/after test names, order, existing content and fixture hashes. Existing tests are never deleted or rebuilt from a template. New templates do not trigger a wholesale rewrite of older tests. The second identical invocation must change no project files.

This is strictly additive maintenance. A stale mock ID or changed expected value can require a non-additive repair; that is reported rather than silently changed. Adding passing tests must never hide failures in preserved tests.

## Install once

Extract this ZIP outside your Mule project and run from the extracted directory.

Windows, using built-in PowerShell:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\Install-MUnitCommand.ps1"
```

To update an earlier installation, use the same command with `-Update`. It backs up changed **skill definitions**; this does not authorize overwriting application tests. The execution-policy option is process-scoped and does not change persistent policy.

macOS, using the built-in shell:

```bash
/bin/bash ./install-munit-command.sh
```

Add `--update` when replacing an earlier installation. No extra runtime, extension, download or administrator access is required by the installer. PowerShell is not required on macOS.

The default installation produces:

```text
~/.copilot/skills/
  munit-generate/SKILL.md
  munit-http-listener/SKILL.md
  munit-non-http-listener/SKILL.md
```

The installers convert frontmatter and rewrite sibling Markdown links for this layout; all instruction bodies remain enclosed in the installed Markdown files. Relative links keep routes connected without workspace configuration changes. Personal skills can appear as slash commands in VS Code. [VS Code skill documentation](https://code.visualstudio.com/docs/agent-customization/agent-skills)

Open the Mule application in VS Code Chat, select **Agent** and **Auto**, then invoke the router or one of the listener commands. Reload the window if necessary and inspect `/skills` or **Chat: Open Customizations**. For remote sessions, install where the agent reads its skills.

For an existing Local-agent setup using `.prompt.md` files, pass `-Format Prompt` or `--format prompt`. Default prompt directories are `%APPDATA%\Code\User\prompts` on Windows and `~/Library/Application Support/Code/User/prompts` on macOS. Current Agent Host sessions use skills rather than prompt files. [VS Code prompt documentation](https://code.visualstudio.com/docs/agent-customization/prompt-files)

For another profile or custom location, use `-Destination 'DIRECTORY'` / `--destination 'DIRECTORY'`. This is the parent skills directory in Skill mode or the prompt directory in Prompt mode. Keep only one installed format per command in an environment. Reinstalling identical definitions leaves their bytes and modification times unchanged. All three source files and destinations are checked before installing any changed file.

## Preserved generation requirements

HTTP tests resolve RAML from the POM and local Maven repository with native Windows/macOS commands. Missing HTTP RAML stops the whole selected run before project writes; non-HTTP-only runs do not require RAML. HTTP uses real local HTTP requests; non-HTTP invokes the actual flow directly with sources disabled.

Recursive sub-flow analysis, branch/cache/retry planning, raw backend output fixtures, source-traced mocks, XML validation, and the exact two property-file rule remain in the shared instructions. Project changes are limited to MUnit XML and test resources; temporary plans/extraction stay in OS temp. Existing Maven test runs may create their normal target reports only when generation made changes.

Actual test execution requires the project's already provisioned compatible Mule 4/MUnit 2.x/Java/Maven environment. No dependencies or POM changes are added. The mandated non-null assertion checks payload presence only; it does not prove the expected business response. The api.xml source-provenance requirement remains a project-specific gate. Missing contracts or contradictory requirements are reported explicitly.

## Validation limits

Package checks cover the macOS install/update/no-op paths, preservation of installer conflicts, rewritten Markdown links, metadata and instantiated XML structure. Native RAML extraction retains the previously tested implementation. No target Mule application was supplied, so agent-driven reconciliation, MUnit execution and measured coverage remain unverified. Windows PowerShell execution and actual sidebar discovery also require testing in the target environment.
