---
mode: 'agent'
agent: 'agent'
name: 'munit-http-listener'
version: '3.0.0'
description: 'Generate additive HTTP-listener MUnit suites from local RAML while preserving every existing test.'
argument-hint: '<file.xml> | all | errors'
---

# HTTP listener MUnit route

Run `/munit-http-listener <file.xml> | all | errors`, or let `/munit-generate` route here. Read the **Shared sections only** in [the router](munit-generate.prompt.md), once per invocation. Follow its additive/no-op policy and validation gates. Do not execute its dispatch section when loading it directly. This file adds only HTTP-specific instructions.

## Scope and sequence

Select only flows reached from a real http:listener, including APIKit operations. For mixed files, leave non-HTTP entries to the other route. Read current source and existing suites first, resolve all selected RAML contracts, map HTTP paths and backend calls, plan branches, and compare existing fixtures/mocks/tests using the shared delta algorithm. If covered, stop with Unchanged. Otherwise add only missing content and validate preservation.

HTTP without APIKit still uses local HTTP requests and the mandatory POM-resolved RAML gate. Map operations from actual listener paths, allowedMethods and downstream routing; do not invent APIKit flows/configs or router error tests. If no evidenced operation contract/mapping exists, stop the affected selection. APIKit-specific steps and Mode B apply only when a real router exists.

## HTTP pre-flight

5. REST flow-source values must trace to real `<flow name>` declarations read from `api.xml` this run, as required by this contract. Resolve MAIN_LISTENER_FLOW and PUBLIC_FLOW through the real inbound chain; never substitute the API console or guess that an operation flow has a listener. If one flow genuinely serves both roles, record that identity and enable it once. If the required source declarations live elsewhere, report the contract mismatch before writing instead of pretending they came from `api.xml`.
6. Determine test HTTP client connection from the actual listener: loopback host, resolved test port, protocol/TLS, base path, and application routing. Reuse a proven local test client configuration if available. Otherwise declare a uniquely named test HTTP request config inside one generated suite and reference it from the selected suites; do not add an unproven `test-config.xml` import. Verify cross-suite configuration visibility with the existing runner. Never send a test request to an external application endpoint.

For a plain HTTP listener, only actual source flows are enabled; PUBLIC_FLOW may be the same real listener flow. The api.xml provenance requirement remains a strict project-specific gate; report different layouts rather than moving source files.

## RAML resolution and native extraction

Print `→ Resolving the API contract from the local Maven repository`.

Resolve coordinates as **data**, not executable shell text:

1. Read the RAML/ZIP dependency's groupId, artifactId, version, type, classifier from the module POM, dependencyManagement/imported local BOMs, local parents and applicable profiles. Match the APIKit `api`/`raml` reference to the selected artifact/root. Do not choose the first ZIP dependency. Resolve `${...}` recursively with cycle detection. Unavailable parents, ambiguous profiles, version ranges, or unresolved expressions are blockers; do not guess a version.
2. Determine the effective local repository from explicit `-Dmaven.repo.local`, configured Maven arguments/settings, user `~/.m2/settings.xml`, global settings where applicable, then default `~/.m2/repository`. Resolve precedence; do not scan unrelated repositories for the newest version. On Windows use the actual user profile path, not a literal tilde. Do not display credentials from settings.
3. Construct `<repository>/<groupId with dots replaced by separators>/<artifactId>/<version>/<artifactId>-<version>[-<classifier>].<extension>`. For a dependency explicitly declared as ZIP/RAML, honor the actual classifier; do not substitute a fragment for the root API. If classifier is absent and source conventions leave it uncertain, inspect only the matching version directory and prove the chosen archive/root from APIKit and archive metadata. For SNAPSHOTs resolve the matching extension/classifier through local `maven-metadata*.xml`; do not sort files by date and assume the latest is correct.
4. Check all selected archive paths exist before creating project output directories. If absent, print exactly `RAML not found. Please add the RAML artifact declared by pom.xml to the local Maven repository, then rerun /munit-generate. No project files were written.` Include the unresolved coordinates and checked paths separately. HALT THE ENTIRE RUN. Do not fetch an online or source-tree substitute.
5. Extract to a fresh temporary directory per artifact. Never extract into the project or `.m2`, reuse a stale extraction, or flatten directories. The following blocks use native tools and accept a **resolved absolute archive path**; replace the placeholder using literal shell quoting. Reject malformed, encrypted, unsafe, or corrupt archives; do not continue after a nonzero exit.

### Windows native extraction (PowerShell 5.1)

Use Windows PowerShell, not a shell whose `tar` implementation cannot read ZIPs. Single quotes in a literal path must be doubled. This block validates paths before extraction; it needs no downloaded module.

```powershell
$ErrorActionPreference = 'Stop'
$ramlArchive = 'RESOLVED_ABSOLUTE_ARCHIVE_PATH'
if (-not (Test-Path -LiteralPath $ramlArchive -PathType Leaf)) {
    throw 'RAML not found. No project files were written.'
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$ramlTemp = Join-Path ([IO.Path]::GetTempPath()) ('munit-raml-' + [guid]::NewGuid().ToString('D'))
$ramlZip = [IO.Compression.ZipFile]::OpenRead($ramlArchive)
try {
    $seen = @{}
    foreach ($entry in $ramlZip.Entries) {
        $n = $entry.FullName.Replace('\', '/')
        if ($n -match '(^/|^[A-Za-z]:|(^|/)\.\.(/|$)|[\x00-\x1f])') { throw 'Unsafe archive path' }
        $dest = [IO.Path]::GetFullPath((Join-Path $ramlTemp $n))
        $prefix = [IO.Path]::GetFullPath($ramlTemp) + [IO.Path]::DirectorySeparatorChar
        if (-not $dest.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Archive path escapes temp' }
        if ($seen.ContainsKey($dest)) { throw 'Duplicate archive destination' }
        $seen[$dest] = $true
        if (($entry.ExternalAttributes -band 0xF0000000L) -eq 0xA0000000L) { throw 'Archive symlink is not allowed' }
    }
} finally { $ramlZip.Dispose() }
[IO.Compression.ZipFile]::ExtractToDirectory($ramlArchive, $ramlTemp)
Get-ChildItem -LiteralPath $ramlTemp -Recurse -File -Filter '*.raml' | Select-Object -ExpandProperty FullName
Write-Output ('RAML_TEMP=' + $ramlTemp)
```

### macOS native extraction (system Bash)

Use `/bin/bash`. Quote a literal single quote as `'\''`; never interpolate POM text as shell code. These utilities are part of macOS; no PowerShell, Python, Node, Java, or Homebrew is required for extraction.

```bash
set -euo pipefail
raml_archive='RESOLVED_ABSOLUTE_ARCHIVE_PATH'
test -f "$raml_archive" || { echo 'RAML not found. No project files were written.' >&2; exit 1; }
unset UNZIP UNZIPOPT ZIPINFO ZIPINFOOPT
raml_names=$(/usr/bin/unzip -Z1 "$raml_archive")
raml_details=$(/usr/bin/zipinfo -l "$raml_archive")
printf '%s\n' "$raml_names" | /usr/bin/awk '
  /^\// || /^[A-Za-z]:/ || /\\/ || /(^|\/)\.\.(\/|$)/ || /[[:cntrl:]]/ {bad=1}
  {key=tolower($0); if (seen[key]++) bad=1}
  END {exit bad ? 1 : 0}' || { echo 'Unsafe or duplicate archive path' >&2; exit 1; }
printf '%s\n' "$raml_details" | /usr/bin/awk '
  /^l/ {bad=1} END {exit bad ? 1 : 0}' || { echo 'Archive symlink is not allowed' >&2; exit 1; }
/usr/bin/unzip -tq "$raml_archive" </dev/null
raml_temp=$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/munit-raml.XXXXXXXX")
/usr/bin/unzip -q "$raml_archive" -d "$raml_temp" </dev/null
/usr/bin/find "$raml_temp" -type f -name '*.raml' -print
printf 'RAML_TEMP=%s\n' "$raml_temp"
```

6. Find the API root with `#%RAML 1.0` or the project's supported RAML version; a Library, Trait, DataType, or NamedExample fragment is not an API root. Multiple roots require APIKit mapping evidence. No valid root is the same whole-run halt as a missing artifact.
7. Resolve `!include`, `uses`, traits, resourceTypes, type inheritance, named examples, schemas, and nested resources relative to each referring file. Prefer bundled `exchange_modules`; use local fragment artifacts only when their coordinates are evidenced in the contract/POM/metadata. Preserve relative references across extraction directories. Missing referenced fragments or remote-only references stop generation; do not download them. Detect reference cycles and traverse each dependency once.
8. Build a per-operation contract: method, full resource path, media types, required headers/query/URI parameters, effective request type constraints, request example, and responses. RAML keys are `example`/`examples`; “requestExample” below means the selected request body's example value, not a guessed RAML keyword. Resolve inherited traits and distinguish example wrappers (`value`, `strict`) from the actual body.

For plain HTTP flows, replace references to APIKit mapping in the resolution procedure with the evidenced listener method/path/dispatch mapping. The same local-artifact and missing-contract halt rules apply.

## Map operations and prepare HTTP input

Map each contract operation to its actual APIKit flow, honoring explicit flow mappings and the configured naming scheme. Trace from listener through public routing to business flows and back through response/error transforms. Read each inline/resource DWL payload, variable, and attributes transformation. Track payload, attributes, variables, target/targetValue, and error mappings at each processor.

For non-APIKit listeners, map method/path through the real routing code instead. Apply shared recursive analysis, coverage planning and backend fixture rules, then use the following HTTP input rules for newly required scenarios:

- `in/<suite-base>-request.json`: copy the selected RAML JSON request example byte-for-byte, including its whitespace, when the source is a JSON file/literal. Validate first; never repair the base example silently. For a RAML YAML object example, JSON serialization preserves value/types but cannot be verbatim bytes: report this conflict and request a JSON example before writing under this strict contract. Missing/invalid body examples block that operation. For a contract with **no request body**, use `null` as a test-event seed and omit `<http:body>`; do not send an invented `{}` request body.
- Branch `in/` copies change only the declared fields referenced by the relevant predicates, preserving all other values and types. Diff against the base; validate effective RAML required fields, enums, types, nested items, nullability, lengths/ranges/patterns, and additionalProperties. Evaluate all predicates with the planned fixtures. No required-field deletion or invalid enum to force a business branch. Invalid request bodies are not needed for router-mock Mode B tests.

If the desired input filename already exists, compare actual contents/contract/predicates. Reuse valid data; otherwise use a new stable scenario filename for a new test. Never replace an old request fixture under existing tests.

## HTTP suite root and client

Use this only for a NEW suite; existing suites receive necessary non-conflicting insertions only.

```xml
<?xml version="1.0" encoding="UTF-8"?>
<mule xmlns="http://www.mulesoft.org/schema/mule/core"
      xmlns:munit="http://www.mulesoft.org/schema/mule/munit"
      xmlns:munit-tools="http://www.mulesoft.org/schema/mule/munit-tools"
      xmlns:http="http://www.mulesoft.org/schema/mule/http"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
      http://www.mulesoft.org/schema/mule/munit http://www.mulesoft.org/schema/mule/munit/current/mule-munit.xsd
      http://www.mulesoft.org/schema/mule/munit-tools http://www.mulesoft.org/schema/mule/munit-tools/current/mule-munit-tools.xsd
      http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd">
    <!-- munit-generate: managed suite v3 -->
    <munit:config name="SUITE_BASE.xml"/>
    <!-- Declare this once only if a proven local test client is not already available. -->
    <http:request-config name="UNIQUE_TEST_HTTP_CONFIG">
        <http:request-connection host="127.0.0.1" port="RESOLVED_TEST_PORT" protocol="HTTP"/>
    </http:request-config>
    <!-- Insert fully instantiated tests here. -->
</mule>
```

Use the actual protocol/TLS requirements; the HTTP example is not a license to downgrade HTTPS. Make base-path placement explicit: either client basePath or request path, never both. Add `xmlns:doc` only if a generated element has doc:* attributes. Include connector namespace declarations/schema pairs only when actual suite elements/attributes use that namespace. A plain string such as `processor="db:select"` is a mock selector, not an XML QName requiring `xmlns:db`. Use the source prefix spelling understood by the runner; verify alternate source prefixes rather than assuming `http`.

## HTTP tests: Modes A/B/C

| Mode | First-child enable-flow-sources contents | Execution/mocking |
| --- | --- | --- |
| A: operation | MAIN_LISTENER_FLOW and PUBLIC_FLOW, deduplicated if the same flow | Local HTTP request; backend connectors mocked |
| B: APIKit errors | MAIN_LISTENER_FLOW only | Local HTTP request; narrowly identified APIKit router mocked to registered error |
| C: business handler | MAIN_LISTENER_FLOW and PUBLIC_FLOW of this handler's actual entry, deduplicated | Local HTTP request; real trigger/connector error reaches business handler; never mock APIKit router |

The block below is shared by all three modes. Apply the table to its source list and mocks; do not generate three duplicate templates. Set-event contains only payload and is the first child of execution. Exactly four **test-owned** core INFO loggers have `message="#[payload]"`; application loggers invoked through production code do not count. Categories are literal generated names, not an assumed `${log.category.base}` property.

```xml
<munit:test name="SUITE_BASE-SCENARIO" description="EVIDENCED_SCENARIO">
    <munit:enable-flow-sources>
        <munit:enable-flow-source value="MAIN_LISTENER_FLOW"/>
        <munit:enable-flow-source value="PUBLIC_FLOW"/>
    </munit:enable-flow-sources>
    <munit:behavior>
        <!-- Insert the exact connector mocks for the complete path. -->
    </munit:behavior>
    <munit:execution>
        <munit:set-event>
            <munit:payload value="#[read(MunitTools::getResourceAsString('in/INPUT.json'), 'application/json')]" mediaType="application/json"/>
        </munit:set-event>
        <logger level="INFO" message="#[payload]" category="SUITE_BASE.execution-start"/>
        <http:request config-ref="TEST_HTTP_CONFIG" method="METHOD" path="RESOLVED_RESOURCE_PATH">
            <http:body><![CDATA[#[payload]]]></http:body>
            <!-- Add evidenced headers, uri-params, query-params in schema order. -->
        </http:request>
        <logger level="INFO" message="#[payload]" category="SUITE_BASE.execution-end"/>
    </munit:execution>
    <!-- Insert the exact Shared: canonical validation block from the router. -->
</munit:test>
```

Remove `http:body` for bodyless contracts. Supply request headers/URI/query values from the contract and traced test configuration; sending HTTP creates real listener attributes. Preserve required types through the HTTP serialization boundary. Never use a flow-ref to simulate REST transport, except a raise-error scenario explicitly testing the sub-flow directly. For that exception retain the applicable REST source list, seed payload only, and classify it as a direct test with no transport coverage.

Exactly one `munit-tools:assert` with the shared canonical expression is mandatory. Do not replace it with assert-that, verify-call, or MunitTools::equalTo. This is a **non-null check**, not a response-schema/status/business-correctness assertion. Do not claim otherwise. If a valid scenario necessarily returns null, report the incompatibility instead of adding set-payload just to make this check pass.

## APIKit router errors

```xml
<munit-tools:mock-when processor="apikit:router">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="doc:id" whereValue="SOURCE_ROUTER_DOC_ID"/>
        <munit-tools:with-attribute attributeName="config-ref" whereValue="SOURCE_APIKIT_CONFIG"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:error typeId="REGISTERED_APIKIT_ERROR"/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

Add doc:name if present; if doc:id is absent use the proven unique config-ref/name combination. Enumerate real reachable APIKit handlers, splitting comma-separated types and honoring handler `when`/order. `ANY` is a catch-all matcher, not an error type to throw: choose a registered error proven to reach it and not a preceding handler. Never automatically substitute HTTP:CONNECTIVITY. These tests exercise error dispatch/formatting with the router mocked; they do not prove the real router detects invalid requests.

Mode C enumerates actual business-handler entries and all candidate anchors; find a real raise-error, error-mapping, or backend failure that reaches each one. Execute real sub-flows, never replace the business error path with an APIKit mock or an `APIKIT:*` injection. If an entry is shadowed/unreachable or its trigger is unavailable, list the evidence as an unresolved obligation. Generate one evidenced trigger per handler entry and distinct condition/type path needed, not a guessed error for every string in a handler list.

## HTTP error request addition

For every test expecting an HTTP error response, insert this as the **last child** of its request, after body/headers/URI/query parameters:

```xml
<http:response-validator>
    <http:success-status-code-validator values="200..599"/>
</http:response-validator>
```

HTTP Modes A/B/C must not use expectedErrorType to expect application errors delivered as HTTP responses. A connection failure of the test client is a test failure, not the application's business error. The broad validator prevents throwing on a response status; it does not assert the expected status.

## Finish

Use shared validation, including the preservation gate. No delta means no WRITE, property copy or runtime invocation. On additions, validate only new-content rules while checking the whole suite still parses, keeps existing tests and has no duplicate names/configurations. Report incompatible existing tests without replacing or deleting them. Use shared progress and summary formats.
