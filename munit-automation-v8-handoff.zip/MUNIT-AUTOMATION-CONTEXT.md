# MUnit automation — portable session context

Updated: 14 September 2026. Current implementation: **version 8.0.0**. Target: VS Code chat with GitHub Copilot, Agent selected, model Auto or the user's existing selection. Instruction content is model-agnostic; no model or provider is pinned.

## Start here

We are creating reusable Markdown instructions for generating and maintaining Mule 4 / MUnit 2.x tests. No actual target Mule application or its Maven repository was supplied or accessed in this session. Do not claim that tests generated in the user's application have been repaired or passed. The user explicitly excluded inspecting the other system where failures occurred.

Read this context, then the actual current package before changing implementation. Do not reconstruct the prompts from this summary or revert to older scaffold/refresh versions. Follow the user's next instruction; a context upload alone does not authorize installing anything or editing an application.

Take `munit-automation-v8-handoff.zip` into the next session. It contains:

```text
MUNIT-AUTOMATION-CONTEXT.md
munit-automation-v8/
  README.md
  VALIDATION.md
  munit-generate.prompt.md
  munit-http-listener.prompt.md
  munit-non-http-listener.prompt.md
```

For Claude or another assistant, attach that ZIP if supported; otherwise extract and attach the six Markdown files individually. A normal chat can review them. Executing the instructions requires source-file/search/edit/terminal tools and the existing Mule toolchain. The installer targets VS Code chat, not a Claude-specific host. Adapting installation/discovery to a different host is separate work. No previous session paths/tools are assumed. Commands needed by users are embedded in the package; the local authoring/regression harness is not part of the handoff.

## Latest report and why version 8 exists

The user reported that their run appeared to work when selecting Claude, but stopped when selecting a GPT model. This is a reported difference, not a measured quality comparison or proof that either run generated correct tests.

The supplied report identified module `digh-enrollment-papi-v3`, listener/router flow `api-flow`, and root RAML artifact `csp-dhisp-enrollment-services-api:3.0.43`, classifier raml, type zip. It said the archive had been extracted and discovered POST /enrollment, POST /v2/enrollment and POST /eligibility. The reported root group was `58484177-6b93-4b16-bbeb-b12b8a5873da`. These are user-reported facts, not locally verified coordinates or reusable defaults.

The blocker was alias common referencing an `exchange_modules/.../csp-dhisp-common-api-library/1.0.4/...` library absent from that extracted archive. The report did not show exhaustive local resolution. The library's own group and exact entry must be read from the literal reference; do not assume the root artifact's group. Required headers are inherited through this library's applied traits, so making up headers or ignoring the missing library is not acceptable.

The report also labeled create-enrollment-flow, create-enrollment-v2-flow and create-eligibility-flow as non-HTTP/public callable flows and proposed running a non-HTTP worker. Source-less callable flows are not autonomous non-HTTP sources. Actual XML/caller evidence is needed before routing them; helpers owned by an HTTP/APIKit graph must remain in that graph's endpoint scenarios.

Version 8 changes:

- A missing library path inside an extracted API is LOCAL_LOOKUP_REQUIRED, not an immediate fatal missing-root result.
- The HTTP worker must resolve the reference relative to its defining document, inspect archive layout, derive exact dependency coordinates, search the effective local Maven repository, inspect the owning POM/metadata and perform a bounded local fallback before reporting missing content.
- Embedded Windows and macOS probes inspect the exact coordinate directory and ZIP manifests, reporting all candidate entries or explicit empty/access/error evidence. They do not download or select the first candidate automatically.
- Reuse safe extraction for each verified dependency in a separate temp directory, preserve includes, record a reference-to-extracted-file mapping, and resolve transitive dependencies until the queue is complete. A library fragment does not need an API root.
- Continue the already requested generation automatically when resolution succeeds. Do not stop after discovery, mark partial planning complete, or ask “Would you like me to proceed?” while authorized work can continue.
- A true unresolved dependency after local search still blocks project writes. Report the root as found, the exact missing reference/identity, actual checked paths, result and needed action. Distinguish missing, unreadable, ambiguous and invalid content. Do not weaken headers or invent evidence because another model seemed to succeed.
- Router/non-HTTP rules require evidence of a real inbound source before creating non-HTTP work. Source-less public/helper flows are CALLABLE dependencies. Outbound HTTP/MQ/DB operations are not sources. Mixed scope requires actual sources of both types.

The temporary scenario-plan schema remains **version 2**, introduced in version 7. Version 8 adds a temp dependency ledger and resolution procedure rather than changing the scenario schema.

## Settled workflow and constraints

There are exactly three generation prompts: an interactive router, a self-contained HTTP worker and a self-contained non-HTTP worker. Refresh is integrated into both workers; no duplicate refresh prompt. The router loads the applicable worker and executes its workflow rather than merely giving a link.

Invocations:

```text
/munit-generate
/munit-generate all
/munit-generate orders.xml
/munit-generate orders.xml,customers.xml
/munit-generate errors
```

Missing scope asks once. Explicit all/file/list/errors proceeds. Recursively validate every selected filename and caller, including dependencies in other XML files. Keep reactor modules separate. For an explicitly selected isolated callable with no entry owner, clarify direct testing; do not ask about every helper in an all run.

No new extensions, dependency downloads, package installations, production changes or POM edits. Use native Windows PowerShell 5.1/.NET and native macOS commands. PowerShell is not assumed to be built into macOS. Existing authorized chat and compatible Mule/Java/Maven/MUnit dependencies are prerequisites. Extraction, plans and temporary scripts stay in OS temp; do not alter `.m2`.

Allowed generation outputs: src/test/munit/*.xml; src/test/resources/in/*.json and out/*.json; src/test/resources/test-config.xml; the two permitted test YAML files. Normal existing-runner build output is allowed. Installation places prompt/skill definitions outside the Mule project, using README commands; it backs up differing definitions and leaves identical definitions alone. Replace all three definitions together and start a fresh chat to avoid stale instruction context.

## HTTP and RAML requirements

Resolve the root artifact from actual POM/APIKit/local metadata: group, artifact, version, classifier, extension, inherited properties/profiles and effective local-repository overrides. Do not choose the newest ZIP or a similarly named artifact. If the root itself is absent, halt without project writes and ask for that exact RAML artifact. If the root exists but a dependency path is absent, use the version 8 local resolver before concluding it is unavailable.

For every operation, resolve `is: [...]` traits from resources/methods, libraries, includes, nested/parameterized traits and resourceType inheritance. Read the effective request headers, not response headers or unapplied traits. Keep provenance and overrides per operation. Missing required values must be resolved from valid contract examples or existing test-property evidence; never invent credentials/business fields.

Every Mode A/B/C HTTP execution request has `doc:name="Request to <actual request path>"` and one explicit `<http:headers>` DataWeave object containing all effective required headers. Header-name checks are case-insensitive. Use the canonical expression formatting in the worker's plan gate. An empty map is valid only when the effective contract actually requires none. Error tests retain valid anchor-operation headers. Header maps are not YAML or trait names.

`all` means every APIKit-routed method/path endpoint, with one owning suite per endpoint. One XML may contain many endpoints. Cross-check RAML operations, mappings and actual operation-flow names in both directions. Media-type variants become scenarios in the endpoint suite. `errors` discovers entry anchors but writes the applicable error suites only.

## Recursive coverage and external mocks

Before writing XML, build a definition table, caller-specific branch table and full scenario table. Resolve every flow-ref by exact name across production XML: SEARCH → READ complete definition → LIST processors → RECORD actual connector selectors → RECURSE. Cache reads, not coverage; retain caller contexts and processors before/after branches. Never replace a resolved flow-ref or scope with a mock to avoid drilling. Unresolved dynamic calls remain explicit blockers.

- Every choice has distinct scenarios for each feasible when and otherwise, including implicit fall-through and empty/log-only arms. Include nested and sequential branch vectors.
- Scatter-gather has an all-routes-primary scenario plus nontrivial route alternatives; each scenario mocks the union of concurrently executed routes plus prefix/suffix calls.
- foreach/parallel-foreach cover representative iterations and behavior-changing empty/multiple/error cases. Batch covers steps, record acceptance/failures, aggregation and completion. Async/batch need supported observable completion, not a fixed sleep.
- Try/handlers cover success, each feasible matcher/when/body branch and real error propagation. Retry covers success and actual retry exhaustion. Cache gating requires hit and miss, including contains true/false when relevant.
- Predicate fixtures satisfy all conjunctions, ancestor branches and earlier false choice conditions. Trace whether a discriminator comes from entry payload, attributes, a backend result, properties or real variable producers.

Mock actual external operations: HTTP, DB, Salesforce, WSC, SFTP/FTP/file, OS store/retrieve/contains/remove, MQ/JMS/VM and evidenced custom outbound calls. Do not mock source triggers, core/json loggers, DWL, resolved flow-ref or routing/iteration scopes. Use source-verbatim doc:id/doc:name selectors and distinguish repeated calls needing different return behavior.

All mock payloads use literal `MunitTools::getResourceAsString('out/<file>.json')`, optionally wrapped in a type-appropriate read expression. Bare payload / #[payload] is forbidden as a mock return; logger/request-body payload expressions remain valid. Mock-when belongs only in behavior. Then-return order is variables → payload → attributes → error, omitting unused children per schema. ANY is a matcher, never a thrown error. OS contains returns a parsed Boolean; preserve target/targetValue behavior.

Only a full path with no external calls allows behavior containing `<!-- B16-exception: provably empty branch -->`. No verify-call.

Small graphs (≤25 executable doc:id processors) target 100% measured processor coverage; larger graphs at least 80%, while retaining mandatory branch obligations. Planned processor IDs are not measured runtime coverage.

## Fixtures, configuration and existing tests

HTTP in/ uses the RAML request example verbatim as its base; branch variants change only relevant predicate fields while preserving required fields, types and enums. Non-HTTP in/ derives from XML/DWL first consumers and producer provenance. Backend results belong in out/, not in/. A scheduler can have a null event seed; a subscriber can have an actual payload/attributes contract. Never pre-seed flow-derived variables to bypass their producers.

out/ contains raw backend connector output consumed by downstream DWL, not final transformed output or RAML response examples. The documented pass-through exception requires proof that the body is exactly payload. Resolve opaque/binary/typed shapes with actual evidence.

Copy exactly app-properties-test.yaml and app-secrets-test.yaml from their current source locations into src/test/resources/properties, byte-identically. Do not create/copy dev/qa/prod files, app-constants.yaml, app-errors.yaml or apikit-errors.yaml. Do not delete unrelated pre-existing files to satisfy an allowlist; report the conflict.

Every suite imports `<import file="test-config.xml" doc:name="Import"/>` and has its own unique munit:config. Shared HTTP client globals belong in src/test/resources/test-config.xml; derive listener protocol/port/basePath/TLS from actual test configuration, not defaults. Use local test endpoints and mock external operations; no live backend calls.

Existing valid selected tests are a true no-op: preserve bytes/mtime and skip property recopies/write-producing test runs. New branches, stale selectors/fixtures, missing headers/request names or handler tests require narrow updates and additions. Preserve unrelated tests and useful custom checks. Check every shared-fixture consumer; do not blindly overwrite suites, delete unmatched tests or disable failures. Stage projected changes in temp and recheck source/destination hashes before applying.

## Error suites and XML rules

Inventory concrete on-error declarations independently from planned suites, with exact source references including default/global/inline and reusable on-error refs. Classify by actual error/caller role. APIKit cases belong in apikit-error-test-suite.xml; main/business cases in error-test-suite.xml; inline try cases also belong in the owning endpoint/entry suite. Cover comma-separated types separately, then feasible conditions/body paths. An absent source group needs no invented suite; an unreachable declared obligation needs a blocker.

Mode A enables main listener + public operation flow. Mode B enables main only, mocks the actual APIKit router to a supported error and runs the real handler. Mode C enables its main/public pair, keeps the router real and triggers the business error chain. Mock all handler-body external calls. Main coverage cannot use a router mock shortcut. Direct raise-error exceptions have explicit guards and do not count as HTTP routing coverage.

For REST, enable-flow-sources is the first test child; set-event is first in execution and contains payload only. Use http:request in execution except the explicit direct raise-error exception. Error-response requests end with a response-validator accepting 200..599, not expectedErrorType.

XML starts with one declaration, without BOM/leading whitespace, and has one Mule root. Optional generated doc:id can be omitted; if present it is a unique lowercase hexadecimal UUID. Source selector IDs remain verbatim. Declare only namespaces actually used in XML. SUITE_BASE is the filename without .xml and ends -test-suite; owned test names begin SUITE_BASE-. Never use happy-path, error-path or default-choice.

Exactly four test-owned INFO loggers use message="#[payload]": execution-start/end and validation-start/end. Exactly one munit-tools:assert uses `import * from dw::test::Asserts --- payload must notBeNull()`. No assert-that, verify-call or MunitTools::equalTo. This user-required assertion is not a business/status correctness check; do not fabricate non-null output or silently erase useful existing checks to satisfy it.

## Executable checks and honest limits

The frozen OS-temp version 2 plan records sourceRoots, scope/sourceKind, entry/public flows, effective contracts, source handler identity/matchers/cases, required obligations, exclusive branches, suite ownership/preserved tests, per-test mode/handlerCases/request/input checks and exact external mocks/resources/errors. Full schema and native checks are embedded in both workers. The illustrative schema is deliberately incomplete until populated; never copy it as a complete plan.

The gate checks actual suites/test identities, mocks against current source, fixture JSON/scalar discriminators, imports, required obligations, canonical header maps/request names and handler ownership. All/errors scans concrete handlers across the recorded roots; files traverses the selected graph. Never derive the expected plan from already generated tests or shrink it to make checks pass.

Version 7 recorded 59 macOS checks. Version 8 reran those checks and added local dependency-probe cases: **70 passed macOS checks** in total. Consult current VALIDATION.md for the complete list. The native probes were tested with a synthetic repository containing a separately cached library and a transitive library, not the user's cache. The test harness manually drives those probe steps: it does not prove that an agent resolves every RAML dependency or classifies every source correctly.

Windows execution, actual VS Code discovery/agent adherence, complete RAML/trait interpretation, real-application synchronization, Mule XSD/runtime, arbitrary DWL predicates, async/batch completion and measured coverage remain unverified. No model-quality/token/cost/latency claim is measured. Prompt files grew with explicit checks; no token-saving claim follows.

The prior outputs directory was empty at the start of the version 8 update. The tested version 7 prompt copies were recovered from local QA fixtures, then updated; the current README/validation/context were regenerated. The handoff contains the authoritative current files and requires no access to those local recovery paths.

## History and next work

Earlier attachments were unified scaffold, REST scaffold, scheduler scaffold and refresh prompts. Later requirements supersede blind overwrite, one-test-per-suite, skipped sub-flow drilling, bare mock payloads and older error-suite names. Version 7 added inherited header requirements, request display names and stronger source-handler gates. Version 8 addresses local dependency lookup and incorrect non-HTTP classification; it does not relax any prior hard rule.

A previous MuleSoft Vibes discussion positioned this build as an explicit team workflow, not exclusive MUnit generation functionality. No superiority or productivity/cost advantage was measured; any renewed product comparison needs current evidence.

When requested, validate the current package on an authorized representative application. Verify the exact library reference and effective repository, compare trait/operation/call/handler inventories to the agent plan, then run the existing offline Mule tests and inspect real coverage. Exercise Windows commands and targeted refresh followed by a no-op run. Do not inspect the excluded other system or imply those checks already occurred.

## Opening message for another session

```text
Read MUNIT-AUTOMATION-CONTEXT.md, then the attached version 8 package.
Continue from the actual files, preserving the three-prompt architecture,
model independence, native commands, recursive scenarios/mocks, required
trait headers, Request to <path> names, error suites and narrow refresh.
The latest fix requires complete local RAML dependency lookup before a
missing-fragment stop and real inbound-source evidence for non-HTTP routing.
Distinguish the tested native checks from unverified agent/Mule runtime behavior.
Do not assume access to the previous session or install anything automatically.

My next task is: [the review, fix or application validation needed].
```
