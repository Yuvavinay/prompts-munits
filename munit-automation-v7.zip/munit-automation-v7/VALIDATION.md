# Version 7 validation record

Checked locally on macOS on 13 September 2026. The tests exercise the delivered Markdown, native commands and synthetic source/plan/XML fixtures. No real Mule application or the other system where generation failed was inspected.

## New regression evidence

The header fixture has two required names in a manually resolved effective contract. The native gate accepts the explicit matching DataWeave header map and rejects missing maps, wrong values, missing display names, and omission from both the request plan and XML while the effective contract still requires the header. Header-name comparisons are case-insensitive. This is NOT a test of an automatic RAML parser: trait/include/merge resolution remains the agent's source-analysis responsibility.

The handler fixture has the source names apikit-error-hander and main-errror-handlers, three concrete on-error declarations, and four handler scenarios: two APIKit types from one comma-separated matcher, main connectivity, and an ANY matcher with a concrete timeout trigger. Together with the four nested endpoint scenarios, the gate accepts three suites and eight tests. It rejects either missing error suite, either suite omitted from the plan, and both the handler inventory and error-suite rows omitted while source declarations remain. File-scope tests exercise explicit handler references, defaults, and reusable global on-error references. Handler-body external mocks are included.

The fixtures are minimal structural XML, not deployable Mule applications. Passing these checks establishes source/plan/output consistency, not that the injected error reaches the correct handler at runtime. Role classification, feasible when/body paths, registered error mappings, complete traits and supported connector serialization still need source analysis and actual MUnit execution.

## Passed checks

- All three YAML metadata blocks and model-unpinned headers
- macOS Prompt/Skill installers, exact body preservation, idempotent installation, backups, missing-source and symlink safeguards
- All embedded Bash blocks pass syntax checks
- Four nested-choice scenarios accepted with eleven full-path backend mock bindings and source identity checks
- Rejects one-test suite when four scenarios are planned
- Rejects correct count but wrong scenario identity
- Rejects missing otherwise test
- Rejects missing nested sub-flow backend mock
- Rejects missing prefix call mock
- Rejects missing suffix call mock
- Rejects resolved flow-ref mocked instead of backend
- Rejects wrong source doc:id
- Rejects fabricated selector even when both plan and XML use it
- Rejects wrong existing return fixture
- Rejects wrong scenario input fixture
- Rejects wrong discriminator value inside the correctly named input fixture
- Rejects bare payload instead of file-backed return
- Rejects missing import
- Rejects duplicate import
- Rejects one test claiming mutually exclusive branches
- Rejects uncovered required branch despite four test files/names
- Rejects planned error replaced with success
- Rejects malformed nested backend fixture
- Rejects missing owning endpoint suite
- Accepts error-only mock when the scenario plan expects that error
- Accepts typed read(getResourceAsString(...)) return
- Accepts explicitly preserved legacy tests without counting them toward required scenarios
- HTTP A/B/C and non-HTTP templates parse with checked source/set-event/logger/assertion structure
- Native macOS RAML extraction accepts nested valid content; rejects missing, traversal and case collisions
- Rejects missing http:headers element
- Rejects request display name absent
- Rejects request display name without endpoint
- Rejects required trait header missing from XML
- Rejects wrong required header value
- Rejects required trait header omitted from both request plan and XML
- Rejects duplicate case-insensitive header name
- Rejects empty listener entry inventory
- Rejects HTTP listener omitted from all plan
- Accepts required-header name comparison without case sensitivity
- Accepts explicit empty map for a contract with no required headers
- Accepts three suites/eight tests including APIKit comma-separated types, main connectivity and ANY cases with explicit headers
- Rejects missing apikit-error-test-suite.xml
- Rejects apikit-error-test-suite.xml omitted from plan
- Rejects missing error-test-suite.xml
- Rejects error-test-suite.xml omitted from plan
- Rejects both handler inventory and error suites omitted despite current source declarations
- Rejects one comma-separated handler type omitted
- Rejects stale source handler condition
- Rejects APIKit global handler relabeled as local to evade owning suite
- Rejects missing headers in APIKit error suite
- Rejects missing request name in main error suite
- Rejects missing error response validator
- Rejects router mock used to claim main handler coverage
- Rejects missing external mock inside handler body
- File scope follows named error-handler refs and handler sub-flow calls
- Rejects file-scope reachable handlers omitted from both plan and suite list
- File scope follows defaultErrorHandler-ref
- File scope follows a reusable global on-error reference
- Non-HTTP worker gate accepts direct tests without HTTP request contracts

## Unverified

- Windows PowerShell execution: the included commands were reviewed, not run on Windows.
- VS Code discovery, live slash-command execution and agent adherence.
- Complete RAML trait/library/resourceType resolution on a real API.
- Real-application generation, existing-test synchronization and true no-op behavior of the agent.
- MUnit XSD/runtime, DataWeave evaluation, full handler triggering, asynchronous/batch completion and measured coverage.
- Per-model quality, token consumption, latency and cost.

## Practical limits

Source scanning uses the configured sourceRoots recorded from the module POM. For all/errors it inventories concrete on-error declarations across those roots. For files it follows selected entry/public flows, calls, handler refs and defaults; APIKit's implicit dispatch edges still come from the independently checked operation inventory. Missing dynamic references and ambiguous definitions block rather than get silently mocked. Correct roots and operation selection must be independently checked against source.

The fixed payload-not-null assertion remains the user's required convention; it does not verify business output or HTTP status. The gate is not a RAML parser, DataWeave interpreter, Mule compiler, or proof of coverage. Existing unrelated preserved tests are not counted toward required scenario coverage. Source changes between planning and application must be rechecked before edits.

The larger version 7 workers contain additional native checks. No reduction in token use or cost is claimed. Each worker remains self-contained; generation helper commands are embedded, with no new dependency installation.
