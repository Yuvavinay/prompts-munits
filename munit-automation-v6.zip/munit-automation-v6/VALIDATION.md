# Version 6 validation record

Checked locally on macOS on 13 September 2026. Tests exercise the delivered Markdown templates, embedded commands and synthetic scenario plans. No application or other system where the reported generation failed was inspected.

## Regression that addresses the reported defect

The synthetic endpoint has a channel choice (email/sms/otherwise), a nested priority/normal choice in the email sub-flow, an upstream lookup and a downstream audit call in another source file. The plan requires four success tests with eleven mock bindings across those tests. The otherwise case still mocks lookup and audit.

The gate accepts that complete plan/output pair. It rejects a one-test suite, a missing otherwise test, missing nested/upstream/downstream mocks, wrong names despite the same test count, and fabricated mock selectors even if plan and XML agree on the fabricated value. It also rejects wrong input-resource selection and a wrong discriminator inside a correctly named input fixture.

This is an executable consistency regression, not a Mule runtime test. The source fixtures are deliberately minimal XML, not deployable applications. DataWeave predicates were not executed. The agent must still discover the complete source graph, derive valid predicates/fixtures and run the actual test environment.

## Passed checks

- All three YAML metadata blocks and model-unpinned headers
- macOS Prompt/Skill installers, exact body preservation, idempotent installation, backups, missing-source and symlink safeguards
- All embedded Bash blocks pass syntax checks
- Four nested-choice scenarios accepted with eleven full-path backend mock bindings and source identity checks
- Rejects one-test suite when four scenarios are planned
- Rejects correct count but wrong scenario identity
- Rejects missing otherwise test
- Rejects missing nested sub-flow backend mock
- Rejects missing prefix call mock
- Rejects missing suffix call mock
- Rejects resolved flow-ref mocked instead of backend
- Rejects wrong source doc:id
- Rejects fabricated selector even when both plan and XML use it
- Rejects wrong existing return fixture
- Rejects wrong scenario input fixture
- Rejects wrong discriminator value inside the correctly named input fixture
- Rejects bare payload instead of file-backed return
- Rejects missing import
- Rejects duplicate import
- Rejects one test claiming mutually exclusive branches
- Rejects uncovered required branch despite four test files/names
- Rejects planned error replaced with success
- Rejects malformed nested backend fixture
- Rejects missing owning endpoint suite
- Accepts error-only mock when the scenario plan expects that error
- Accepts typed read(getResourceAsString(...)) return
- Accepts explicitly preserved legacy tests without counting them toward required scenarios
- HTTP A/B/C and non-HTTP templates parse with checked source/set-event/logger/assertion structure
- Native macOS RAML extraction accepts nested valid content; rejects missing, traversal and case collisions

## Size comparison

| Prompt | Version 5 bytes | Version 6 bytes | Reduction |
| --- | ---: | ---: | ---: |
| munit-generate | 5,164 | 2,598 | 49.7% |
| munit-http-listener | 63,631 | 49,718 | 21.9% |
| munit-non-http-listener | 48,783 | 42,231 | 13.4% |
| Total | 117,578 | 94,547 | 19.6% |

These are actual UTF-8 file sizes. They are not tokenizer measurements or a benchmark of model usage, latency or cost. The new validation logic occupies space but replaces a weaker nonempty-suite check. Refresh remains integrated into the workers; each worker is self-contained.

## Not verified

- Windows PowerShell execution
- Actual VS Code slash-command behavior/agent adherence
- Complete source/branch discovery and synchronization on a real application
- MUnit schema/runtime, predicate/fixture semantics, batch/async completion and measured coverage
- Per-model quality, token consumption and cost

## Limits of the native gate

The gate compares every planned test name, mock selector, current source match, returned resource/error, input resource, recorded scalar discriminator and required obligation. Explicitly preserved legacy tests are not counted as new coverage. The gate cannot prove the plan contains every real branch, cannot evaluate arbitrary DataWeave, and cannot observe actual async/batch completion. No coverage percentage or all-model reliability claim follows from these checks.

Windows blocks were reviewed but not executed. macOS uses native Foundation XML traversal rather than namespace-sensitive XPath behavior, and the shipped traversal was exercised by the regression cases. MUnit schema/runtime validation remains necessary.
