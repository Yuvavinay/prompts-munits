# MUnit automation — version 6.0.0

This rewrite addresses the one-test-per-suite failure. It uses your attached scaffold, REST, scheduler and refresh prompts as design input, especially their per-branch checklist and recursive flow-ref resolution. It preserves the three-file architecture and folds refresh into both workers to avoid a second implementation of synchronization.

## Commands and files

| File | Role |
| --- | --- |
| [munit-generate.prompt.md](munit-generate.prompt.md) | Interactive HTTP/non-HTTP router |
| [munit-http-listener.prompt.md](munit-http-listener.prompt.md) | RAML-first endpoint generation and refresh |
| [munit-non-http-listener.prompt.md](munit-non-http-listener.prompt.md) | DWL-led generation and refresh for any non-HTTP source |

```text
/munit-generate
/munit-generate all
/munit-generate orders.xml
/munit-generate orders.xml,customers.xml
/munit-generate errors
```

No argument asks for scope; explicit all/files/errors proceeds. all includes all APIKit-routed method/path operations, one owning suite per operation, plus the applicable apikit-error-test-suite.xml and error-test-suite.xml. Within each suite the flow determines the number of tests. A valid linear case can have one; branching processing requires its corresponding scenarios. No fixed minimum is used to pad counts.

## The substantive change

Version 5's executable gate checked whether each expected suite existed and contained tests. Version 6 additionally requires a source-derived plan naming every required test and its exact external-call mocks. It checks test identity, not just total count; mock source identity, not just a nonempty behavior; expected returned fixtures/errors, not just the presence of JSON somewhere.

The agent first builds a flow-definition table, caller-specific branch checklist and complete scenario table. Each flow-ref is resolved recursively by name; choices expand into when/otherwise paths; sequential branches retain their prefix/suffix. A scatter-gather test includes mocks from all concurrently executed routes. The plan is frozen before candidate test XML and independently audited against source. Creating tests first and deriving the plan from those tests is explicitly prohibited.

The native gate rejects a suite containing only one test when four scenario names are expected. It also rejects four tests with the wrong names, a missing nested backend mock, a stale source selector, a wrong return fixture, or one test claiming mutually exclusive branches. Each test must load its planned input fixture; recorded scalar discriminator checks also reject a wrong branch value. Complete predicate evaluation and source inventory still depend on agent analysis; this is not a deterministic Mule compiler or proof of runtime coverage.

## Decisions taken from the attachments

| Retained and clarified | Conflicting or unsafe shortcuts removed |
| --- | --- |
| Name-to-file flow map; branch checklist; depth-first drilling | Unresolved flow-ref treated as sufficient completion |
| One test per distinct required scenario, with full-path mocks | One generic test per suite; isolated scatter-gather route mocks |
| Current-source refresh of selectors and fixtures | Blind overwrite on all; deleting unmatched tests using weak mock overlap |
| Raw backend data from actual DWL consumers | Formatted application error output used as backend input |
| Per-handler type/condition/body analysis | ANY used as an injected error; blanket error types for different connectors |
| Shared test-config import and four-logger/one-assert convention | Scheduler-only assumptions applied to all message sources |

Later requirements take precedence over the older attachments: mock payloads use literal MunitTools::getResourceAsString('out/...json'), imports remain mandatory, and non-HTTP in/ files follow actual entry-data origins. A scheduler can have a null entry seed; that does not imply all message consumers have no input. OS contains returns a Boolean; no source-derived variable is artificially pre-seeded to bypass its producing code.

## Efficiency and model independence

The router reads only the selected worker. Definitions/contracts are read once per run; caller contexts are retained without rereading bodies. Repeated explanations and separate refresh instructions have been removed. Worker rules are still repeated across the two self-contained files so either can be invoked independently. The validation report contains the actual file-size comparison; byte reduction is not a measured token or cost saving.

No model is pinned, and Agent + Auto remains compatible with the intended workflow. The instructions require competent source analysis plus read/search/edit/terminal tools. They cannot make every model equally capable or guarantee identical results. No particular high-end model is selected implicitly.

## One-time installation

Extract outside the Mule project and open a terminal in this directory. Paste the appropriate complete block below. No extra script download, new extension or dependency is installed. Existing authorized VS Code chat and the application's provisioned Java/Maven/Mule/MUnit 2.x environment remain prerequisites.

The included update switches replace definitions with the same names after backup; identical definitions are untouched. Use Prompt for the supported VS Code Local prompt session, or change -Format Prompt to -Format Skill / --format prompt to --format skill for the skill installation format. Keep one active format per command and use a custom destination for custom profiles. Do not run old /munit-scaffold commands when testing this package. Current session support is described in [VS Code prompt-file documentation](https://code.visualstudio.com/docs/agent-customization/prompt-files).

### Windows: paste into Windows PowerShell 5.1

This is a pasted command block; it does not need a persisted script or execution-policy change. Default Prompt destination is %APPDATA%\Code\User\prompts; Skill uses %USERPROFILE%\.copilot\skills. For a named/custom profile, append `-Destination 'ABSOLUTE_DIRECTORY'` after the closing script block arguments. Skill destination is the parent skills directory; Prompt destination is the prompt directory itself.

```powershell
& {
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [ValidateSet('Skill', 'Prompt')][string]$Format = 'Prompt',
    [string]$Destination,
    [switch]$Update
)
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false, $true)
$userRoot = [Environment]::GetFolderPath('UserProfile')
if (-not $userRoot) { throw 'Cannot resolve user profile.' }
$skillRoot = Join-Path $userRoot '.copilot/skills'
if ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) {
    $promptRoot = Join-Path ([Environment]::GetFolderPath('ApplicationData')) 'Code\User\prompts'
} else {
    $promptRoot = Join-Path $userRoot 'Library/Application Support/Code/User/prompts'
}
$useDefault = [string]::IsNullOrWhiteSpace($Destination)
if ($useDefault) {
    if ($Format -eq 'Skill') { $Destination = $skillRoot } else { $Destination = $promptRoot }
}
$Destination = [IO.Path]::GetFullPath($Destination)
# Preflight all three files before any destination write; publish router last.
$names = @('munit-http-listener', 'munit-non-http-listener', 'munit-generate')
$plan = @()
foreach ($name in $names) {
    $source = Join-Path (Get-Location).Path ($name + '.prompt.md')
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing bundled file: $source" }
    $text = [IO.File]::ReadAllText($source, $utf8).Replace("`r`n", "`n")
    $match = [regex]::Match($text, '\A---\n(?<header>.*?)\n---\n(?<body>[\s\S]*)\z', 'Singleline')
    if (-not $match.Success) { throw "Invalid frontmatter: $source" }
    $header = $match.Groups['header'].Value
    if ($header -notmatch ("(?m)^name: '" + [regex]::Escape($name) + "'$") -or
        $header -notmatch "(?m)^version: '6\.0\.0'$") { throw "Mismatched name/version: $source" }
    if ($Format -eq 'Skill') {
        $lines = @('---') + @($header -split "`n" | Where-Object { $_ -match '^(name|description):' })
        $lines += @('metadata:', "  version: '6.0.0'", '---')
        $body = [regex]::Replace($match.Groups['body'].Value, '\((munit-[a-z-]+)\.prompt\.md\)', '(../$1/SKILL.md)')
        $text = ($lines -join "`n") + "`n" + $body
        $target = Join-Path (Join-Path $Destination $name) 'SKILL.md'
        $other = Join-Path $promptRoot ($name + '.prompt.md')
    } else {
        $target = Join-Path $Destination ($name + '.prompt.md')
        $other = Join-Path (Join-Path $skillRoot $name) 'SKILL.md'
    }
    if ($useDefault -and (Test-Path -LiteralPath $other)) {
        throw "Other command format exists at $other. Keep one active format; relocate it before switching."
    }
    $changed = $true
    if (Test-Path -LiteralPath $target) {
        $item = Get-Item -LiteralPath $target
        if ($item.PSIsContainer -or (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
            throw "Destination is not a regular file: $target"
        }
        $changed = [IO.File]::ReadAllText($target, $utf8) -cne $text
        if ($changed -and -not $Update) { throw "Existing content differs: $target. Use -Update to preserve a backup and replace the installed skill." }
    }
    $plan += [pscustomobject]@{ Path = $target; Text = $text; Changed = $changed }
}
if (-not ($plan | Where-Object { $_.Changed })) {
    Write-Output 'All three commands are already installed; no changes.'
    return
}
if (-not $PSCmdlet.ShouldProcess($Destination, 'Install the three MUnit command files')) { return }
foreach ($entry in $plan) {
    if (-not $entry.Changed) { Write-Output "Unchanged: $($entry.Path)"; continue }
    $directory = [IO.Path]::GetDirectoryName($entry.Path)
    [IO.Directory]::CreateDirectory($directory) | Out-Null
    $stage = Join-Path $directory ('.munit-install-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [IO.File]::WriteAllText($stage, $entry.Text, $utf8)
        if ([IO.File]::ReadAllText($stage, $utf8) -cne $entry.Text) { throw 'Staged verification failed.' }
        if (Test-Path -LiteralPath $entry.Path) {
            $backup = $entry.Path + '.backup-' + [guid]::NewGuid().ToString('N')
            [IO.File]::Replace($stage, $entry.Path, $backup)
            Write-Output "Backup: $backup"
        } else { [IO.File]::Move($stage, $entry.Path) }
        if ([IO.File]::ReadAllText($entry.Path, $utf8) -cne $entry.Text) { throw 'Installed verification failed.' }
        Write-Output "Installed: $($entry.Path)"
    } finally {
        if (Test-Path -LiteralPath $stage -PathType Leaf) { [IO.File]::Delete($stage) }
    }
}
Write-Output 'Reload VS Code if needed. Select Agent and Auto; run /munit-generate all.'
Write-Output 'This installer updates skill definitions only. Selected application tests are synchronized using the worker prompts.'
} -Format Prompt -Update
```

### macOS: paste into Terminal

PowerShell is not built into macOS; this block uses its system Bash and native utilities. Default Prompt destination is ~/Library/Application Support/Code/User/prompts; Skill uses ~/.copilot/skills. Add `--destination 'ABSOLUTE_DIRECTORY'` to the first line for a different profile.

```bash
/bin/bash -s -- --format prompt --update <<'MUNIT_INSTALL'
set -euo pipefail
format=prompt
destination=''
update=false
while [ "$#" -gt 0 ]; do
    case "$1" in
        --format) [ "$#" -ge 2 ] || exit 2; format=$2; shift 2 ;;
        --destination) [ "$#" -ge 2 ] && [ -n "$2" ] || exit 2; destination=$2; shift 2 ;;
        --update) update=true; shift ;;
        --help) echo 'Usage: /bin/bash install-munit-command.sh [--format skill|prompt] [--destination DIRECTORY] [--update]'; exit 0 ;;
        *) echo "Unknown argument: $1" >&2; exit 2 ;;
    esac
done
case "$format" in skill|prompt) ;; *) echo 'Format must be skill or prompt' >&2; exit 2 ;; esac
bundle=$PWD
skill_root="$HOME/.copilot/skills"
prompt_root="$HOME/Library/Application Support/Code/User/prompts"
use_default=false
if [ -z "$destination" ]; then
    use_default=true
    if [ "$format" = skill ]; then destination=$skill_root; else destination=$prompt_root; fi
fi
stage_dir=$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/munit-install.XXXXXXXX")
target_stage=''
cleanup() {
    /bin/rm -f -- "$stage_dir/munit-http-listener" "$stage_dir/munit-non-http-listener" "$stage_dir/munit-generate"
    /bin/rmdir -- "$stage_dir"
    if [ -n "$target_stage" ]; then /bin/rm -f -- "$target_stage"; fi
}
trap cleanup EXIT
names=(munit-http-listener munit-non-http-listener munit-generate)
targets=()
changes=()
# Preflight all three destinations before publishing any file; router is last.
for name in "${names[@]}"; do
    source="$bundle/$name.prompt.md"
    [ -f "$source" ] || { echo "Missing bundled file: $source" >&2; exit 1; }
    /usr/bin/awk -v expected="$name" '
      NR == 1 {if ($0 != "---") bad=1; next}
      !closed && $0 == "---" {closed=1; next}
      !closed && $0 == "name: '\''" expected "'\''" {name_ok=1}
      !closed && $0 == "version: '\''6.0.0'\''" {version_ok=1}
      END {if (bad || !closed || !name_ok || !version_ok) exit 1}
    ' "$source" || { echo "Invalid bundled name/version: $source" >&2; exit 1; }
    if [ "$format" = skill ]; then
        target="$destination/$name/SKILL.md"
        other="$prompt_root/$name.prompt.md"
        /usr/bin/awk '
          NR == 1 {print; next}
          !closed && $0 == "---" {print "metadata:"; print "  " version; print "---"; closed=1; next}
          !closed {if ($0 ~ /^(name|description):/) print; if ($0 ~ /^version:/) version=$0; next}
          {print}
        ' "$source" | /usr/bin/sed -E 's@\((munit-[a-z-]+)\.prompt\.md\)@(../\1/SKILL.md)@g' > "$stage_dir/$name"
    else
        target="$destination/$name.prompt.md"
        other="$skill_root/$name/SKILL.md"
        /bin/cp -- "$source" "$stage_dir/$name"
    fi
    if [ "$use_default" = true ] && [ -e "$other" ]; then
        echo "Other command format exists at $other. Keep one active format; relocate it before switching." >&2; exit 1
    fi
    if [ -L "$target" ] || { [ -e "$target" ] && [ ! -f "$target" ]; }; then
        echo "Destination is not a regular file: $target" >&2; exit 1
    fi
    changed=true
    if [ -f "$target" ]; then
        if /usr/bin/cmp -s "$target" "$stage_dir/$name"; then changed=false
        elif [ "$update" = false ]; then
            echo "Existing content differs: $target. Use --update to preserve a backup and replace the installed skill." >&2; exit 1
        fi
    fi
    targets+=("$target")
    changes+=("$changed")
done
for ((i=0; i<${#names[@]}; i++)); do
    target=${targets[$i]}
    if [ "${changes[$i]}" = false ]; then echo "Unchanged: $target"; continue; fi
    directory=$(dirname -- "$target")
    /bin/mkdir -p -- "$directory"
    target_stage=$(/usr/bin/mktemp "$directory/.munit-install.XXXXXXXX")
    /bin/cp -- "$stage_dir/${names[$i]}" "$target_stage"
    /usr/bin/cmp -s "$target_stage" "$stage_dir/${names[$i]}"
    if [ -f "$target" ]; then
        backup="$target.backup-$(/usr/bin/uuidgen)"
        /bin/cp -p -- "$target" "$backup"
        echo "Backup: $backup"
    fi
    /bin/mv -f -- "$target_stage" "$target"
    target_stage=''
    /usr/bin/cmp -s "$target" "$stage_dir/${names[$i]}"
    echo "Installed: $target"
done
echo 'Reload VS Code if needed. Select Agent and Auto; run /munit-generate all.'
echo 'This installer updates skill definitions only. Selected application tests are synchronized using the worker prompts.'
MUNIT_INSTALL
```

Reload VS Code if the slash commands are not listed; inspect Chat: Open Customizations. In remote sessions install on the host where the agent reads its prompts/skills. Normal editor tool approvals remain in effect.

## Validation and limits

See [VALIDATION.md](VALIDATION.md) for tested regressions and unverified areas. Neither the system where you observed failures nor your Mule application was inspected. Native gates exercise synthetic fixtures and plan/XML consistency; they do not prove the agent discovers every branch, that MUnit accepts all generated XML, or that batch/async completes.

The fixed payload-not-null assertion is retained because it is your rule; it is not sufficient to prove business correctness. MUnit mocking does not eliminate initialization requirements, and injected errors must be supported by the installed modules. [MUnit 2.3 mocking](https://docs.mulesoft.com/munit/2.3/mock-event-processor)

Scatter-gather executes its routes and produces an aggregated result; isolating just one route's mock list would miss other executed calls. [Scatter-gather reference](https://docs.mulesoft.com/mule-runtime/4.6/scatter-gather-concept)

Batch step/record acceptance and completion need specific analysis; a request returning does not prove all batch records finished. [Batch phases](https://docs.mulesoft.com/mule-runtime/4.6/batch-phases)
