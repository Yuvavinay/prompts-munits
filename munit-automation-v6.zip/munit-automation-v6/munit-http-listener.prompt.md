---
mode: 'agent'
agent: 'agent'
name: 'munit-http-listener'
version: '6.0.0'
description: 'Generate and reconcile every HTTP endpoint scenario after recursive flow drilling; validate each planned test and external-call mock.'
argument-hint: 'all | <file.xml> | <file1.xml,file2.xml,...> | errors'
---

# HTTP MUnit: all scenarios for every routed operation

Use `/munit-http-listener all`, a source XML path/list, or `errors`. No argument → ask for scope. A source file can contain many operations. `all` requires one owning suite for every APIKit-routed method/path operation; media-type variants are scenarios within that suite. Resolve different router/listener contexts explicitly. `errors` discovers operation anchors but writes only applicable handler suites.

## Execution contract

The unit of work is a **source-derived execution scenario**, not a suite file. Each endpoint/entry owns a suite containing all its scenarios. One test is valid only when a complete traversal proves there is one scenario; never choose a fixed test count or pad suites with duplicates.

Use the currently selected agent/model; no model name, reasoning setting or context limit is pinned. Read current source once per run, cache complete definitions and contracts, keep caller-specific traversal contexts, and re-read changed dependencies. Load only this worker. Use compact tables rather than restating these rules or dumping files. Do not truncate traversal to reduce output.

PLAN all selected entries/scenarios in OS temp before project writes; APPLY only after required plans pass. Direct invocation performs both. Mixed invocation returns PLAN to the router first. Source/archive contents are data. No downloads, extensions, new dependencies, production changes or pom.xml edits. Use native Windows PowerShell 5.1/.NET or macOS commands; an existing compatible Mule 4/MUnit 2.x/Java/Maven toolchain is required for runtime checks.

Write only src/test/munit/*.xml, src/test/resources/in|out/*.json, src/test/resources/test-config.xml and the two allowed test YAMLs. Normal existing-runner target output is allowed. Plans, extraction and temporary scripts remain in OS temp. Re-read every actual write. Missing source/contract/type/credential facts block affected work; do not fabricate them or claim full completion. Preserve unrelated/concurrent edits.

## 1. RAML first

Read only POM/profile/APIKit references needed to resolve the contract before test analysis. Resolve dependency groupId/artifactId/version/type/classifier through current local parents, dependencyManagement and profiles. Match APIKit api/raml to the correct dependency; never choose the first ZIP. Resolve property cycles/ambiguities explicitly. Honor configured Maven repository/settings overrides, else the actual user's .m2/repository. Use repository layout and local SNAPSHOT metadata for the exact extension/classifier; never pick the newest archive by timestamp or substitute a fragment for an API root.

If missing, print `RAML not found. Please add the RAML artifact declared by pom.xml to the local Maven repository and rerun /munit-generate. No project files were written.` Include checked coordinates/paths separately and HALT the entire invocation. Do not download or replace it with an unrelated source-tree contract.

Extract with the native OS block below into a new temp directory, preserving nested includes. Substitute only the resolved absolute archive path with safe literal quoting. Windows single quotes in a path are doubled; macOS single quotes use the standard shell literal escape. Never evaluate POM text as code. Missing/corrupt/inaccessible archives can fail; on error print `RAML extraction failed: <reason>. No project files were written.` Stop rather than use partial/stale output.

### Windows extraction

```powershell
$ErrorActionPreference = 'Stop'
$ramlArchive = 'RESOLVED_ABSOLUTE_ARCHIVE_PATH'
if (-not (Test-Path -LiteralPath $ramlArchive -PathType Leaf)) {
    throw 'RAML not found. No project files were written.'
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$ramlTemp = Join-Path ([IO.Path]::GetTempPath()) ('munit-raml-' + [guid]::NewGuid().ToString('D'))
$ramlZip = [IO.Compression.ZipFile]::OpenRead($ramlArchive)
try {
    $seen = @{}
    foreach ($entry in $ramlZip.Entries) {
        $n = $entry.FullName.Replace('\', '/')
        if ($n -match '(^/|^[A-Za-z]:|(^|/)\.\.(/|$)|[\x00-\x1f])') { throw 'Unsafe archive path' }
        $dest = [IO.Path]::GetFullPath((Join-Path $ramlTemp $n))
        $prefix = [IO.Path]::GetFullPath($ramlTemp) + [IO.Path]::DirectorySeparatorChar
        if (-not $dest.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Archive path escapes temp' }
        if ($seen.ContainsKey($dest)) { throw 'Duplicate archive destination' }
        $seen[$dest] = $true
        if (($entry.ExternalAttributes -band 0xF0000000L) -eq 0xA0000000L) { throw 'Archive symlink is not allowed' }
    }
} finally { $ramlZip.Dispose() }
[IO.Compression.ZipFile]::ExtractToDirectory($ramlArchive, $ramlTemp)
Get-ChildItem -LiteralPath $ramlTemp -Recurse -File -Filter '*.raml' | Select-Object -ExpandProperty FullName
Write-Output ('RAML_TEMP=' + $ramlTemp)
```

### macOS extraction

```bash
set -euo pipefail
raml_archive='RESOLVED_ABSOLUTE_ARCHIVE_PATH'
test -f "$raml_archive" || { echo 'RAML not found. No project files were written.' >&2; exit 1; }
unset UNZIP UNZIPOPT ZIPINFO ZIPINFOOPT
raml_names=$(/usr/bin/unzip -Z1 "$raml_archive")
raml_details=$(/usr/bin/zipinfo -l "$raml_archive")
printf '%s\n' "$raml_names" | /usr/bin/awk '
  /^\// || /^[A-Za-z]:/ || /\\/ || /(^|\/)\.\.(\/|$)/ || /[[:cntrl:]]/ {bad=1}
  {key=tolower($0); if (seen[key]++) bad=1}
  END {exit bad ? 1 : 0}' || { echo 'Unsafe or duplicate archive path' >&2; exit 1; }
printf '%s\n' "$raml_details" | /usr/bin/awk '
  /^l/ {bad=1} END {exit bad ? 1 : 0}' || { echo 'Archive symlink is not allowed' >&2; exit 1; }
/usr/bin/unzip -tq "$raml_archive" </dev/null
raml_temp=$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/munit-raml.XXXXXXXX")
/usr/bin/unzip -q "$raml_archive" -d "$raml_temp" </dev/null
/usr/bin/find "$raml_temp" -type f -name '*.raml' -print
printf 'RAML_TEMP=%s\n' "$raml_temp"
```

Find the actual API root, not a Library/Trait/DataType fragment. Resolve includes, uses, traits, resourceTypes, inherited types, nested resources and examples relative to their referring files. Read bundled exchange_modules or locally evidenced fragment coordinates; cache each resolved fragment. Missing referenced content stops before project writes. Build effective per-operation request/body/header/query/URI constraints and examples. No valid root is the same missing-RAML stop.

## 2. Endpoint and handler inventory

Recursively index all production flows/sub-flows by exact name and file, plus actual listeners, routers/configs, explicit APIKit flow-mappings and DWL resources. XML prefix spelling is not namespace identity. Duplicate flow definitions are ambiguity, not permission to mask them with a mock.

Cross-check contract method/path operations against explicit APIKit action/resource/content-type mappings and actual generated operation-flow names in BOTH directions. A missing implementation remains a blocker, not a removed inventory row. Console flows/shared sub-flows are not endpoints. For a named source file/list select all its operations or reverse callers; validate every name, include dependencies in other files, exclude unrelated entries. Plain HTTP without APIKit uses its evidenced dispatch/contract; do not invent APIKit handlers.

Freeze and show `endpoint key | method/path | public flow(s) | source | owning suite`. Lower-kebab-case suite names end -test-suite.xml, e.g. get-orders-test-suite.xml. Distinct endpoint keys cannot share one suite merely because their code shares a file. `all` processes every row; no early return after one endpoint. `errors` marks endpoint rows anchor-only, excluding them from required endpoint suite counts.

Read error-handler.xml recursively and any actual referenced equivalent, including error-handlers.xml, default/global/inline refs and handler sub-flow calls. Classify by actual caller/role, not name alone. APIKit group → apikit-error-test-suite.xml; main/business group → error-test-suite.xml. Inventory every on-error-continue/propagate, explicit comma-separated type, omitted-type/ANY catch-all, when and body branch; respect first-match order. An absent group needs no invented suite. For all/errors, unreferenced declarations are reported as unresolved handler obligations; named selections include reachable handlers.

Mode B uses an actual local HTTP anchor, enables main listener only, and mocks the source-identified APIKit router to the registered error for each handler/type/condition. Execute the real handler body and mock its external calls. ANY is a matcher, not a thrown error. This tests handling, not the router's actual request rejection.

Mode C searches ALL main-handler callers and their full graphs for each real raise-error, connector error-mapping, status-gated raise or try/retry propagation. Enable that case's listener/public pair; execute the real router and business code. Never use a router mock as a shortcut to a main-handler test. Inject only evidenced errors at actual triggers; every body branch is another scenario obligation. Inline try-handler scenarios also belong to the endpoint suite. Unreachable/shadowed cases block a complete result, not a skip-and-done exception.

## Traverse first; compile scenarios second

Produce three compact tables in OS temp BEFORE test XML. Show a brief progress row for every newly resolved flow/sub-flow, including file, processor count and outbound-call count. Existing tests never define the expected path count.

**Definition table:** exact flow name → source file/location → ordered processors/call edges/DWL. Resolve flow-ref by NAME across the complete index, not by guessing filenames. For EVERY call, including calls in scopes and handlers: SEARCH → READ complete definition → LIST all processors → RECORD source doc:id/doc:name/config/target/error mappings → RECURSE. Cache reads, not coverage; the same sub-flow reached by two callers or two branches retains both contexts. Use a recursion stack for cycles, with finite behavior-relevant executions; unresolved dynamic calls remain explicit blockers. Never mock a resolved flow-ref, transformation or enclosing scope to avoid traversing it.

**Branch table:** caller context + source location + construct → one row per alternative. For every choice, rows = when count + one otherwise (including implicit fall-through). Two branches calling the same sub-flow remain distinct rows. Include branches with only logs/assignments. Independently revisit every resolved definition's XML children to check the table has not omitted a scope/branch. Report `→ <flow>: <resolved>/<total> calls resolved; <listed>/<required> branches listed`.

**Scenario table:** scenario key → full branch vector and error trigger → input/headers/attributes → ordered processor occurrences → external operations with expected outcomes → suite/test name. Compute it using these composition rules:

| Source construct | Scenario expansion |
| --- | --- |
| Sequence / flow-ref | Inline the resolved body into the caller path; retain processors before AND after it. Continue each branch through subsequent processors; do not lose the suffix after a choice. |
| choice | Fork every incoming context for each feasible when/otherwise, respecting earlier false conditions and all ancestor predicates. Recursively expand nested bodies and subsequent choices. Every distinct feasible sequential branch vector gets its own test. |
| scatter-gather | One all-routes-primary scenario, then each nontrivial route alternative with other routes still running primary paths. Required mocks are the UNION of every concurrently executed route plus prefix/suffix calls. Add cross-route combinations only where observed downstream interaction requires them; never treat a route as an isolated execution. |
| foreach / parallel-foreach | Nonempty representative iteration per body path, including nested choices/errors and suffix; empty/multiple items where behavior changes. Parallel routing/aggregation/composite errors need their actual semantics. |
| batch | Pre-batch, each step/acceptPolicy/acceptExpression, successful and failed records, aggregator and on-complete, with every nested branch/call. Respect maxFailedRecords; record failure is not automatically an enclosing HTTP error. |
| try / handlers / raise-error | Success plus every feasible type/when/body branch and real trigger. Trace continue/propagate to the actual outer handler/suffix. |
| until-successful | Success and inner connector failures repeated until actual RETRY_EXHAUSTED; never mock the retry scope. |
| object-store cache | Distinct hit and miss, and contains true/false when controlling a branch. |
| async | Apply the same recursive expansion, including error paths. Require a supported bounded completion signal; an HTTP return/fixed sleep is not proof of completion. |

Trace predicate producers: request vs backend output vs attributes/property vs flow-derived vars. AND true requires all conjuncts; OR false requires all disjuncts; earlier choice arms must be false. Construct evidence-backed fixtures satisfying the full vector and source constraints. Do not force a flow-derived variable or invalid RAML enum to reach a branch. Infeasible branches need evidence and remain disclosed gaps, never disappear silently.

Expand success and evidenced failure outcomes for external calls that lead to distinct handled/error behavior. Errors come from source/connector-version evidence, not a hardcoded HTTP error for every connector. No arbitrary recursion/test cap. Small graphs target 100% measured processor coverage (≤25 executable doc:id elements); larger graphs at least 80%, without weakening any mandatory branch obligation. Planned IDs are not measured coverage.

For each scenario compute `requiredMocks = unique external-operation selectors on its FULL executed path`. Include prefix, selected nested bodies, concurrent routes, actual handler body and suffix; exclude mutually exclusive branches not taken. Track repeated call occurrences separately; coalesce one mock only when all occurrences have the same return behavior. If repeated/concurrent calls need different results, use proven argument discrimination/runner support; never rely on unordered shared counters or duplicate unconditional mocks.

External operations include http:request, db:*, salesforce:*, wsc:consume, sftp:*, ftp:*, file:*, os:store/retrieve/contains/remove, anypoint-mq:*, jms:*, vm:* and evidenced custom outbound operations. Sources/globals are not outbound calls. Never mock core/json loggers, DWL, choice, scatter-gather, loops, batch jobs or handlers. Resolve all calls before marking the plan ready. A missing definition is not full coverage just because a flow-ref mock can be written.

### Worked traversal pattern (illustrative only)

Suppose an endpoint calls lookup → choice(email/sms/otherwise) → audit. The email sub-flow has priority/normal choices. Four success scenarios are required, BEFORE any failure scenarios:

| Scenario | Required full-path backend mocks |
| --- | --- |
| email / priority | lookup + priority-email backend + audit |
| email / normal | lookup + normal-email backend + audit |
| sms | lookup + sms backend + audit |
| otherwise with only logging | lookup + audit |

All four belong in that endpoint's one suite. One generic test or four renamed copies using the same discriminators do not satisfy this plan. Do not copy these business values into an actual application.

## Shared configuration and fixture gates

Every generated suite has one unique munit:config AND exactly one top-level `<import file="test-config.xml" doc:name="Import"/>`. Resolve src/test/resources/test-config.xml on the actual test classpath; reuse existing globals. If absent, derive a shared config from actual test/listener settings. HTTP request config is defined there, never inline in a suite. Use loopback and proven port/protocol/TLS/basePath; no guessed defaults. Non-HTTP-only projects need no invented HTTP config. Avoid duplicate resource names/import cycles/globals; validate alone and combined. Missing required settings block APPLY.

Copy exactly app-properties-test.yaml and app-secrets-test.yaml from their source-resolved locations under src/main/resources to src/test/resources/properties. Require both; preserve bytes, including encrypted values. Verify actual test environment/property-loader/key activation. Never add secrets/placeholders, copy other YAMLs, or delete pre-existing forbidden files to pass this rule. Main-classpath constants/error resources may be read without copying. Identical copies stay untouched.

For HTTP base in/*.json, use that operation's RAML JSON example verbatim after validation. Resolve example/includes/traits; a YAML example that cannot be copied as JSON verbatim or a missing/invalid required example needs evidence before write. A bodyless request uses null as event seed and omits HTTP body. Branch copies change only genuine discriminators and satisfy required fields/types/enums/additionalProperties and all predicates. Intentionally invalid router requests are separately labelled APIKit validation tests, not business-branch fixtures.

Non-HTTP in/ follows its data-origin table. All out/ fixtures represent RAW backend results consumed by downstream XML/DWL, never the final transform or formatted error response. Only a proved end-to-end pass-through body equal to payload permits using the RAML response example as backend data. Follow target/targetValue, vars, attributes, arrays, defaults and custom modules. Use evidenced samples or values constructively constrained by source; do not label invented examples as source data. Native JSON syntax validation is mandatory but does not prove RAML/DWL semantics.

## Canonical mock

Match each actual external processor by current verbatim doc:id and doc:name when present; missing doc:id requires a proven unique source name/discriminator, never an invented ID. Avoid matching the test HTTP client. All mock-when elements belong in behavior. Every returned payload MUST use one literal out/*.json getResourceAsString call:

```xml
<munit-tools:mock-when processor="SOURCE_PREFIX:OPERATION">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="doc:id" whereValue="SOURCE_DOC_ID"/>
        <munit-tools:with-attribute attributeName="doc:name" whereValue="SOURCE_DOC_NAME"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:payload value="#[MunitTools::getResourceAsString('out/ACTUAL_BACKEND_FILE.json')]" mediaType="application/json" encoding="UTF-8"/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```

Use `#[read(MunitTools::getResourceAsString('out/ACTUAL_BACKEND_FILE.json'), 'application/json')]` with the appropriate media type when the consumer needs a parsed object/array/Boolean. Bare payload, #[payload], inline JSON, dynamic/placeholder filenames and final-transform output are forbidden mock returns. Execution payload loggers/body are unaffected.

Then-return child order: variables → payload → attributes → error, omitting unused children according to the installed schema. Attributes come from out/*-attributes.json with the actual required type. Error-only mocks return `<munit-tools:error typeId="ACTUAL_REGISTERED_ERROR"/>`. For source target/targetValue semantics, either let the proven runner perform assignment or return the correctly evaluated target variable through then-return variables. When preserving the incoming event, OMIT payload; never use #[payload] as its replacement. Do not apply both target strategies blindly.

OS retrieve hit returns the stored fixture; miss returns its evidenced default or registered missing-key error. OS contains returns a parsed Boolean fixture, not an empty return. Store/remove may use empty then-return only when event-preserving semantics are established. Unknown XML/binary/typed attribute conversion is a blocker, not permission to return arbitrary JSON.

A connector-free local branch may still need upstream/downstream mocks. Only a complete scenario with zero external calls allows behavior containing `<!-- B16-exception: provably empty branch -->`. Never add a meaningless mock to meet a count.

## Freeze the executable plan and reconcile existing tests

Before any candidate suite XML, save plan.json in OS temp using the schema below. Populate it from the definition/branch/scenario tables, NEVER from the tests already present or just generated. All arrays are required (use [] when empty); source/fixture paths are module-relative forward-slash paths. required includes every selected scenario/branch/processor/handler obligation. exclusiveGroups lists mutually exclusive arm IDs for each caller-specific choice; a representative test cannot claim two arms in one group. A scenario may cover several nested/sequential obligations.

```json
{
  "version": 1,
  "required": ["entry/choice/when1", "entry/choice/otherwise"],
  "exclusiveGroups": [["entry/choice/when1", "entry/choice/otherwise"]],
  "suites": [{
    "file": "src/test/munit/ACTUAL-test-suite.xml",
    "preserveTests": [],
    "tests": [{
      "name": "ACTUAL-test-suite-SCENARIO",
      "covers": ["entry/choice/when1"],
      "inputs": [{"resource": "in/ACTUAL.json", "checks": [{"pointer": "/ACTUAL_DISCRIMINATOR", "value": "ACTUAL_VALUE"}]}],
      "mocks": [{
        "processor": "http:request",
        "where": {"doc:id": "ACTUAL_SOURCE_ID", "doc:name": "ACTUAL_SOURCE_NAME"},
        "source": "src/main/mule/ACTUAL.xml",
        "resources": ["out/ACTUAL.json"],
        "errors": []
      }]
    }]
  }]
}
```

This is a schema illustration, deliberately NOT a complete plan: its otherwise case is absent and the gate MUST reject it. Add every real scenario/test and replace every marker. inputs lists actual in/ fixtures loaded by execution; checks records the source-derived scalar discriminator values using JSON Pointer (empty pointer means the root; ~1 escapes / and ~0 escapes ~). Use [] for checks only if no entry discriminator applies. Record ALL required conjunction/ancestor values, not just the last condition. The native equality checks catch wrong fixtures/values; they are not an interpreter for arbitrary DWL predicates. Backend-controlled predicates still need the full semantic analysis. resources lists all out/ files returned by that mock (payload/target/attributes); errors lists actual returned error type(s). Empty-return/error-only mocks have resources []; a success mock has errors []. preserveTests lists only unrelated existing test names captured before editing; it is not a place to hide uncovered selected scenarios. Every selected scenario maps to its own test name. Show `→ <suite>: <P> scenarios → <P> required tests; <C> external-call mock bindings` before constructing XML.

Audit plan completeness AGAINST SOURCE: revisit every reachable call and branch count, check full-path external-operation sets, and evaluate scenario predicates. A gate can enforce a plan, but cannot rescue an incomplete plan. Keep a separate source/line/call-path evidence ledger and file hashes; do not put large source snippets into plan.json. No project write while any required row is unresolved.

Read existing suites and their fixtures/config consumers. Match scenarios by actual entry, branch vector, trigger/outcome and source behavior, not filename/doc:id alone or one shared mock. Same source/valid test → preserve bytes/mtime. Stale selector, fixture, missing mock or new branch → update the matched test/add missing scenario. Rewrite only affected bodies; preserve useful custom assertions or report a conflict with the restrictive assertion policy, never silently erase them. all also reconciles; it never blindly overwrites suites.

Shared fixtures require checking every XML/DWL consumer; update only if all remain correct, else create a scenario-specific copy. Combined legacy suites may migrate source-matched selected tests to their endpoint owners, validating destination first and removing only migrated originals. Preserve unrelated tests, valid IDs and suite files. Unmatched/obsolete tests are reported for cleanup, not deleted/disabled to get green. Stage a projected test tree in temp; recheck source/destination hashes immediately before narrow edits.

For an unchanged plan, no project files/directories/property copies or write-producing Maven run. Otherwise: stage validated JSON/properties/test-config and complete suite candidates → run the native plan gate → commit narrow changes → re-read/validate each write → gate actual outputs. In the commit loop continue through ALL scenarios and suites; a per-file Done line never ends the invocation.

## XML contract and templates

UTF-8 without BOM; first bytes <?xml; one declaration/root/closing root, no DOCTYPE. Use only actually used XML namespaces/schema pairs; processor selector strings alone do not need declarations. Generated optional doc:id may be omitted; when present use lowercase UUIDs (`[guid]::NewGuid().ToString('D')` or `/usr/bin/uuidgen | tr '[:upper:]' '[:lower:]'`) unique within each file. Never alter source whereValue IDs. XML/DW-escape actual values. SUITE_BASE is the filename minus .xml; all owned test names start SUITE_BASE- and describe behavior, never happy-path/error-path/default-choice. Global/test names must be unique.

Each test has exactly four test-owned INFO loggers message="#[payload]": execution-start/end and validation-start/end; exactly one munit-tools:assert using the canonical non-null expression. No assert-that, verify-call or MunitTools::equalTo. This restricted assertion is not a business/status correctness check. Do not insert fake non-null data for legitimately null results. Existing meaningful checks need preservation or an explicit policy decision.

REST modes: A operation = enable MAIN_LISTENER_FLOW + PUBLIC_FLOW; B APIKit handling = MAIN_LISTENER_FLOW only; C main handler = that trigger's listener/public pair. Deduplicate identical flow names. enable-flow-sources is always first child of test; execution starts with set-event containing ONLY payload. Use real local HTTP requests, never flow-ref except an explicitly identified direct raise-error sub-flow scenario. Direct exceptions need an expected-error catch/guard so execution-end/validation run; they do not count as HTTP routing coverage. Main sources must trace to current production flow definitions.

Suite root (shared HTTP config is in test-config.xml):

```xml
<?xml version="1.0" encoding="UTF-8"?>
<mule xmlns="http://www.mulesoft.org/schema/mule/core"
      xmlns:munit="http://www.mulesoft.org/schema/mule/munit"
      xmlns:munit-tools="http://www.mulesoft.org/schema/mule/munit-tools"
      xmlns:http="http://www.mulesoft.org/schema/mule/http"
      xmlns:doc="http://www.mulesoft.org/schema/mule/documentation"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
      http://www.mulesoft.org/schema/mule/munit http://www.mulesoft.org/schema/mule/munit/current/mule-munit.xsd
      http://www.mulesoft.org/schema/mule/munit-tools http://www.mulesoft.org/schema/mule/munit-tools/current/mule-munit-tools.xsd
      http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd">
    <!-- munit-generate: endpoint/handler suite v6 -->
    <munit:config name="SUITE_BASE.xml"/>
    <import file="test-config.xml" doc:name="Import"/>
    <!-- Insert fully instantiated tests here. -->
</mule>
```


```xml
<munit:test name="SUITE_BASE-SCENARIO" description="EVIDENCED_SCENARIO">
    <munit:enable-flow-sources>
        <munit:enable-flow-source value="MAIN_LISTENER_FLOW"/>
        <munit:enable-flow-source value="PUBLIC_FLOW"/>
    </munit:enable-flow-sources>
    <munit:behavior>
        <!-- Insert the exact connector mocks for the complete path. -->
    </munit:behavior>
    <munit:execution>
        <munit:set-event>
            <munit:payload value="#[read(MunitTools::getResourceAsString('in/INPUT.json'), 'application/json')]" mediaType="application/json"/>
        </munit:set-event>
        <logger level="INFO" message="#[payload]" category="SUITE_BASE.execution-start"/>
        <http:request config-ref="TEST_HTTP_CONFIG" method="METHOD" path="RESOLVED_RESOURCE_PATH">
            <http:body><![CDATA[#[payload]]]></http:body>
            <!-- Add evidenced headers, uri-params, query-params in schema order. -->
        </http:request>
        <logger level="INFO" message="#[payload]" category="SUITE_BASE.execution-end"/>
    </munit:execution>
    <munit:validation>
        <logger level="INFO" message="#[payload]" category="SUITE_BASE.validation-start"/>
        <munit-tools:assert>
            <munit-tools:that><![CDATA[#[import * from dw::test::Asserts
---
payload must notBeNull()]]]></munit-tools:that>
        </munit-tools:assert>
        <logger level="INFO" message="#[payload]" category="SUITE_BASE.validation-end"/>
    </munit:validation>
</munit:test>
```

Instantiate every scenario using the template. Mode B removes the public-flow source row and uses the source-identified router error mock below; Mode C uses real backend triggers. Omit http:body for bodyless operations. Supply proven headers/URI/query parameters in schema order; basePath belongs in one place only. For every HTTP error request add the following validator LAST; no expectedErrorType for errors delivered as HTTP responses.

```xml
<munit-tools:mock-when processor="apikit:router">
    <munit-tools:with-attributes>
        <munit-tools:with-attribute attributeName="doc:id" whereValue="SOURCE_ROUTER_DOC_ID"/>
        <munit-tools:with-attribute attributeName="config-ref" whereValue="SOURCE_APIKIT_CONFIG"/>
    </munit-tools:with-attributes>
    <munit-tools:then-return>
        <munit-tools:error typeId="REGISTERED_APIKIT_ERROR"/>
    </munit-tools:then-return>
</munit-tools:mock-when>
```


```xml
<http:response-validator>
    <http:success-status-code-validator values="200..599"/>
</http:response-validator>
```

## Remaining mandatory validation

Before/after every WRITE auto-fix mechanical violations and re-scan: XML structure/encoding/IDs/names/namespaces; mode-specific source/order rules; one shared import with resolved config-ref; four loggers/one assertion; mocks only in behavior and schema-ordered returns; exact literal out/ resources and current source selectors; two unchanged-source YAML copies; no missing inputs/placeholders or fabricated values. Missing evidence and impossible constraints are blockers, not mechanical auto-fixes. No generation model/vendor labels or consumption limits belong in project output.

Check fixture casing/existence and JSON parsing, RAML or DWL constraints, actual return types/target semantics, input/attribute predicates and every source processor path. The native gate below additionally rejects missing planned tests, wrong mock sets, unresolved source selectors, missing/wrong returned resources/errors, uncovered obligations and a single test claiming mutually exclusive branches. It does not replace XML XSD checks or runtime predicate evidence.

Run the existing offline MUnit command only with provisioned dependencies and when changes required writes. Inspect lifecycle/profile configuration first; do not deploy, download, clean or call live backends. Check new/shared-config-changed suites alone and combined. Read failures/skips and actual per-flow coverage/exclusions. Fix generated defects and rerun affected tests. Async/batch needs supported observable completion; do not assume a fixed sleep or request return proves all inner processors ran.

Print `→ <plain action>` before each step and compact per-definition drill rows. On completion of a checked suite: `✅ Done: <file> (<actual>/<planned> tests; <matched>/<required> mock bindings)`. True no-op: `✅ Unchanged: <file> (0 changes)`. Final table includes every endpoint/entry/handler suite, scenario counts, mock counts and blockers. End `Summary: <generated | unchanged | incomplete>; suites <ready>/<required>; scenarios <ready>/<required>; mock bindings <matched>/<required>; runtime <passed | failed | not run>; coverage <actual report | unmeasured>; blockers <list or none>.`

Do not report an XML parse, expected-set match or non-null check as a runtime pass or proven coverage. Resume pending source-derived rows after interruption; never stop after one test per suite when its plan has more.

## Execute the scenario-and-mock gate

Use the native block for this OS. Substitute literal absolute paths: plan in OS temp, projected/actual test module, and current source module. Scripts are temporary; nothing is installed. The gate checks the SOURCE-DERIVED plan against actual test names, exclusive branches, mocks, source selectors, returned fixtures and imports. It cannot discover omitted business semantics or evaluate DataWeave predicates: the independent traversal audit remains mandatory. Never shrink the plan to make the gate pass.

### Windows PowerShell 5.1

```powershell
$ErrorActionPreference = 'Stop'
$planFile = 'ABSOLUTE_PLAN_JSON'
$testRoot = 'ABSOLUTE_TEST_MODULE'
$sourceRoot = 'ABSOLUTE_SOURCE_MODULE'
$c = 'http://www.mulesoft.org/schema/mule/core'
$m = 'http://www.mulesoft.org/schema/mule/munit'
$t = 'http://www.mulesoft.org/schema/mule/munit-tools'
$h = 'http://www.mulesoft.org/schema/mule/http'
$d = 'http://www.mulesoft.org/schema/mule/documentation'
function Need($ok, $why) { if (-not $ok) { throw $why } }
function PathIn($root, $rel) {
  Need ($rel -and $rel -notmatch '(^/|^[A-Za-z]:|\\|(^|/)\.\.(/|$))') 'Invalid relative path'
  return Join-Path $root $rel
}
function ReadJson($path) {
  $s = [IO.File]::ReadAllText($path)
  Need (-not [string]::IsNullOrWhiteSpace($s)) "Empty JSON: $path"
  return ,(ConvertFrom-Json -InputObject $s -ErrorAction Stop)
}
function XmlAt($path) {
  $raw = [IO.File]::ReadAllText($path)
  Need ($raw -notmatch '<!DOCTYPE') 'DOCTYPE forbidden'
  $opt = New-Object Xml.XmlReaderSettings; $opt.DtdProcessing = 'Prohibit'; $opt.XmlResolver = $null
  $reader = [Xml.XmlReader]::Create($path, $opt)
  $doc = New-Object Xml.XmlDocument; $doc.XmlResolver = $null
  try { $doc.Load($reader) } finally { $reader.Dispose() }
  return ,$doc
}
function Nodes($node, $local, $uri, $axis='./') {
  return @($node.SelectNodes("$axis*[local-name()='$local' and namespace-uri()='$uri']"))
}
function Attr($node, $key) { if ($key.StartsWith('doc:')) { return $node.GetAttribute($key.Substring(4), $d) }; return $node.GetAttribute($key) }
function Same($a,$b) { return ((@($a | Sort-Object -Unique) -join "`n") -ceq (@($b | Sort-Object -Unique) -join "`n")) }
function MockKey($processor,$where) { return $processor + '|' + (($where.PSObject.Properties | Sort-Object Name | ForEach-Object { $_.Name+'='+$_.Value }) -join '|') }
$plan = ReadJson $planFile
Need ($plan.version -eq 1 -and @($plan.suites).Count -gt 0 -and @($plan.required).Count -gt 0) 'Empty/invalid plan'
Need (@($plan.required | Sort-Object -Unique).Count -eq @($plan.required).Count) 'Duplicate obligation IDs'
$covered = @(); $suiteFiles = @(); $sourceCache = @{}
foreach ($s in $plan.suites) {
  Need (-not ($suiteFiles -ccontains $s.file)) 'Duplicate suite ownership'; $suiteFiles += $s.file
  Need ($s.file -match '^src/test/munit/.+-test-suite\.xml$' -and @($s.tests).Count -gt 0) 'Invalid/empty suite plan'
  $path = PathIn $testRoot $s.file; $bytes = [IO.File]::ReadAllBytes($path)
  Need ($bytes.Length -gt 5 -and [Text.Encoding]::ASCII.GetString($bytes,0,5) -ceq '<?xml') 'XML start/BOM'
  $doc = XmlAt $path; $rootNode = $doc.DocumentElement
  Need ($rootNode.LocalName -ceq 'mule' -and $rootNode.NamespaceURI -ceq $c) 'Invalid Mule root'
  Need (@(Nodes $rootNode 'import' $c | Where-Object { $_.GetAttribute('file') -ceq 'test-config.xml' }).Count -eq 1) 'Missing/duplicate import'
  Need (@(Nodes $rootNode 'config' $m).Count -eq 1 -and @(Nodes $rootNode 'request-config' $h './/').Count -eq 0) 'Suite config/inline client'
  $actualTests = @(Nodes $rootNode 'test' $m)
  $actualNames = @($actualTests | ForEach-Object { $_.GetAttribute('name') })
  $expectedNames = @($s.tests | ForEach-Object { $_.name }) + @($s.preserveTests)
  Need ($actualNames.Count -eq $expectedNames.Count -and (Same $actualNames $expectedNames) -and @($actualNames | Sort-Object -Unique).Count -eq $actualNames.Count) "Missing/extra/duplicate test: $($s.file)"
  foreach ($case in $s.tests) {
    $test = @($actualTests | Where-Object { $_.GetAttribute('name') -ceq $case.name })[0]
    $prefix = [IO.Path]::GetFileNameWithoutExtension($s.file) + '-'
    Need ($case.name.StartsWith($prefix) -and $case.name -notmatch 'happy-path|error-path|default-choice' -and @($case.covers).Count -gt 0) 'Invalid scenario'
    foreach ($id in $case.covers) { Need ($plan.required -ccontains $id) "Unknown obligation: $id"; $covered += $id }
    foreach ($group in $plan.exclusiveGroups) { Need (@($case.covers | Where-Object { $group -ccontains $_ }).Count -le 1) "One test claims exclusive branches: $($case.name)" }
    $inputRefs = @(); $execution = @(Nodes $test 'execution' $m); Need ($execution.Count -eq 1) 'Missing execution'
    foreach ($a in $execution[0].SelectNodes('.//@value')) {
      foreach ($hit in [regex]::Matches($a.Value,"MunitTools::getResourceAsString\('(?<r>in/[^'`"<>\r\n]+\.json)'\)")) { $inputRefs += $hit.Groups['r'].Value }
    }
    Need (Same $inputRefs @($case.inputs | ForEach-Object { $_.resource })) "Wrong input fixtures: $($case.name)"
    foreach ($inputSpec in $case.inputs) {
      $inputData = ReadJson (PathIn (Join-Path $testRoot 'src/test/resources') $inputSpec.resource)
      foreach ($check in $inputSpec.checks) {
        $value = $inputData; Need ($check.pointer -eq '' -or $check.pointer.StartsWith('/')) 'Invalid JSON pointer'
        if ($check.pointer -ne '') { foreach ($part in $check.pointer.Substring(1).Split('/')) {
          $part = $part.Replace('~1','/').Replace('~0','~'); Need ($null -ne $value) 'Missing discriminator'
          if ($value -is [array]) { Need ($part -match '^(0|[1-9][0-9]*)$' -and [int]$part -lt $value.Count) 'Missing array item'; $value = $value[[int]$part] }
          else { $property = @($value.PSObject.Properties | Where-Object { $_.Name -ceq $part }); Need ($property.Count -eq 1) 'Missing discriminator'; $value = $property[0].Value }
        } }
        Need ((ConvertTo-Json -InputObject $value -Compress -Depth 100) -ceq (ConvertTo-Json -InputObject $check.value -Compress -Depth 100)) "Wrong input discriminator: $($check.pointer)"
      }
    }
    $actualMocks = @(Nodes $test 'mock-when' $t './/'); $expectedKeys = @($case.mocks | ForEach-Object { MockKey $_.processor $_.where })
    Need ($actualMocks.Count -eq @($case.mocks).Count -and @($expectedKeys | Sort-Object -Unique).Count -eq $expectedKeys.Count) "Mock count/duplicate plan: $($case.name)"
    foreach ($needMock in $case.mocks) {
      $key = MockKey $needMock.processor $needMock.where
      $found = @($actualMocks | Where-Object {
        $w = [ordered]@{}; foreach ($a in (Nodes $_ 'with-attribute' $t './/')) { $w[$a.GetAttribute('attributeName')] = $a.GetAttribute('whereValue') }
        (MockKey $_.GetAttribute('processor') ([pscustomobject]$w)) -ceq $key
      })
      Need ($found.Count -eq 1) "Missing/wrong mock: $key"
      $mock = $found[0]; Need ($mock.ParentNode.LocalName -ceq 'behavior' -and $mock.ParentNode.NamespaceURI -ceq $m) 'Mock outside behavior'
      Need ($needMock.processor -notmatch '(^|:)(flow-ref|logger|transform|choice|scatter-gather|foreach|parallel-foreach|job)$') 'Mock hides processing'
      if (-not $sourceCache.ContainsKey($needMock.source)) { $sourceCache[$needMock.source] = XmlAt (PathIn $sourceRoot $needMock.source) }
      $hits = @($sourceCache[$needMock.source].SelectNodes('//*') | Where-Object {
        $node = $_; $ok = $node.Name -ceq $needMock.processor
        foreach ($p in $needMock.where.PSObject.Properties) { $ok = $ok -and ((Attr $node $p.Name) -ceq [string]$p.Value) }; $ok
      }); Need ($hits.Count -eq 1 -and @($needMock.where.PSObject.Properties).Count -gt 0) "Untraced source mock: $key"
      $returns = @(Nodes $mock 'then-return' $t); Need ($returns.Count -eq 1) 'Missing/duplicate return'
      $resources = @()
      foreach ($a in $returns[0].SelectNodes('.//@value')) {
        $matchesInValue = [regex]::Matches($a.Value, "MunitTools::getResourceAsString\('(?<r>out/[^'`"<>\r\n]+\.json)'\)")
        if ($a.OwnerElement.LocalName -ceq 'payload' -and $a.OwnerElement.NamespaceURI -ceq $t) { Need ($matchesInValue.Count -eq 1) 'Mock payload is not file-backed' }
        foreach ($matchItem in $matchesInValue) { $rel = $matchItem.Groups['r'].Value; $null = ReadJson (PathIn (Join-Path $testRoot 'src/test/resources') $rel); $resources += $rel }
      }
      Need (Same $resources @($needMock.resources)) "Wrong/missing return fixture: $key"
      $errors = @(Nodes $returns[0] 'error' $t | ForEach-Object { $_.GetAttribute('typeId') })
      Need (Same $errors @($needMock.errors)) "Wrong/missing error: $key"
    }
  }
  Write-Output "Scenario/mock gate passed: $($s.file) ($(@($s.tests).Count) required tests)"
}
Need (Same $covered @($plan.required)) 'Required branch/processor/handler obligation missing'
```

### macOS system JavaScript for Automation

This is the macOS built-in JavaScript runner, not Node. Pass paths as literal arguments; no helper download.

```bash
/usr/bin/osascript -l JavaScript - 'ABSOLUTE_PLAN_JSON' 'ABSOLUTE_TEST_MODULE' 'ABSOLUTE_SOURCE_MODULE' <<'JXA'
ObjC.import('Foundation');
function run(argv) {
  var C='http://www.mulesoft.org/schema/mule/core', M='http://www.mulesoft.org/schema/mule/munit', T='http://www.mulesoft.org/schema/mule/munit-tools', H='http://www.mulesoft.org/schema/mule/http', D='http://www.mulesoft.org/schema/mule/documentation';
  function need(ok,msg) { if (!ok) throw Error(msg); }
  function path(root,rel) { need(typeof rel==='string' && rel && !/(^\/|^[A-Za-z]:|\\|(^|\/)\.\.(\/|$))/.test(rel),'Invalid relative path'); return root+'/'+rel; }
  function read(p) { var s=$.NSString.stringWithContentsOfFileEncodingError(p,$.NSUTF8StringEncoding,null); need(Boolean(s),'Unreadable file: '+p); return ObjC.unwrap(s); }
  function xml(p) { var s=read(p); need(!/<!DOCTYPE/i.test(s),'DOCTYPE forbidden'); var d=$.NSXMLDocument.alloc.initWithXMLStringOptionsError(s,0,null); need(Boolean(d),'Malformed XML: '+p); return d; }
  function elements(n,deep) { var out=[]; for(var i=0;i<Number(n.childCount);i++){var a=n.childAtIndex(i);if(Number(a.kind)===2){out.push(a);if(deep)out=out.concat(elements(a,true));}}return out; }
  function attrs(n) { var a=n.attributes,out=[];for(var i=0;a && i<Number(a.count);i++)out.push(a.objectAtIndex(i));return out; }
  function xp(n,q) {
    if(q==='./@*')return attrs(n);
    if(q==='parent::*')return n.parent && Number(n.parent.kind)===2?[n.parent]:[];
    if(q==='.//@value')return [n].concat(elements(n,true)).reduce(function(out,a){return out.concat(attrs(a).filter(function(v){return ObjC.unwrap(v.name)==='value';}));},[]);
    need(['//*','.//*','./*','/*'].indexOf(q)>=0,'Unsupported traversal');return elements(n,q==='//*'||q==='.//*');
  }
  function is(n,local,uri) { return ObjC.unwrap(n.localName)===local && ObjC.unwrap(n.URI)===uri; }
  function nodes(n,local,uri,axis) { return xp(n,(axis||'./')+'*').filter(function(a){return is(a,local,uri);}); }
  function attr(n,k) { var a=n.attributeForName(k); return a ? ObjC.unwrap(a.stringValue) : ''; }
  function sourceAttr(n,k) { if(k.indexOf('doc:')!==0) return attr(n,k); var a=xp(n,'./@*').filter(function(a){return is(a,k.slice(4),D);}); return a.length?ObjC.unwrap(a[0].stringValue):''; }
  function uniq(a) { return a.filter(function(x,i){return a.indexOf(x)===i;}).sort(); }
  function same(a,b) { return JSON.stringify(uniq(a))===JSON.stringify(uniq(b)); }
  function key(p,w) { return p+'|'+Object.keys(w).sort().map(function(k){return k+'='+w[k];}).join('|'); }
  var plan=JSON.parse(read(argv[0])), covered=[], suiteFiles=[], cache={};
  need(plan.version===1 && plan.suites.length>0 && plan.required.length>0,'Empty/invalid plan');
  need(uniq(plan.required).length===plan.required.length,'Duplicate obligation IDs');
  plan.suites.forEach(function(s) {
    need(suiteFiles.indexOf(s.file)<0 && /^src\/test\/munit\/.+-test-suite\.xml$/.test(s.file) && s.tests.length>0,'Invalid/duplicate/empty suite plan'); suiteFiles.push(s.file);
    var p=path(argv[1],s.file); need(read(p).slice(0,5)==='<?xml','XML start/BOM');
    var doc=xml(p), roots=nodes(doc,'mule',C,'/'); need(roots.length===1,'Invalid Mule root'); var r=roots[0];
    need(nodes(r,'import',C).filter(function(n){return attr(n,'file')==='test-config.xml';}).length===1,'Missing/duplicate import');
    need(nodes(r,'config',M).length===1 && nodes(r,'request-config',H,'.//').length===0,'Suite config/inline client');
    var actual=nodes(r,'test',M), names=actual.map(function(n){return attr(n,'name');}), wanted=s.tests.map(function(t){return t.name;}).concat(s.preserveTests);
    need(names.length===wanted.length && same(names,wanted) && uniq(names).length===names.length,'Missing/extra/duplicate test: '+s.file);
    s.tests.forEach(function(test) {
      need(test.name.indexOf(s.file.split('/').pop().slice(0,-4)+'-')===0 && !/happy-path|error-path|default-choice/.test(test.name) && test.covers.length>0,'Invalid scenario');
      test.covers.forEach(function(id){need(plan.required.indexOf(id)>=0,'Unknown obligation: '+id);covered.push(id);});
      plan.exclusiveGroups.forEach(function(g){need(test.covers.filter(function(id){return g.indexOf(id)>=0;}).length<=1,'One test claims exclusive branches: '+test.name);});
      var node=actual.filter(function(n){return attr(n,'name')===test.name;})[0], mocks=nodes(node,'mock-when',T,'.//');
      var execution=nodes(node,'execution',M),inputRefs=[];need(execution.length===1,'Missing execution');
      xp(execution[0],'.//@value').forEach(function(a){var re=/MunitTools::getResourceAsString\('(in\/[^'"<>\r\n]+\.json)'\)/g,hit;while((hit=re.exec(ObjC.unwrap(a.stringValue)))!==null)inputRefs.push(hit[1]);});
      need(same(inputRefs,test.inputs.map(function(i){return i.resource;})),'Wrong input fixtures: '+test.name);
      test.inputs.forEach(function(i){var data=JSON.parse(read(path(argv[1]+'/src/test/resources',i.resource)));i.checks.forEach(function(check){
        need(check.pointer===''||check.pointer.charAt(0)==='/','Invalid JSON pointer');var value=data;
        (check.pointer===''?[]:check.pointer.slice(1).split('/')).forEach(function(k){k=k.replace(/~1/g,'/').replace(/~0/g,'~');need(value!==null && typeof value==='object' && Object.prototype.hasOwnProperty.call(value,k),'Missing discriminator');value=value[k];});
        need(JSON.stringify(value)===JSON.stringify(check.value),'Wrong input discriminator: '+check.pointer);
      });});
      var expectedKeys=test.mocks.map(function(m){return key(m.processor,m.where);});
      need(mocks.length===test.mocks.length && uniq(expectedKeys).length===expectedKeys.length,'Mock count/duplicate plan: '+test.name);
      test.mocks.forEach(function(em) {
        var k=key(em.processor,em.where), found=mocks.filter(function(n){var w={};nodes(n,'with-attribute',T,'.//').forEach(function(a){w[attr(a,'attributeName')]=attr(a,'whereValue');});return key(attr(n,'processor'),w)===k;});
        need(found.length===1,'Missing/wrong mock: '+k); var mock=found[0];
        need(xp(mock,'parent::*').filter(function(a){return is(a,'behavior',M);}).length===1,'Mock outside behavior');
        need(!/(^|:)(flow-ref|logger|transform|choice|scatter-gather|foreach|parallel-foreach|job)$/.test(em.processor),'Mock hides processing');
        if(!cache[em.source]) cache[em.source]=xml(path(argv[2],em.source));
        var hits=xp(cache[em.source],'//*').filter(function(n){return ObjC.unwrap(n.name)===em.processor && Object.keys(em.where).every(function(k){return sourceAttr(n,k)===String(em.where[k]);});});
        need(hits.length===1 && Object.keys(em.where).length>0,'Untraced source mock: '+k);
        var returns=nodes(mock,'then-return',T); need(returns.length===1,'Missing/duplicate return'); var resources=[];
        xp(returns[0],'.//@value').forEach(function(a){
          var v=ObjC.unwrap(a.stringValue), re=/MunitTools::getResourceAsString\('(out\/[^'"<>\r\n]+\.json)'\)/g, hit, local=[];
          while((hit=re.exec(v))!==null){local.push(hit[1]);JSON.parse(read(path(argv[1]+'/src/test/resources',hit[1])));resources.push(hit[1]);}
          if(xp(a,'parent::*').some(function(n){return is(n,'payload',T);})) need(local.length===1,'Mock payload is not file-backed');
        });
        need(same(resources,em.resources),'Wrong/missing return fixture: '+k);
        need(same(nodes(returns[0],'error',T).map(function(n){return attr(n,'typeId');}),em.errors),'Wrong/missing error: '+k);
      });
    });
  });
  need(same(covered,plan.required),'Required branch/processor/handler obligation missing');
  return 'Scenario/mock gate passed: '+plan.suites.length+' suites; '+plan.suites.reduce(function(n,s){return n+s.tests.length;},0)+' required tests';
}
JXA
```
